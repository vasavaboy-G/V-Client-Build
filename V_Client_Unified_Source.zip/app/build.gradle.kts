plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vclient.pvp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vclient.pvp"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// The native library (frame statistics engine) is optional so the normal build never depends on the NDK.
// Build it with:  gradle assembleDebug -PenableNative=true
if (project.findProperty("enableNative") == "true") {
    android {
        defaultConfig {
            ndk { abiFilters += listOf("arm64-v8a") }
        }
        externalNativeBuild {
            cmake { path = file("src/main/cpp/CMakeLists.txt") }
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")

    testImplementation("junit:junit:4.13.2")
    // Real org.json for JVM unit tests (the Android stub jar throws "not mocked"); used by the HUD JSON/profile tests.
    testImplementation("org.json:json:20240303")
}

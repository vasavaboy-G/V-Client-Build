# Keep methods exposed to JavaScript (WebView bridge).
-keepattributes JavascriptInterface
-keepclassmembers class com.vclient.pvp.VBridge {
    @android.webkit.JavascriptInterface <methods>;
}

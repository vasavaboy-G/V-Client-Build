cmake_minimum_required(VERSION 3.18)
project(vclient_native CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(vclient_native SHARED frame_stats.cpp jni_bridge.cpp)

# Android 15+ devices may use 16 KB memory pages: align the library accordingly.
if(ANDROID)
    target_link_options(vclient_native PRIVATE "-Wl,-z,max-page-size=16384")
endif()

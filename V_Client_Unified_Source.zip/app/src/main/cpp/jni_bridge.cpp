// JNI bridge between Kotlin (NativeBridge) and the native frame statistics engine.
// This file is only compiled when the app is built with -PenableNative=true (see app/build.gradle.kts).
#include <jni.h>

#include <mutex>

#include "frame_stats.h"

namespace {
std::mutex g_lock;
vclient::FrameStats g_stats(600);
}  // namespace

extern "C" {

JNIEXPORT jstring JNICALL Java_com_vclient_pvp_NativeBridge_nativeVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF("vclient_native 0 (frame statistics engine only; no game hook)");
}

JNIEXPORT void JNICALL Java_com_vclient_pvp_NativeBridge_nativeOnPresent(JNIEnv*, jclass, jlong nowNs) {
    std::lock_guard<std::mutex> g(g_lock);
    g_stats.onPresent(static_cast<int64_t>(nowNs));
}

JNIEXPORT jdouble JNICALL Java_com_vclient_pvp_NativeBridge_nativeFps(JNIEnv*, jclass, jlong nowNs) {
    std::lock_guard<std::mutex> g(g_lock);
    return g_stats.fps(static_cast<int64_t>(nowNs));
}

JNIEXPORT jdouble JNICALL Java_com_vclient_pvp_NativeBridge_nativeOnePercentLowMs(JNIEnv*, jclass, jlong nowNs) {
    std::lock_guard<std::mutex> g(g_lock);
    return g_stats.onePercentLowMs(static_cast<int64_t>(nowNs));
}

JNIEXPORT void JNICALL Java_com_vclient_pvp_NativeBridge_nativeReset(JNIEnv*, jclass) {
    std::lock_guard<std::mutex> g(g_lock);
    g_stats.reset();
}

}  // extern "C"

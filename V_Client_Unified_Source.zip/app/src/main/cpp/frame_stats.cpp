#include "frame_stats.h"

#include <algorithm>
#include <functional>

namespace vclient {

FrameStats::FrameStats(size_t capacity) : ring_(capacity < 4 ? 4 : capacity, 0) {}

void FrameStats::onPresent(int64_t nowNs) {
    ring_[head_] = nowNs;
    head_ = (head_ + 1) % ring_.size();
    if (count_ < ring_.size()) count_++;
    total_++;
}

void FrameStats::reset() {
    head_ = 0;
    count_ = 0;
    total_ = 0;
}

std::vector<int64_t> FrameStats::intervalsInWindow(int64_t nowNs, int64_t windowNs) const {
    std::vector<int64_t> out;
    if (count_ < 2 || windowNs <= 0) return out;
    const size_t cap = ring_.size();
    const size_t oldest = (head_ + cap - count_) % cap;
    int64_t prev = ring_[oldest];
    for (size_t i = 1; i < count_; i++) {
        const int64_t cur = ring_[(oldest + i) % cap];
        if (cur >= nowNs - windowNs && cur <= nowNs && cur >= prev) out.push_back(cur - prev);
        prev = cur;
    }
    return out;
}

double FrameStats::fps(int64_t nowNs, int64_t windowNs) const {
    const std::vector<int64_t> iv = intervalsInWindow(nowNs, windowNs);
    if (iv.empty()) return 0.0;
    int64_t sum = 0;
    for (int64_t v : iv) sum += v;
    if (sum <= 0) return 0.0;
    return static_cast<double>(iv.size()) * 1e9 / static_cast<double>(sum);
}

double FrameStats::avgFrameMs(int64_t nowNs, int64_t windowNs) const {
    const std::vector<int64_t> iv = intervalsInWindow(nowNs, windowNs);
    if (iv.empty()) return 0.0;
    int64_t sum = 0;
    for (int64_t v : iv) sum += v;
    return static_cast<double>(sum) / static_cast<double>(iv.size()) / 1e6;
}

double FrameStats::onePercentLowMs(int64_t nowNs, int64_t windowNs) const {
    std::vector<int64_t> iv = intervalsInWindow(nowNs, windowNs);
    if (iv.empty()) return 0.0;
    std::sort(iv.begin(), iv.end(), std::greater<int64_t>());
    size_t n = iv.size() / 100;
    if (n < 1) n = 1;
    int64_t sum = 0;
    for (size_t i = 0; i < n; i++) sum += iv[i];
    return static_cast<double>(sum) / static_cast<double>(n) / 1e6;
}

}  // namespace vclient

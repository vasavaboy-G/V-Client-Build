// Frame statistics from "a frame was presented" timestamps.
// Pure C++ (no Android or JNI types) so it can be unit tested on a normal computer.
// It reports only what it is fed. V CLIENT must feed it from a real in-process presentation hook;
// until such a hook exists and is verified on a phone, nothing in the app may show its output as Minecraft FPS.
#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

namespace vclient {

class FrameStats {
public:
    explicit FrameStats(size_t capacity = 600);

    // Record one presented frame. Timestamps must be non-decreasing (nanoseconds, monotonic clock).
    void onPresent(int64_t nowNs);

    // Frames per second over the last windowNs. Returns 0 when fewer than two frames fall in the window
    // or when the newest frame is older than windowNs (the game stopped presenting).
    double fps(int64_t nowNs, int64_t windowNs = 1000000000LL) const;

    // Mean frame time (ms) over the same window; 0 when unavailable.
    double avgFrameMs(int64_t nowNs, int64_t windowNs = 1000000000LL) const;

    // Mean of the slowest 1% of frame times (ms) among frames in the window (at least one frame); 0 when unavailable.
    double onePercentLowMs(int64_t nowNs, int64_t windowNs = 1000000000LL) const;

    size_t totalFrames() const { return total_; }
    void reset();

private:
    // Frame intervals (ns) of frames whose end timestamp lies in [now - window, now]. Oldest first.
    std::vector<int64_t> intervalsInWindow(int64_t nowNs, int64_t windowNs) const;

    std::vector<int64_t> ring_;  // timestamps
    size_t head_ = 0;            // next write position
    size_t count_ = 0;           // valid entries
    size_t total_ = 0;
};

}  // namespace vclient

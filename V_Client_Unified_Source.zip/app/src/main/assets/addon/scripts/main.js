// V CLIENT in-game stats add-on (Script API). Runs inside Minecraft, in worlds that have this behavior pack enabled.
// It does NOT run on public servers you join. Written independently for V CLIENT; no third-party client code.
import { world, system, EquipmentSlot, EntitySwingSource, InputButton, ButtonState } from "@minecraft/server";
import { CONFIG } from "./generated_config.js";
import { normalizeConfig } from "./lib/defaults.js";
import { SlidingCounter } from "./lib/cps.js";
import { ComboTracker } from "./lib/combo.js";
import { cardinal, coordsText, durabilityPercent, armorText, keyStates, keysText, buildLine } from "./lib/format.js";

const cfg = normalizeConfig(CONFIG);
const states = new Map();

// Which APIs this game version really has. Missing ones are shown as "n/a" instead of being faked.
const has = {
  swing: !!(world.afterEvents && world.afterEvents.playerSwingStart),
  hit: !!(world.afterEvents && world.afterEvents.entityHitEntity && world.afterEvents.entityHurt),
  input: true,
};

function stateOf(player) {
  let s = states.get(player.id);
  if (!s) {
    s = { cps: new SlidingCounter(cfg.cpsWindowTicks), combo: new ComboTracker(cfg.comboTimeoutTicks), hits: 0 };
    states.set(player.id, s);
  }
  return s;
}

if (cfg.modules.attack_cps && has.swing) {
  world.afterEvents.playerSwingStart.subscribe(
    (ev) => {
      if (ev && ev.player) stateOf(ev.player).cps.record(system.currentTick);
    },
    { swingSource: EntitySwingSource.Attack }
  );
}

if (cfg.modules.combo && has.hit) {
  world.afterEvents.entityHitEntity.subscribe((ev) => {
    const a = ev.damagingEntity;
    if (a && a.typeId === "minecraft:player") {
      const s = stateOf(a);
      s.hits++;
      s.combo.hit(ev.hitEntity ? ev.hitEntity.id : null, system.currentTick);
    }
  });
  world.afterEvents.entityHurt.subscribe((ev) => {
    const h = ev.hurtEntity;
    if (h && h.typeId === "minecraft:player") stateOf(h).combo.hurt();
  });
}

world.afterEvents.playerLeave.subscribe((ev) => states.delete(ev.playerId));

const ARMOR = [
  ["H", EquipmentSlot.Head],
  ["C", EquipmentSlot.Chest],
  ["L", EquipmentSlot.Legs],
  ["B", EquipmentSlot.Feet],
];

function armorSlots(player) {
  const eq = player.getComponent("minecraft:equippable");
  return ARMOR.map(([label, slot]) => {
    let item;
    try {
      item = eq ? eq.getEquipment(slot) : undefined;
    } catch (e) {
      item = undefined;
    }
    if (!item) return { label, present: false, pct: null };
    const d = item.getComponent("minecraft:durability");
    return { label, present: true, pct: d ? durabilityPercent(d.damage, d.maxDurability) : null };
  });
}

function render(player) {
  const now = system.currentTick;
  const m = cfg.modules;
  const parts = [];
  if (m.coords) parts.push(coordsText(player.location));
  if (m.direction) parts.push(cardinal(player.getRotation().y));
  if (m.armor) parts.push(armorText(armorSlots(player)));
  if (m.keystrokes) {
    const info = player.inputInfo;
    const jump = info.getButtonState(InputButton.Jump) === ButtonState.Pressed;
    const sneak = info.getButtonState(InputButton.Sneak) === ButtonState.Pressed;
    parts.push(keysText(keyStates(info.getMovementVector(), jump, sneak)));
  }
  const s = stateOf(player);
  if (m.attack_cps) parts.push(has.swing ? "CPS " + s.cps.count(now) : "CPS n/a");
  if (m.combo) parts.push(has.hit ? "Combo " + s.combo.current(now) : "Combo n/a");
  if (cfg.diagnostic) {
    const v = player.inputInfo.getMovementVector();
    parts.push("DIAG swings=" + s.cps.total + " hits=" + s.hits + " mv=" + v.x.toFixed(1) + "," + v.y.toFixed(1) + " yaw=" + player.getRotation().y.toFixed(0));
  }
  const line = buildLine(parts);
  if (line) player.onScreenDisplay.setActionBar(line);
}

system.runInterval(() => {
  for (const player of world.getAllPlayers()) {
    try {
      render(player);
    } catch (e) {
      if (cfg.diagnostic) console.warn("V CLIENT add-on render error: " + e);
    }
  }
}, cfg.intervalTicks);

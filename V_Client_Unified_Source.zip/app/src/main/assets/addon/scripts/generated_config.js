// Placeholder. V CLIENT replaces this file with your settings every time you build the add-on.
export const CONFIG = {};

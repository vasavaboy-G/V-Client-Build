package com.vclient.pvp

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * One small overlay window per HUD element. Each element has its own on/off switch (settings key w_<id>_on) and its own look and
 * position, stored in the active HUD profile (see HudProfiles). Positions are fractions of the screen (separate for portrait and
 * landscape) and are always clamped so an element can never end up off screen.
 *
 * Data shown: battery, clock, free RAM, free storage, display refresh rate, overlay time, ping to a server you typed,
 * touch CPS (touches, NOT attack clicks) and your own text. Elements that need game data (FPS, attack CPS, coordinates, direction,
 * keystrokes, armor, combo) show "Needs Native Integration" until a verified real source exists (see GameData). Never an invented number.
 */
class HudOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val store: SettingsStore,
    private val startedAt: Long
) {
    private class W(val root: FrameLayout, val text: TextView, val lp: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var lastW = 0
        var lastH = 0
    }

    private val views = HashMap<String, W>()
    private val handler = Handler(Looper.getMainLooper())
    private val clockFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val ping = PingProbe()
    private val profiles: HudProfiles get() = HudStore.get(ctx)
    private var tapView: View? = null
    private var visible = true
    private var editing = false

    private val ticker = object : Runnable {
        override fun run() {
            updateTexts()
            handler.postDelayed(this, 500L)
        }
    }

    fun setVisible(v: Boolean) {
        visible = v
        val vis = if (v) View.VISIBLE else View.GONE
        for (w in views.values) w.root.visibility = vis
    }

    /** Re-reads switches, styles and positions. Cheap: only touches windows whose element is on. */
    fun refresh() {
        handler.removeCallbacks(ticker)
        editing = store.getBool(Keys.HUD_EDIT)
        for (id in Widgets.ids) {
            if (store.getBool(Widgets.keyOn(id))) {
                ensure(id)
                style(id)
            } else {
                removeWidget(id)
            }
        }
        syncPing()
        syncTap()
        if (views.isNotEmpty()) {
            updateTexts()
            handler.postDelayed(ticker, 500L)
        }
    }

    private fun flags(): Int {
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        if (!editing) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        return f
    }

    private fun ensure(id: String) {
        if (views.containsKey(id)) return
        val tv = TextView(ctx)
        tv.includeFontPadding = false
        val root = FrameLayout(ctx)
        root.addView(tv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags(),
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        Ui.applyCutout(lp)
        val w = W(root, tv, lp)
        attachDrag(id, w)
        root.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val nw = r - l
            val nh = b - t
            if (nw != w.lastW || nh != w.lastH) {
                w.lastW = nw
                w.lastH = nh
                // The size is known now: re-clamp so the element is fully on screen.
                root.post { positionWindow(id) }
            }
        }
        try {
            wm.addView(root, lp)
            root.visibility = if (visible) View.VISIBLE else View.GONE
            views[id] = w
        } catch (e: Exception) {
            Log.w(TAG, "Could not add HUD element $id", e)
        }
    }

    private fun attachDrag(id: String, w: W) {
        w.root.setOnTouchListener { v, ev ->
            if (!editing) {
                false
            } else {
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        w.startX = w.lp.x
                        w.startY = w.lp.y
                        w.downX = ev.rawX
                        w.downY = ev.rawY
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val s = Ui.screen(wm)
                        w.lp.x = (w.startX + ev.rawX - w.downX).toInt().coerceIn(0, maxOf(0, s.x - v.width))
                        w.lp.y = (w.startY + ev.rawY - w.downY).toInt().coerceIn(0, maxOf(0, s.y - v.height))
                        safeUpdate(w)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val s = Ui.screen(wm)
                        val land = HudGeometry.isLandscape(s.x, s.y)
                        profiles.setPosition(id, land, HudGeometry.normFromPx(w.lp.x, s.x), HudGeometry.normFromPx(w.lp.y, s.y))
                        true
                    }
                    else -> false
                }
            }
        }
    }

    private fun dp(v: Float): Int = Ui.dp(ctx, v)

    /** Applies look, size and position of one element from the active profile. */
    private fun style(id: String) {
        val w = views[id] ?: return
        val el = profiles.element(id)
        val st = el.style
        val sc = st.scale
        val tv = w.text

        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, st.textSizeSp * sc)
        tv.setTextColor(Ui.withOpacity(0xFF000000.toInt() or st.textColor, st.textOpacity))

        val bg = GradientDrawable()
        bg.cornerRadius = dp(st.radiusDp.toFloat()) * sc
        bg.setColor(Ui.withOpacity(0xFF000000.toInt() or st.bgColor, st.bgOpacity))
        if (st.borderDp > 0) {
            bg.setStroke(maxOf(1, (dp(st.borderDp.toFloat()) * sc).toInt()), 0xFF000000.toInt() or st.borderColor)
        } else if (editing) {
            bg.setStroke(dp(2f), ThemeManager.resolve(store).accent)
        }
        w.root.background = bg

        val padH = (dp(8f) * sc).toInt()
        val padV = (dp(4f) * sc).toInt()
        w.root.setPadding(padH, padV, padH, padV)

        val fixedW = HudGeometry.sizePx(st.widthDp, sc, ctx.resources.displayMetrics.density)
        val fixedH = HudGeometry.sizePx(st.heightDp, sc, ctx.resources.displayMetrics.density)
        w.lp.width = if (fixedW > 0) fixedW else WindowManager.LayoutParams.WRAP_CONTENT
        w.lp.height = if (fixedH > 0) fixedH else WindowManager.LayoutParams.WRAP_CONTENT
        w.lp.flags = flags()
        positionWindow(id)
    }

    /** Computes the pixel position from the normalized one for the current orientation and keeps the element on screen. */
    private fun positionWindow(id: String) {
        val w = views[id] ?: return
        val s = Ui.screen(wm)
        val el = profiles.element(id)
        val pos = el.pos(HudGeometry.isLandscape(s.x, s.y))
        val wpx = if (w.root.width > 0) w.root.width else maxOf(0, w.lp.width)
        val hpx = if (w.root.height > 0) w.root.height else maxOf(0, w.lp.height)
        w.lp.x = HudGeometry.posPx(pos.x, s.x, wpx)
        w.lp.y = HudGeometry.posPx(pos.y, s.y, hpx)
        safeUpdate(w)
    }

    private fun safeUpdate(w: W) {
        try { wm.updateViewLayout(w.root, w.lp) } catch (e: Exception) { /* detached */ }
    }

    private fun textFor(id: String): String = when (id) {
        "battery" -> {
            val pct = DeviceTelemetry.batteryPercent(ctx)
            if (pct != null) "Battery $pct%" else "Battery: Unavailable"
        }
        "clock" -> clockFormat.format(Date())
        "ram" -> {
            val r = DeviceTelemetry.availRamMb(ctx)
            if (r != null) "RAM free $r MB" else "RAM: Unavailable"
        }
        "storage" -> {
            val g = DeviceTelemetry.freeStorageGb()
            if (g != null) String.format(Locale.US, "Storage free %.1f GB", g) else "Storage: Unavailable"
        }
        "refresh" -> {
            val hz = displayHz()
            if (hz != null) String.format(Locale.US, "Display %.0f Hz", hz) else "Display: Unavailable"
        }
        "uptime" -> {
            val s = (SystemClock.elapsedRealtime() - startedAt) / 1000L
            String.format(Locale.US, "Overlay %02d:%02d", s / 60L, s % 60L)
        }
        "ping" -> ping.text()
        "cps" -> "Touch CPS " + TouchStats.cps()
        "custom" -> store.getString(Keys.HUD_CUSTOM_TEXT).ifBlank { "V CLIENT" }
        else -> GameData.text(id, Widgets.labels[id] ?: id)
    }

    @Suppress("DEPRECATION")
    private fun displayHz(): Float? = try {
        wm.defaultDisplay.refreshRate.takeIf { it > 0f }
    } catch (e: Exception) { null }

    private fun updateTexts() {
        for ((id, w) in views) {
            val t = textFor(id)
            if (w.text.text.toString() != t) w.text.text = t
        }
    }

    private fun syncPing() {
        if (store.getBool(Widgets.keyOn("ping"))) {
            ping.configure(store.getString(Keys.PING_HOST), store.getInt(Keys.PING_PORT))
            ping.start()
        } else {
            ping.stop()
        }
    }

    /**
     * A 1x1 window that is told "a touch started outside me" (no coordinates, no content). Counts TOUCH gestures, not Minecraft
     * attacks. Android only reports the start of a new gesture, so extra fingers may be missed (see TouchStats).
     */
    private fun syncTap() {
        val want = store.getBool(Widgets.keyOn("cps"))
        if (want && tapView == null) {
            val v = View(ctx)
            v.setOnTouchListener { _, ev ->
                if (ev.action == MotionEvent.ACTION_OUTSIDE && visible) TouchStats.tap()
                false
            }
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            try {
                wm.addView(v, lp)
                tapView = v
            } catch (e: Exception) {
                Log.w(TAG, "Could not add touch window", e)
                tapView = null
            }
        } else if (!want && tapView != null) {
            removeTap()
        }
    }

    private fun removeTap() {
        val v = tapView
        tapView = null
        if (v != null) {
            try { wm.removeView(v) } catch (e: Exception) { /* already removed */ }
        }
    }

    private fun removeWidget(id: String) {
        val w = views.remove(id) ?: return
        try { wm.removeView(w.root) } catch (e: Exception) { /* already removed */ }
    }

    fun remove() {
        handler.removeCallbacks(ticker)
        ping.stop()
        for (id in ArrayList(views.keys)) removeWidget(id)
        removeTap()
    }

    private companion object {
        const val TAG = "VClientHud"
    }
}

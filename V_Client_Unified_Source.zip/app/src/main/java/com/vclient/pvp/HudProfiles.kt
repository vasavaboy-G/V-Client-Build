package com.vclient.pvp

import org.json.JSONObject
import java.io.File

/**
 * Named HUD layouts ("profiles"), stored in one JSON file in the app's private storage (it survives app updates and restarts).
 * A profile holds the look and the portrait + landscape position of every HUD element. Whether an element is shown at all
 * stays a global module switch (settings key w_<id>_on) and is not part of a profile.
 * All methods are synchronized; the object can be used from the UI thread and the WebView bridge thread.
 */
class HudProfiles(
    private val file: File,
    private val ids: List<String>,
    private val defaultFor: (String) -> HudElement
) {
    companion object {
        const val DEFAULT_NAME = "Default"
        const val MAX_PROFILES = 20
        const val MAX_NAME = 32

        fun safeName(raw: String): String = raw.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().take(MAX_NAME).trim()
    }

    private val profiles = LinkedHashMap<String, LinkedHashMap<String, HudElement>>()
    private var activeName: String = DEFAULT_NAME

    private fun defaults(): LinkedHashMap<String, HudElement> {
        val m = LinkedHashMap<String, HudElement>()
        for (id in ids) m[id] = defaultFor(id)
        return m
    }

    /** Add any element that is missing (new modules after an app update) without touching the existing ones. */
    private fun complete(m: LinkedHashMap<String, HudElement>) {
        for (id in ids) if (!m.containsKey(id)) m[id] = defaultFor(id)
    }

    @Synchronized
    fun load() {
        profiles.clear()
        activeName = DEFAULT_NAME
        if (file.isFile) {
            try {
                val root = JSONObject(file.readText())
                val ps = root.optJSONObject("profiles")
                if (ps != null) {
                    val keys = ps.keys()
                    while (keys.hasNext()) {
                        val rawKey = keys.next()
                        val name = safeName(rawKey)
                        if (name.isEmpty() || profiles.containsKey(name) || profiles.size >= MAX_PROFILES) continue
                        val src = ps.optJSONObject(rawKey) ?: continue
                        profiles[name] = parseElements(src)
                    }
                }
                val a = safeName(root.optString("active", DEFAULT_NAME))
                if (profiles.containsKey(a)) activeName = a
            } catch (e: Exception) {
                // Unreadable file: keep a copy for inspection and start with defaults instead of crashing.
                try { file.renameTo(File(file.parentFile, file.name + ".corrupt")) } catch (x: Exception) { /* ignore */ }
                profiles.clear()
            }
        }
        if (profiles.isEmpty()) profiles[DEFAULT_NAME] = defaults()
        if (!profiles.containsKey(activeName)) activeName = profiles.keys.first()
        for (m in profiles.values) complete(m)
        save()
    }

    private fun parseElements(src: JSONObject): LinkedHashMap<String, HudElement> {
        val m = LinkedHashMap<String, HudElement>()
        val els = src.optJSONObject("elements") ?: src
        for (id in ids) {
            val o = els.optJSONObject(id)
            m[id] = if (o != null) HudJson.elementFromJson(id, o, defaultFor(id)) else defaultFor(id)
        }
        return m
    }

    private fun save() {
        val root = JSONObject()
        root.put("version", HudJson.VERSION)
        root.put("active", activeName)
        val ps = JSONObject()
        for ((name, els) in profiles) ps.put(name, JSONObject().put("elements", HudJson.elementsToJson(els)))
        root.put("profiles", ps)
        try {
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(root.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            // Storage problem: the in-memory state stays usable for this session.
        }
    }

    @Synchronized fun active(): String = activeName
    @Synchronized fun names(): List<String> = profiles.keys.toList()

    private fun cur(): LinkedHashMap<String, HudElement> = profiles[activeName] ?: defaults().also { profiles[activeName] = it }

    @Synchronized
    fun element(id: String): HudElement = cur()[id] ?: defaultFor(id)

    @Synchronized
    fun elements(): Map<String, HudElement> = LinkedHashMap(cur())

    @Synchronized
    fun setElement(id: String, e: HudElement) {
        if (id !in ids) return
        cur()[id] = HudElement(id, HudGeometry.clampStyle(e.style), HudGeometry.clampPos(e.portrait), HudGeometry.clampPos(e.landscape))
        save()
    }

    @Synchronized
    fun setPosition(id: String, landscape: Boolean, x: Float, y: Float) {
        if (id !in ids) return
        val e = element(id)
        val p = HudGeometry.clampPos(HudPos(x, y))
        setElement(id, if (landscape) e.copy(landscape = p) else e.copy(portrait = p))
    }

    @Synchronized
    fun resetElement(id: String) {
        if (id !in ids) return
        cur()[id] = defaultFor(id)
        save()
    }

    @Synchronized
    fun resetActive() {
        profiles[activeName] = defaults()
        save()
    }

    /** Applies the old "Look of all widgets" controls to every element of the active profile. */
    @Synchronized
    fun applyGlobalLook(textSizeSp: Float, textColor: Int, opacityPercent: Int) {
        val m = cur()
        for (id in ids) {
            val e = m[id] ?: continue
            m[id] = e.copy(
                style = HudGeometry.clampStyle(
                    e.style.copy(textSizeSp = textSizeSp, textColor = textColor, textOpacity = opacityPercent, bgOpacity = opacityPercent * 70 / 100)
                )
            )
        }
        save()
    }

    // ---- profile management ----

    @Synchronized
    fun create(name: String): Boolean {
        val n = safeName(name)
        if (n.isEmpty() || profiles.containsKey(n) || profiles.size >= MAX_PROFILES) return false
        profiles[n] = defaults()
        save()
        return true
    }

    @Synchronized
    fun duplicate(name: String, newName: String): Boolean {
        val src = profiles[safeName(name)] ?: return false
        val n = safeName(newName)
        if (n.isEmpty() || profiles.containsKey(n) || profiles.size >= MAX_PROFILES) return false
        profiles[n] = LinkedHashMap(src)
        save()
        return true
    }

    @Synchronized
    fun rename(old: String, newName: String): Boolean {
        val o = safeName(old)
        val n = safeName(newName)
        if (n.isEmpty() || !profiles.containsKey(o) || (n != o && profiles.containsKey(n))) return false
        if (n == o) return true
        val rebuilt = LinkedHashMap<String, LinkedHashMap<String, HudElement>>()
        for ((k, v) in profiles) rebuilt[if (k == o) n else k] = v
        profiles.clear()
        profiles.putAll(rebuilt)
        if (activeName == o) activeName = n
        save()
        return true
    }

    /** The last remaining profile cannot be deleted. Deleting the active one activates the first remaining. */
    @Synchronized
    fun delete(name: String): Boolean {
        val n = safeName(name)
        if (!profiles.containsKey(n) || profiles.size <= 1) return false
        profiles.remove(n)
        if (activeName == n) activeName = profiles.keys.first()
        save()
        return true
    }

    @Synchronized
    fun switchTo(name: String): Boolean {
        val n = safeName(name)
        if (!profiles.containsKey(n)) return false
        activeName = n
        save()
        return true
    }

    // ---- import / export ----

    @Synchronized
    fun exportText(name: String): String? {
        val els = profiles[safeName(name)] ?: return null
        return JSONObject()
            .put("format", HudJson.FORMAT)
            .put("version", HudJson.VERSION)
            .put("name", safeName(name))
            .put("elements", HudJson.elementsToJson(els))
            .toString()
    }

    /** Creates a new profile from exported text. Returns its final name, or null if the text is not a valid HUD profile. */
    @Synchronized
    fun importText(text: String, nameHint: String): String? {
        if (profiles.size >= MAX_PROFILES) return null
        return try {
            val root = JSONObject(text)
            if (root.optString("format") != HudJson.FORMAT) return null
            val src = root.optJSONObject("elements") ?: return null
            var base = safeName(nameHint)
            if (base.isEmpty()) base = safeName(root.optString("name", "Imported"))
            if (base.isEmpty()) base = "Imported"
            var n = base
            var k = 2
            while (profiles.containsKey(n)) { n = safeName(base.take(MAX_NAME - 3) + " " + k); k++ }
            profiles[n] = parseElements(JSONObject().put("elements", src))
            save()
            n
        } catch (e: Exception) {
            null
        }
    }

    @Synchronized
    fun activeJson(): String {
        val o = JSONObject()
        o.put("active", activeName)
        o.put("profiles", org.json.JSONArray(profiles.keys.toList()))
        o.put("elements", HudJson.elementsToJson(cur()))
        return o.toString()
    }
}

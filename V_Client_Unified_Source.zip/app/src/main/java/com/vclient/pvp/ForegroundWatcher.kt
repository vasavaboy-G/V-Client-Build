package com.vclient.pvp

import android.app.AppOpsManager
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.util.Log

/** Special-access checks and shortcuts to the system screens where the user grants them. */
object Access {
    fun overlay(ctx: Context): Boolean = Settings.canDrawOverlays(ctx)

    @Suppress("DEPRECATION")
    fun usage(ctx: Context): Boolean {
        return try {
            val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = if (Build.VERSION.SDK_INT >= 29) {
                ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            } else {
                ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
            }
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            false
        }
    }

    fun dnd(ctx: Context): Boolean {
        return try {
            ctx.getSystemService(NotificationManager::class.java)?.isNotificationPolicyAccessGranted == true
        } catch (e: Exception) {
            false
        }
    }

    fun json(ctx: Context, running: Boolean): String =
        "{\"granted\":" + overlay(ctx) + ",\"running\":" + running +
            ",\"usage\":" + usage(ctx) + ",\"dnd\":" + dnd(ctx) + "}"

    fun openUsageSettings(ctx: Context) {
        try {
            val i = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Log.w("VClientAccess", "usage settings", e)
        }
    }

    fun openDndSettings(ctx: Context) {
        try {
            val i = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
        } catch (e: Exception) {
            Log.w("VClientAccess", "dnd settings", e)
        }
    }
}

/**
 * Tells the service whether a Minecraft build is the app in front, using Usage Access (the user grants it).
 * Without that access it reports "visible" so the overlay is never hidden by mistake.
 */
/**
 * Debounce for "Minecraft is in front". Showing is immediate; hiding needs [hidePolls] "not in game" answers in a row,
 * so a single odd usage event (keyboard, notification shade, a game-assistant sidebar) never hides the menu or HUD.
 */
class VisibilityDebounce(private val hidePolls: Int = 3) {
    private var misses = 0
    private var shown = true

    fun next(inGame: Boolean): Boolean {
        if (inGame) {
            misses = 0
            shown = true
        } else {
            misses++
            if (misses >= hidePolls) shown = false
        }
        return shown
    }

    fun reset() {
        misses = 0
        shown = true
    }
}

class ForegroundWatcher(private val ctx: Context, private val onChange: (Boolean) -> Unit) {
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var lastQuery = 0L
    private var current: String? = null
    private var mcPackages: Set<String> = emptySet()
    private var lastPackageRefresh = 0L
    private var last: Boolean? = null
    private var ignored: Set<String> = emptySet()
    private val debounce = VisibilityDebounce(3)

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            poll()
            handler.postDelayed(this, 1000L)
        }
    }

    fun start() {
        if (running) return
        running = true
        lastQuery = System.currentTimeMillis() - 10 * 60 * 1000L
        last = null
        debounce.reset()
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
        last = null
    }

    @Suppress("DEPRECATION")
    private fun poll() {
        if (!Access.usage(ctx)) {
            emit(debounce.next(true))
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastPackageRefresh > 30000L) {
            val set = HashSet<String>()
            set.add(MinecraftDetector.OFFICIAL_PACKAGE)
            for (m in MinecraftDetector.detectAll(ctx)) set.add(m.packageName)
            mcPackages = set
            // Packages whose "came to the front" events say nothing about whether Minecraft is still on screen.
            val ign = HashSet<String>()
            ign.add(ctx.packageName)
            ign.add("com.android.systemui")
            try {
                val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                for (m in imm.enabledInputMethodList) ign.add(m.packageName)
            } catch (ex: Exception) {
                Log.w("VClientWatcher", "input methods", ex)
            }
            ignored = ign
            lastPackageRefresh = now
        }
        try {
            val usm = ctx.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
            val events = usm.queryEvents(lastQuery, now)
            val e = UsageEvents.Event()
            while (events.hasNextEvent()) {
                events.getNextEvent(e)
                val toFront = e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND ||
                    (Build.VERSION.SDK_INT >= 29 && e.eventType == UsageEvents.Event.ACTIVITY_RESUMED)
                if (toFront && e.packageName !in ignored) current = e.packageName
            }
            lastQuery = now
        } catch (ex: Exception) {
            Log.w("VClientWatcher", "queryEvents", ex)
        }
        val pkg = current
        emit(debounce.next(pkg == null || pkg in mcPackages))
    }

    private fun emit(v: Boolean) {
        if (last != v) {
            last = v
            onChange(v)
        }
    }
}

package com.vclient.pvp

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Normalized position of an element's top-left corner: fractions (0..1) of the screen width and height. */
data class HudPos(val x: Float, val y: Float)

/**
 * Everything that makes one HUD element look the way it does. Colours are 0xRRGGBB (no alpha);
 * opacity is a separate 0..100 percentage for the text and for the background.
 */
data class HudStyle(
    val scale: Float = 1f,
    val textSizeSp: Float = 14f,
    /** 0 = size to content, otherwise a fixed width in dp (before [scale]). */
    val widthDp: Int = 0,
    val heightDp: Int = 0,
    val textColor: Int = 0xFFFFFF,
    val bgColor: Int = 0x000000,
    val textOpacity: Int = 100,
    val bgOpacity: Int = 70,
    val borderColor: Int = 0xFFFFFF,
    val borderDp: Int = 0,
    val radiusDp: Int = 8
)

/** One HUD element: shared look, plus a separate position for portrait and for landscape. */
data class HudElement(val id: String, val style: HudStyle, val portrait: HudPos, val landscape: HudPos) {
    fun pos(landscapeMode: Boolean): HudPos = if (landscapeMode) landscape else portrait
}

object HudLimits {
    const val SCALE_MIN = 0.5f
    const val SCALE_MAX = 3f
    const val TEXT_MIN = 8f
    const val TEXT_MAX = 40f
    const val SIZE_MIN_W = 40
    const val SIZE_MAX_W = 800
    const val SIZE_MIN_H = 16
    const val SIZE_MAX_H = 400
    const val BORDER_MAX = 10
    const val RADIUS_MAX = 40
}

/** Pure geometry. No Android classes, so it is unit tested on the JVM. */
object HudGeometry {
    fun isLandscape(screenW: Int, screenH: Int): Boolean = screenW > screenH

    fun clampStyle(s: HudStyle): HudStyle = s.copy(
        scale = finiteOr(s.scale, 1f).coerceIn(HudLimits.SCALE_MIN, HudLimits.SCALE_MAX),
        textSizeSp = finiteOr(s.textSizeSp, 14f).coerceIn(HudLimits.TEXT_MIN, HudLimits.TEXT_MAX),
        widthDp = if (s.widthDp <= 0) 0 else s.widthDp.coerceIn(HudLimits.SIZE_MIN_W, HudLimits.SIZE_MAX_W),
        heightDp = if (s.heightDp <= 0) 0 else s.heightDp.coerceIn(HudLimits.SIZE_MIN_H, HudLimits.SIZE_MAX_H),
        textColor = s.textColor and 0xFFFFFF,
        bgColor = s.bgColor and 0xFFFFFF,
        borderColor = s.borderColor and 0xFFFFFF,
        textOpacity = s.textOpacity.coerceIn(0, 100),
        bgOpacity = s.bgOpacity.coerceIn(0, 100),
        borderDp = s.borderDp.coerceIn(0, HudLimits.BORDER_MAX),
        radiusDp = s.radiusDp.coerceIn(0, HudLimits.RADIUS_MAX)
    )

    fun clampPos(p: HudPos): HudPos = HudPos(finiteOr(p.x, 0f).coerceIn(0f, 1f), finiteOr(p.y, 0f).coerceIn(0f, 1f))

    private fun finiteOr(v: Float, fallback: Float): Float = if (v.isNaN() || v.isInfinite()) fallback else v

    /** Pixel position of an element's top-left corner, kept fully on screen. An element can never be stuck off screen. */
    fun posPx(norm: Float, screen: Int, size: Int): Int {
        val maxPos = max(0, screen - size)
        return (finiteOr(norm, 0f).coerceIn(0f, 1f) * screen).roundToInt().coerceIn(0, maxPos)
    }

    fun normFromPx(px: Int, screen: Int): Float = if (screen <= 0) 0f else (px.toFloat() / screen).coerceIn(0f, 1f)

    /** Pixel size of a fixed-size element ("auto" stays 0 = measure it). */
    fun sizePx(dp: Int, scale: Float, density: Float): Int =
        if (dp <= 0) 0 else (dp * scale * density).roundToInt().coerceAtLeast(1)
}

/** Where the menu panel goes relative to the floating icon. */
data class MenuRect(val x: Int, val width: Int, val opensRight: Boolean)

object MenuPlacement {
    /**
     * Icon on the LEFT half of the screen: the menu opens to the RIGHT of the icon.
     * Icon on the RIGHT half: it opens to the LEFT. If the preferred side is too narrow the other side is used, and only
     * if neither side has [minW] of room does the panel use the screen width (it then overlaps the icon). It never leaves the screen.
     */
    fun compute(iconX: Int, iconSize: Int, screenW: Int, desiredW: Int, minW: Int, margin: Int, gap: Int): MenuRect {
        val usable = max(0, screenW - 2 * margin)
        val want = min(desiredW, usable)
        val iconCenter = iconX + iconSize / 2
        val preferRight = iconCenter < screenW / 2

        val rightRoom = screenW - margin - (iconX + iconSize + gap)
        val leftRoom = (iconX - gap) - margin

        fun room(right: Boolean) = if (right) rightRoom else leftRoom
        val side = when {
            room(preferRight) >= min(minW, usable) -> preferRight
            room(!preferRight) >= min(minW, usable) -> !preferRight
            else -> null
        }
        if (side == null) {
            // No side has enough room: use as much width as fits and keep it on screen.
            val w = want
            val x = (screenW - w) / 2
            return MenuRect(x.coerceIn(margin, max(margin, screenW - margin - w)), w, preferRight)
        }
        val width = min(want, room(side)).coerceAtLeast(min(minW, usable))
        val x = if (side) iconX + iconSize + gap else iconX - gap - width
        return MenuRect(x.coerceIn(margin, max(margin, screenW - margin - width)), width, side)
    }
}

/** Floating icon placement, stored as fractions of the free range so it survives rotation and different screens. */
object IconPlacement {
    fun px(frac: Float, screen: Int, size: Int): Int {
        val free = max(0, screen - size)
        val f = if (frac.isNaN() || frac.isInfinite()) 0f else frac.coerceIn(0f, 1f)
        return (f * free).roundToInt().coerceIn(0, free)
    }

    fun frac(px: Int, screen: Int, size: Int): Float {
        val free = screen - size
        return if (free <= 0) 0f else (px.toFloat() / free).coerceIn(0f, 1f)
    }

    /** Snap target for the optional "snap to edge" setting: the nearest horizontal edge. */
    fun snapX(currentX: Int, screenW: Int, size: Int): Int {
        val maxX = max(0, screenW - size)
        return if (currentX + size / 2 > screenW / 2) maxX else 0
    }
}

package com.vclient.pvp

/** What the user is playing on. It only changes how modules are described; it never fakes availability. */
enum class WorldMode(val id: String) {
    AUTO("auto"), PUBLIC("public"), PERSONAL("personal");

    companion object {
        fun from(id: String?): WorldMode = values().firstOrNull { it.id == id } ?: AUTO
    }
}

data class ModuleStatus(val code: String, val text: String)

/**
 * Decides, per module, whether it can work. Rules are fixed and honest:
 *  - overlay modules (drawn by Android) work everywhere;
 *  - world add-on modules need a behavior pack inside the world, so they do not work on public servers;
 *  - native modules work only when the native tier is verified for the installed Minecraft version, otherwise they are locked;
 *  - a world add-on module that is native capable is provided natively only when the native tier is verified.
 * "Auto" cannot know which kind of world is open (Android does not tell other apps), so it shows both facts.
 */
object Integrations {
    const val ADDON_NOT_ON_SERVERS = "Add-ons do not run on public servers you join."

    fun statusFor(
        m: ModuleInfo,
        mode: WorldMode,
        addonSent: Boolean,
        native: NativeState = NativeState.NOT_BUILT
    ): ModuleStatus = when (m.requires) {
        Requirement.ANDROID_OVERLAY ->
            ModuleStatus("available", "Works on public servers and in personal worlds.")
        Requirement.WORLD_ADDON -> addonStatus(m, mode, addonSent, native)
        Requirement.NATIVE ->
            if (native.verified) ModuleStatus("available", "Provided by the native tier. " + native.text)
            else ModuleStatus("needs_native", m.reason + " Native tier: " + native.text)
        Requirement.GAME_INTERNAL ->
            ModuleStatus(if (m.planned) "planned" else "unavailable", m.reason)
    }

    private fun addonStatus(m: ModuleInfo, mode: WorldMode, addonSent: Boolean, native: NativeState): ModuleStatus {
        if (m.nativeCapable && native.verified) {
            return ModuleStatus("available", "Provided by the native tier on public servers and in personal worlds. " + native.text)
        }
        val setup = if (addonSent) "Add-on sent to Minecraft. Enable it in the world's behavior packs."
        else "Build and send the add-on, then enable it in your world's behavior packs."
        val nativeNote = if (m.nativeCapable) " Native tier: " + native.text else ""
        return when (mode) {
            WorldMode.PUBLIC -> ModuleStatus("unavailable", ADDON_NOT_ON_SERVERS + nativeNote)
            WorldMode.PERSONAL -> ModuleStatus(if (addonSent) "setup_done" else "setup", setup)
            WorldMode.AUTO -> ModuleStatus("personal_only", "Personal or hosted worlds only. $setup$nativeNote")
        }
    }
}

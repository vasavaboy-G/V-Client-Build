package com.vclient.pvp

/**
 * Real Minecraft values for the HUD. Every function returns null until a VERIFIED native or add-on data feed exists.
 * Nothing here estimates, smooths, randomises or borrows another number (the Android display refresh rate is NOT Minecraft FPS,
 * and screen touches are NOT attack clicks). When the value is null the HUD shows "Needs Native Integration".
 */
object GameData {
    fun fps(): Int? = null
    fun attackCps(): Int? = null
    fun combo(): Int? = null

    /** HUD elements whose values can only come from inside the game. */
    val needsGame: Set<String> = setOf("fps", "attack_cps", "coords", "direction", "keystrokes", "armor", "combo")

    const val NEEDS_NATIVE = "Needs Native Integration"

    /** "live" = a real value is available now, "needs_native" = no real source yet, "android" = measured by Android itself. */
    fun status(id: String): String = when {
        id !in needsGame -> "android"
        liveValue(id) != null -> "live"
        else -> "needs_native"
    }

    private fun liveValue(id: String): String? = when (id) {
        "fps" -> fps()?.toString()
        "attack_cps" -> attackCps()?.toString()
        "combo" -> combo()?.toString()
        else -> null
    }

    /** Text for an in-game element, e.g. "FPS: Needs Native Integration" or "FPS: 87". */
    fun text(id: String, label: String): String = label + ": " + (liveValue(id) ?: NEEDS_NATIVE)
}

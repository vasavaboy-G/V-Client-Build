package com.vclient.pvp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class SavedServer(val name: String, val host: String, val port: Int)

/** Pure link and validation helpers (unit tested). Minecraft's own minecraft:// links do the actual work. */
object ServerLinks {
    const val MAX_SERVERS = 20

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    fun cleanName(raw: String): String = raw.replace(Regex("[^A-Za-z0-9 _.-]"), "").trim().take(32).trim()

    /** Returns a validated server or null. Host must be a plain host name or IPv4 address. */
    fun clean(name: String, host: String, port: Int): SavedServer? {
        val n = cleanName(name)
        val h = host.trim()
        if (n.isEmpty() || h.isEmpty() || !Defaults.hostName.matches(h) || port !in 1..65535) return null
        return SavedServer(n, h, port)
    }

    fun addServerUri(s: SavedServer): String =
        "minecraft://?addExternalServer=" + enc(s.name + "|" + s.host + ":" + s.port).replace("%3A", ":")

    fun connectUri(s: SavedServer): String =
        "minecraft://connect/?serverUrl=" + enc(s.host) + "&serverPort=" + s.port
}

/** Saved servers kept on the phone. Lines are "name<TAB>host<TAB>port"; tabs cannot occur in cleaned names. */
object ServerLibrary {
    private const val PREFS = "v_client_servers"
    private const val KEY = "list"

    fun list(ctx: Context): List<SavedServer> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        return raw.split("\n").mapNotNull { line ->
            val p = line.split("\t")
            if (p.size != 3) null else ServerLinks.clean(p[0], p[1], p[2].toIntOrNull() ?: 0)
        }
    }

    private fun write(ctx: Context, items: List<SavedServer>) {
        val text = items.joinToString("\n") { it.name + "\t" + it.host + "\t" + it.port }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, text).apply()
    }

    fun add(ctx: Context, name: String, host: String, port: Int): Boolean {
        val s = ServerLinks.clean(name, host, port) ?: return false
        val items = list(ctx)
        if (items.size >= ServerLinks.MAX_SERVERS) return false
        write(ctx, items.filterNot { it.host == s.host && it.port == s.port } + s)
        return true
    }

    fun remove(ctx: Context, index: Int): Boolean {
        val items = list(ctx)
        if (index !in items.indices) return false
        write(ctx, items.filterIndexed { i, _ -> i != index })
        return true
    }

    fun toJson(ctx: Context): String {
        val arr = JSONArray()
        list(ctx).forEach { arr.put(JSONObject().put("name", it.name).put("host", it.host).put("port", it.port)) }
        return arr.toString()
    }
}

package com.vclient.pvp

/** Factory look and position of every HUD element. No Android classes, so it is unit tested on the JVM. */
object HudDefaults {
    /**
     * Android-measured elements keep the grid earlier versions used (so existing layouts do not move). Elements that need game
     * data show a long "Needs Native Integration" status, so they get their own column (landscape) or their own rows near the
     * bottom (portrait) where they do not overlap the others.
     */
    fun element(id: String): HudElement {
        val gameIds = Widgets.ids.filter { it in GameData.needsGame }
        val j = gameIds.indexOf(id)
        if (j >= 0) {
            val landscape = HudPos(0.62f, (4 + j * 12) / 100f)
            val portrait = HudPos(0.02f, (66f + j * 4.7f) / 100f)
            return HudElement(id, HudStyle(), portrait, landscape)
        }
        val idx = Widgets.ids.indexOf(id).coerceAtLeast(0)
        val p = HudPos((2 + (idx / 5) * 24) / 100f, (4 + (idx % 5) * 12) / 100f)
        return HudElement(id, HudStyle(), p, p)
    }
}

package com.vclient.pvp

import org.json.JSONArray
import org.json.JSONObject

/** JSON for HUD elements, profiles and the import/export format. Every value read from JSON is validated and clamped. */
object HudJson {
    const val FORMAT = "vclient-hud-profile"
    const val VERSION = 1
    private val hexRe = Regex("^#?[0-9A-Fa-f]{6}$")

    fun hex(c: Int): String = String.format("#%06X", c and 0xFFFFFF)

    fun parseHex(s: String?, fallback: Int): Int {
        if (s == null || !hexRe.matches(s.trim())) return fallback
        return s.trim().removePrefix("#").toInt(16)
    }

    private fun f(o: JSONObject, key: String, fallback: Float): Float {
        if (!o.has(key)) return fallback
        val d = o.optDouble(key, Double.NaN)
        return if (d.isNaN() || d.isInfinite()) fallback else d.toFloat()
    }

    private fun i(o: JSONObject, key: String, fallback: Int): Int {
        if (!o.has(key)) return fallback
        val d = o.optDouble(key, Double.NaN)
        return if (d.isNaN() || d.isInfinite()) fallback else d.toInt()
    }

    fun elementToJson(e: HudElement): JSONObject {
        val s = e.style
        return JSONObject()
            .put("scale", s.scale.toDouble())
            .put("textSize", s.textSizeSp.toDouble())
            .put("width", s.widthDp)
            .put("height", s.heightDp)
            .put("textColor", hex(s.textColor))
            .put("bgColor", hex(s.bgColor))
            .put("textOpacity", s.textOpacity)
            .put("bgOpacity", s.bgOpacity)
            .put("borderColor", hex(s.borderColor))
            .put("border", s.borderDp)
            .put("radius", s.radiusDp)
            .put("x", e.portrait.x.toDouble())
            .put("y", e.portrait.y.toDouble())
            .put("xl", e.landscape.x.toDouble())
            .put("yl", e.landscape.y.toDouble())
    }

    /** Fields missing or invalid in [o] keep the value of [base]. The result is always clamped to the allowed ranges. */
    fun elementFromJson(id: String, o: JSONObject, base: HudElement): HudElement {
        val b = base.style
        val style = HudGeometry.clampStyle(
            HudStyle(
                scale = f(o, "scale", b.scale),
                textSizeSp = f(o, "textSize", b.textSizeSp),
                widthDp = i(o, "width", b.widthDp),
                heightDp = i(o, "height", b.heightDp),
                textColor = parseHex(o.optString("textColor", ""), b.textColor),
                bgColor = parseHex(o.optString("bgColor", ""), b.bgColor),
                textOpacity = i(o, "textOpacity", b.textOpacity),
                bgOpacity = i(o, "bgOpacity", b.bgOpacity),
                borderColor = parseHex(o.optString("borderColor", ""), b.borderColor),
                borderDp = i(o, "border", b.borderDp),
                radiusDp = i(o, "radius", b.radiusDp)
            )
        )
        val portrait = HudGeometry.clampPos(HudPos(f(o, "x", base.portrait.x), f(o, "y", base.portrait.y)))
        val landscape = HudGeometry.clampPos(HudPos(f(o, "xl", base.landscape.x), f(o, "yl", base.landscape.y)))
        return HudElement(id, style, portrait, landscape)
    }

    fun elementsToJson(elements: Map<String, HudElement>): JSONObject {
        val o = JSONObject()
        for ((id, e) in elements) o.put(id, elementToJson(e))
        return o
    }

    fun namesToJson(names: List<String>): String {
        val a = JSONArray()
        names.forEach { a.put(it) }
        return a.toString()
    }
}

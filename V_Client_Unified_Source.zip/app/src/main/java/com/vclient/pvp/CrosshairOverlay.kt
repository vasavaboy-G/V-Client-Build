package com.vclient.pvp

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.max

/**
 * EXTERNAL crosshair drawn by this app above every other app, at the screen centre.
 * It does NOT modify Minecraft's own in-game crosshair and may not line up with it.
 */
class CrosshairView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    var shape: String = "cross"
    var sizePx: Float = 40f
    var thickPx: Float = 4f
    var gapPx: Float = 8f
    var color: Int = Color.GREEN
    var outline: Boolean = true
    var centerDot: Boolean = false

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = sizePx / 2f
        if (outline) {
            val ow = max(1f, thickPx / 2f)
            drawShape(canvas, cx, cy, r, Color.argb(Color.alpha(color), 0, 0, 0), thickPx + 2f * ow, ow)
        }
        drawShape(canvas, cx, cy, r, color, thickPx, 0f)
    }

    private fun drawShape(c: Canvas, cx: Float, cy: Float, r: Float, col: Int, stroke: Float, grow: Float) {
        paint.color = col
        paint.strokeWidth = stroke
        paint.strokeCap = Paint.Cap.SQUARE
        when (shape) {
            "dot" -> {
                paint.style = Paint.Style.FILL
                c.drawCircle(cx, cy, max(2f, r / 3f) + grow, paint)
            }
            "circle" -> {
                paint.style = Paint.Style.STROKE
                c.drawCircle(cx, cy, r, paint)
            }
            "square" -> {
                paint.style = Paint.Style.STROKE
                c.drawRect(cx - r, cy - r, cx + r, cy + r, paint)
            }
            "plus" -> {
                paint.style = Paint.Style.STROKE
                c.drawLine(cx - r, cy, cx + r, cy, paint)
                c.drawLine(cx, cy - r, cx, cy + r, paint)
            }
            else -> {
                paint.style = Paint.Style.STROKE
                val gap = gapPx.coerceAtMost(r - 1f).coerceAtLeast(0f)
                c.drawLine(cx - r, cy, cx - gap, cy, paint)
                c.drawLine(cx + gap, cy, cx + r, cy, paint)
                c.drawLine(cx, cy - r, cx, cy - gap, paint)
                c.drawLine(cx, cy + gap, cx, cy + r, paint)
            }
        }
        if (centerDot && shape != "dot") {
            paint.style = Paint.Style.FILL
            c.drawCircle(cx, cy, max(1.5f, stroke * 0.75f), paint)
        }
    }
}

class CrosshairOverlay(
    private val ctx: Context,
    private val wm: WindowManager,
    private val store: SettingsStore
) {
    private var view: CrosshairView? = null
    private var params: WindowManager.LayoutParams? = null
    private var visible = true

    fun setVisible(v: Boolean) {
        visible = v
        view?.visibility = if (v) View.VISIBLE else View.GONE
    }

    fun refresh() {
        if (!store.getBool(Keys.XH_ENABLED)) {
            remove()
            return
        }
        val sizePx = Ui.dp(ctx, store.getInt(Keys.XH_SIZE).toFloat())
        val thickPx = Ui.dp(ctx, store.getInt(Keys.XH_THICK).toFloat())
        val box = sizePx + thickPx * 3 + Ui.dp(ctx, 10f)

        if (view == null) {
            val v = CrosshairView(ctx)
            val lp = WindowManager.LayoutParams(
                box, box,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.CENTER
            Ui.applyCutout(lp)
            try {
                wm.addView(v, lp)
                view = v
                params = lp
                v.visibility = if (visible) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                return
            }
        }
        val v = view ?: return
        val lp = params ?: return
        v.shape = store.getString(Keys.XH_SHAPE)
        v.sizePx = sizePx.toFloat()
        v.thickPx = thickPx.toFloat()
        v.gapPx = Ui.dp(ctx, store.getInt(Keys.XH_GAP).toFloat()).toFloat()
        v.outline = store.getBool(Keys.XH_OUTLINE)
        v.centerDot = store.getBool(Keys.XH_DOT)
        v.color = Ui.withOpacity(
            Ui.parseColor(store.getString(Keys.XH_COLOR), Color.GREEN),
            store.getInt(Keys.XH_OPACITY)
        )
        lp.width = box
        lp.height = box
        lp.x = Ui.dp(ctx, store.getInt(Keys.XH_DX).toFloat())
        lp.y = Ui.dp(ctx, store.getInt(Keys.XH_DY).toFloat())
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) { /* detached */ }
        v.invalidate()
    }

    fun remove() {
        val v = view
        view = null
        params = null
        if (v != null) {
            try { wm.removeView(v) } catch (e: Exception) { /* already removed */ }
        }
    }
}

package com.vclient.pvp

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.content.Intent
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Packs the user added in V CLIENT. They are sent to Minecraft (which does the import) when it is launched. */
object PackLibrary {
    private const val PREFS = "v_client_packs"
    private const val SENT = "sent"

    val extensions: Set<String> = setOf("mcpack", "mcworld", "mcaddon", "mctemplate", "mcproject")

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "packs")
        d.mkdirs()
        return d
    }

    fun safeName(name: String): String = name.replace(Regex("[^A-Za-z0-9._-]"), "_")

    private fun key(f: File): String = f.name + ":" + f.length() + ":" + f.lastModified()

    private fun sentSet(ctx: Context): HashSet<String> {
        val cur = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(SENT, null)
        return if (cur == null) HashSet() else HashSet(cur)
    }

    fun files(ctx: Context): List<File> =
        dir(ctx).listFiles()?.filter { it.isFile }?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun pending(ctx: Context): List<File> {
        val s = sentSet(ctx)
        return files(ctx).filter { key(it) !in s }
    }

    fun markSent(ctx: Context, f: File) {
        val s = sentSet(ctx)
        s.add(key(f))
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(SENT, s).apply()
    }

    fun isSent(ctx: Context, name: String): Boolean {
        val f = find(ctx, name) ?: return false
        return key(f) in sentSet(ctx)
    }

    fun clearSent(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(SENT).apply()
    }

    fun find(ctx: Context, name: String): File? {
        val f = File(dir(ctx), safeName(name))
        return if (f.isFile) f else null
    }

    fun remove(ctx: Context, name: String): Boolean = find(ctx, name)?.delete() ?: false

    /** Copies the picked document into app storage. Call from a background thread. */
    fun add(ctx: Context, uri: Uri, name: String): Boolean {
        return try {
            val out = File(dir(ctx), safeName(name))
            val input = ctx.contentResolver.openInputStream(uri) ?: return false
            input.use { src -> out.outputStream().use { dst -> src.copyTo(dst) } }
            true
        } catch (e: Exception) {
            Log.w("VClientPacks", "add failed", e)
            false
        }
    }

    fun toJson(ctx: Context): String {
        val s = sentSet(ctx)
        val arr = JSONArray()
        for (f in files(ctx)) {
            arr.put(
                JSONObject()
                    .put("name", f.name)
                    .put("sizeKb", f.length() / 1024L)
                    .put("sent", key(f) in s)
            )
        }
        return arr.toString()
    }
}

/**
 * Opens each pack with Minecraft through a FileProvider URI whose path ends in the real file name.
 * The first pack also launches Minecraft. Later packs are sent a few seconds apart.
 */
object PackSender {
    private val handler = Handler(Looper.getMainLooper())

    fun send(ctx: Context, files: List<File>, pkg: String) {
        val app = ctx.applicationContext
        files.forEachIndexed { i, f ->
            handler.postDelayed({ openOne(app, f, pkg) }, i * 4000L)
        }
    }

    private fun openOne(app: Context, f: File, pkg: String) {
        try {
            val uri = FileProvider.getUriForFile(app, app.packageName + ".fileprovider", f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, "application/octet-stream")
            i.setPackage(pkg)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            app.startActivity(i)
            PackLibrary.markSent(app, f)
        } catch (e: Exception) {
            Log.w("VClientPacks", "send failed for " + f.name, e)
        }
    }
}

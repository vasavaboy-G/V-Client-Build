package com.vclient.pvp

/** One shared palette used by the dashboard (CSS), the floating icon, HUD and the PvP menu. */
data class VTheme(val id: String, val displayName: String, val primary: Int, val accent: Int) {
    val primaryHex: String get() = hex(primary)
    val accentHex: String get() = hex(accent)

    companion object {
        fun hex(color: Int): String = String.format("#%06X", color and 0xFFFFFF)
    }
}

object ThemeManager {
    const val DEFAULT_ID = "neon"

    // Same ids and colours as the original dashboard's CSS variables.
    val all: List<VTheme> = listOf(
        VTheme("neon", "Neon Blue", 0xFF6366F1.toInt(), 0xFF818CF8.toInt()),
        VTheme("purple", "Meltida Purple", 0xFFA855F7.toInt(), 0xFFC084FC.toInt()),
        VTheme("emerald", "Flarial Emerald", 0xFF10B981.toInt(), 0xFF34D399.toInt()),
        VTheme("obsidian", "Obsidian Dark", 0xFF64748B.toInt(), 0xFF94A3B8.toInt())
    )

    fun byIdOrNull(id: String?): VTheme? = all.firstOrNull { it.id == id }

    fun byId(id: String?): VTheme = byIdOrNull(id) ?: all.first()

    /** Pure helper (unit tested): custom colours win when switched on and both are valid hex. */
    fun resolve(themeId: String?, customOn: Boolean, primaryHex: String, accentHex: String): VTheme {
        val base = byId(themeId)
        if (!customOn) return base
        val hexOk = Defaults.hexColor
        if (!hexOk.matches(primaryHex) || !hexOk.matches(accentHex)) return base
        return VTheme(
            "custom", "Custom",
            0xFF000000.toInt() or (primaryHex.substring(1).toInt(16)),
            0xFF000000.toInt() or (accentHex.substring(1).toInt(16))
        )
    }

    fun resolve(store: SettingsStore): VTheme = resolve(
        store.getString(Keys.THEME),
        store.getBool(Keys.THEME_CUSTOM_ON),
        store.getString(Keys.THEME_CUSTOM_PRIMARY),
        store.getString(Keys.THEME_CUSTOM_ACCENT)
    )
}

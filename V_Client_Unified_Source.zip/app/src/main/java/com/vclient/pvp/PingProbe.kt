package com.vclient.pvp

import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer

/**
 * Measures round-trip time to a server you type in. For a Bedrock server it sends the public RakNet
 * "unconnected ping" (the same packet the server list uses) and times the "unconnected pong".
 * With no server set it times a TCP connect to 1.1.1.1 (internet latency).
 * This is NOT Minecraft's internal ping value.
 */
class PingProbe {
    @Volatile var lastMs: Int = -1          // -1 = no result yet, -2 = no reply
    @Volatile var label: String = "Ping"
    @Volatile private var running = false
    @Volatile private var host: String = ""
    @Volatile private var port: Int = 19132
    private var thread: Thread? = null

    fun configure(h: String, p: Int) {
        host = h
        port = p
        label = if (h.isBlank()) "Internet ping" else "Server ping"
    }

    @Synchronized
    fun start() {
        if (running) return
        running = true
        val t = Thread { loop() }
        t.isDaemon = true
        thread = t
        t.start()
    }

    @Synchronized
    fun stop() {
        running = false
        thread?.interrupt()
        thread = null
    }

    private fun loop() {
        while (running) {
            lastMs = measure()
            try {
                Thread.sleep(2000L)
            } catch (e: InterruptedException) {
                break
            }
        }
    }

    private fun measure(): Int {
        val h = host
        return try {
            if (h.isBlank()) tcp("1.1.1.1", 443) else raknet(h, port)
        } catch (e: Exception) {
            -2
        }
    }

    private fun tcp(h: String, p: Int): Int {
        Socket().use { s ->
            val t = System.nanoTime()
            s.connect(InetSocketAddress(h, p), 2000)
            return ((System.nanoTime() - t) / 1_000_000L).toInt()
        }
    }

    private fun raknet(h: String, p: Int): Int {
        val addr = InetAddress.getByName(h)
        DatagramSocket().use { s ->
            s.soTimeout = 2000
            val data = buildPing(System.currentTimeMillis())
            val t = System.nanoTime()
            s.send(DatagramPacket(data, data.size, addr, p))
            val buf = ByteArray(1500)
            s.receive(DatagramPacket(buf, buf.size))
            if (buf[0].toInt() != 0x1c) return -2
            return ((System.nanoTime() - t) / 1_000_000L).toInt()
        }
    }

    fun text(): String {
        val ms = lastMs
        return when {
            ms >= 0 -> label + " " + ms + " ms"
            ms == -2 -> label + ": no reply"
            else -> label + ": ..."
        }
    }

    companion object {
        val MAGIC: ByteArray = byteArrayOf(
            0x00, 0xFF.toByte(), 0xFF.toByte(), 0x00,
            0xFE.toByte(), 0xFE.toByte(), 0xFE.toByte(), 0xFE.toByte(),
            0xFD.toByte(), 0xFD.toByte(), 0xFD.toByte(), 0xFD.toByte(),
            0x12, 0x34, 0x56, 0x78
        )

        /** RakNet ID_UNCONNECTED_PING: id(1) + time(8) + magic(16) + client guid(8) = 33 bytes. */
        fun buildPing(time: Long): ByteArray {
            val b = ByteBuffer.allocate(33)
            b.put(1.toByte())
            b.putLong(time)
            b.put(MAGIC)
            b.putLong(0x56434C49454E54L)
            return b.array()
        }
    }
}

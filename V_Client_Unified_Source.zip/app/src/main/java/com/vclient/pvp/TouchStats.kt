package com.vclient.pvp

import android.os.SystemClock

/**
 * Counts "a new touch started somewhere on the screen" events reported by the 1x1 "outside touch" window (see HudOverlay).
 * This is TOUCH CPS. It is NOT Minecraft attack CPS: it includes movement, jumping and menu taps, and Android reports an
 * outside touch only when a new touch gesture starts, so a second finger tapping attack while the first holds the joystick
 * may not be counted at all.
 */
object TouchStats {
    private val taps = CpsCounter()
    @Volatile private var lastAt = 0L

    fun tap() {
        taps.record()
        lastAt = SystemClock.elapsedRealtime()
    }

    fun cps(): Int = taps.current()
    fun max(): Int = taps.max
    fun total(): Long = taps.total

    /** Milliseconds since the last touch was reported, or -1 if none was ever received. */
    fun lastTapAgeMs(): Long = if (lastAt == 0L) -1L else SystemClock.elapsedRealtime() - lastAt

    fun reset() {
        taps.reset()
        lastAt = 0L
    }
}

package com.vclient.pvp

import android.content.Context
import android.util.Log
import org.json.JSONArray
import java.io.File

/** Named settings profiles ("configs") stored as small JSON files in the app's private storage. */
object ConfigProfiles {
    const val MAX_NAME = 32
    private const val EXT = ".json"

    fun dir(ctx: Context): File {
        val d = File(ctx.filesDir, "configs")
        d.mkdirs()
        return d
    }

    /** Letters, digits, space, dash and underscore only; trimmed and capped. Empty result means invalid. */
    fun safeName(raw: String): String =
        raw.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().take(MAX_NAME).trim()

    fun names(ctx: Context): List<String> =
        dir(ctx).listFiles()
            ?.filter { it.isFile && it.name.endsWith(EXT) }
            ?.map { it.name.removeSuffix(EXT) }
            ?.sortedBy { it.lowercase() }
            ?: emptyList()

    fun save(ctx: Context, rawName: String, json: String): Boolean {
        val name = safeName(rawName)
        if (name.isEmpty()) return false
        return try {
            File(dir(ctx), name + EXT).writeText(json)
            true
        } catch (e: Exception) {
            Log.w("VClientConfigs", "save failed", e)
            false
        }
    }

    fun read(ctx: Context, rawName: String): String? {
        val name = safeName(rawName)
        if (name.isEmpty()) return null
        val f = File(dir(ctx), name + EXT)
        return try { if (f.isFile) f.readText() else null } catch (e: Exception) { null }
    }

    fun delete(ctx: Context, rawName: String): Boolean {
        val name = safeName(rawName)
        if (name.isEmpty()) return false
        return File(dir(ctx), name + EXT).delete()
    }

    fun toJson(ctx: Context): String {
        val arr = JSONArray()
        names(ctx).forEach { arr.put(it) }
        return arr.toString()
    }
}

package com.vclient.pvp

/**
 * Counts events inside a sliding time window. Pure Kotlin so it can be unit tested on the JVM.
 * IMPORTANT: it counts whatever you feed it. In V CLIENT it is only fed by taps on the overlay
 * touch pad - never by Minecraft input.
 */
class CpsCounter(
    private val windowMs: Long = 1000L,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    private val stamps = ArrayDeque<Long>()
    private var totalCount = 0L
    private var maxCount = 0

    val total: Long
        @Synchronized get() = totalCount
    val max: Int
        @Synchronized get() = maxCount

    @Synchronized
    fun record() {
        val now = clock()
        prune(now)
        stamps.addLast(now)
        totalCount++
        if (stamps.size > maxCount) maxCount = stamps.size
    }

    @Synchronized
    fun current(): Int {
        prune(clock())
        return stamps.size
    }

    @Synchronized
    fun reset() {
        stamps.clear()
        totalCount = 0L
        maxCount = 0
    }

    private fun prune(now: Long) {
        while (stamps.isNotEmpty() && now - stamps.first() >= windowMs) {
            stamps.removeFirst()
        }
    }
}

package com.vclient.pvp

import android.content.Context
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class AddonResult(val ok: Boolean, val message: String, val file: File? = null)

/**
 * Builds the V CLIENT in-game add-on (.mcaddon = a zip holding one behavior pack with Script API code) on the phone,
 * with the user's module switches baked in. The JavaScript lives in assets/addon/ and is tested with Node in CI.
 * The pieces that need no Android classes (manifest, config, zip) are plain functions so they can be unit tested.
 */
object AddonBuilder {
    const val FILE_NAME = "V_CLIENT_Stats.mcaddon"
    private const val FOLDER = "V_CLIENT_Stats_BP"
    private const val ASSET_ROOT = "addon/"
    private const val PREFS = "v_client_addon" // separate from settings so "reset" never lowers the build number

    /** Static script files copied from assets. generated_config.js is produced from the settings instead. */
    val staticFiles: List<String> = listOf(
        "scripts/main.js",
        "scripts/lib/cps.js",
        "scripts/lib/combo.js",
        "scripts/lib/format.js",
        "scripts/lib/defaults.js"
    )

    fun deterministicUuid(seed: String): String = UUID.nameUUIDFromBytes(seed.toByteArray(Charsets.UTF_8)).toString()

    fun isValidApiVersion(v: String): Boolean = Defaults.apiVersion.matches(v)

    /** Higher pack versions replace older imports, so the third number is the build counter. */
    fun manifestJson(apiVersion: String, build: Int, minEngine: List<Int> = listOf(1, 21, 0)): String {
        val ver = "[1, 0, $build]"
        val eng = minEngine.joinToString(", ", "[", "]")
        return """{
  "format_version": 2,
  "header": {
    "name": "V CLIENT Stats",
    "description": "In-game stats from V CLIENT (personal and hosted worlds only)",
    "uuid": "${deterministicUuid("vclient.stats.bp.header")}",
    "version": $ver,
    "min_engine_version": $eng
  },
  "modules": [
    {
      "type": "script",
      "language": "javascript",
      "uuid": "${deterministicUuid("vclient.stats.bp.script")}",
      "version": $ver,
      "entry": "scripts/main.js"
    }
  ],
  "dependencies": [
    { "module_name": "@minecraft/server", "version": "$apiVersion" }
  ]
}
"""
    }

    fun configJs(modules: Map<String, Boolean>, intervalTicks: Int, diagnostic: Boolean): String {
        val mods = Addon.ids.joinToString(", ") { id -> id + ": " + (modules[id] == true) }
        return "export const CONFIG = {\n" +
            "  modules: { " + mods + " },\n" +
            "  intervalTicks: " + intervalTicks + ",\n" +
            "  diagnostic: " + diagnostic + "\n" +
            "};\n"
    }

    fun zipBytes(entries: Map<String, ByteArray>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z ->
            for ((name, data) in entries) {
                z.putNextEntry(ZipEntry(name))
                z.write(data)
                z.closeEntry()
            }
        }
        return bos.toByteArray()
    }

    /** Builds the full entry map. [loadAsset] returns the bytes of a file under assets/addon/. */
    fun buildEntries(
        apiVersion: String,
        build: Int,
        modules: Map<String, Boolean>,
        intervalTicks: Int,
        diagnostic: Boolean,
        loadAsset: (String) -> ByteArray
    ): Map<String, ByteArray> {
        val m = LinkedHashMap<String, ByteArray>()
        m["$FOLDER/manifest.json"] = manifestJson(apiVersion, build).toByteArray(Charsets.UTF_8)
        m["$FOLDER/scripts/generated_config.js"] = configJs(modules, intervalTicks, diagnostic).toByteArray(Charsets.UTF_8)
        for (f in staticFiles) m["$FOLDER/$f"] = loadAsset(f)
        return m
    }

    fun build(ctx: Context): AddonResult {
        val store = SettingsStore(ctx)
        val api = store.getString(Keys.ADDON_API_VERSION).trim()
        if (!isValidApiVersion(api)) {
            return AddonResult(false, "Enter the Script API module version first, for example 2.9.0. It depends on your Minecraft version.")
        }
        val modules = Addon.ids.associateWith { store.getBool(Addon.keyOn(it)) }
        if (modules.values.none { it }) {
            return AddonResult(false, "Switch on at least one World add-on module first.")
        }
        return try {
            val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val build = prefs.getInt("build", 0) + 1
            val entries = buildEntries(api, build, modules, store.getInt(Keys.ADDON_INTERVAL), store.getBool(Keys.ADDON_DIAG)) { path ->
                ctx.assets.open(ASSET_ROOT + path).use { it.readBytes() }
            }
            val out = File(PackLibrary.dir(ctx), FILE_NAME)
            out.writeBytes(zipBytes(entries))
            prefs.edit().putInt("build", build).apply()
            AddonResult(true, "Built " + FILE_NAME + " (build " + build + ", " + modules.values.count { it } + " modules). Now send it to Minecraft.", out)
        } catch (e: Exception) {
            AddonResult(false, "Could not build the add-on: " + (e.message ?: e.javaClass.simpleName))
        }
    }

    fun send(ctx: Context): AddonResult {
        val f = PackLibrary.find(ctx, FILE_NAME) ?: return AddonResult(false, "Build the add-on first.")
        val mc = MinecraftDetector.primary(MinecraftDetector.detectAll(ctx))
            ?: return AddonResult(false, "Minecraft was not found on this phone.")
        PackSender.send(ctx, listOf(f), mc.packageName)
        return AddonResult(true, "Sent to Minecraft. Import it there, then enable it under your world's Behavior Packs.", f)
    }

    fun infoJson(ctx: Context): String {
        val mc = MinecraftDetector.primary(MinecraftDetector.detectAll(ctx))
        val store = SettingsStore(ctx)
        val built = PackLibrary.find(ctx, FILE_NAME) != null
        return JSONObject()
            .put("built", built)
            .put("sent", PackLibrary.isSent(ctx, FILE_NAME))
            .put("build", ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt("build", 0))
            .put("enabled", Addon.ids.count { store.getBool(Addon.keyOn(it)) })
            .put("minecraft", mc?.versionName ?: JSONObject.NULL)
            .toString()
    }
}

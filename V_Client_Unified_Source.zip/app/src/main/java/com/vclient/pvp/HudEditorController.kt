package com.vclient.pvp

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast

/**
 * The HUD editor: a full-screen window (separate from the side menu) with a preview of the Minecraft screen, drag and resize
 * handles, per-element controls and profile management. It exists only while it is open: when closed there is no window and no
 * WebView, so it costs nothing during play and cannot block the game.
 */
class HudEditorController(
    private val ctx: Context,
    private val wm: WindowManager,
    private val host: BridgeHost
) {
    private var root: FrameLayout? = null
    private var web: WebView? = null
    private var pageLoaded = false
    private var pendingSelect: String? = null

    val isShowing: Boolean get() = root != null

    /** [select] optionally pre-selects an element (opened from a module card). */
    fun show(select: String?) {
        if (root != null) return
        val themed = ContextThemeWrapper(ctx, R.style.Theme_VClient)
        val wv = try {
            WebView(themed)
        } catch (e: Exception) {
            Log.e(TAG, "WebView unavailable", e)
            Toast.makeText(ctx, "WebView is unavailable on this device.", Toast.LENGTH_LONG).show()
            return
        }
        wv.settings.javaScriptEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.setBackgroundColor(Color.parseColor("#0B1020"))
        pendingSelect = select
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
            override fun onPageFinished(view: WebView?, url: String?) {
                pageLoaded = true
                val s = pendingSelect
                if (s != null) {
                    view?.evaluateJavascript("window.VEditor&&VEditor.select(" + org.json.JSONObject.quote(s) + ")", null)
                    pendingSelect = null
                }
            }
        }
        wv.addJavascriptInterface(VBridge(ctx, host), "VBridge")
        pageLoaded = false
        wv.loadUrl("file:///android_asset/hud_editor.html")

        val container = object : FrameLayout(themed) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) host.closeHudEditor()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        container.addView(wv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        Ui.applyCutout(lp)
        try {
            wm.addView(container, lp)
        } catch (e: Exception) {
            Log.e(TAG, "addView failed", e)
            wv.destroy()
            return
        }
        root = container
        web = wv
        container.requestFocus()
    }

    /** Screen size or orientation changed: the page recomputes its preview. */
    fun onRotate() {
        if (pageLoaded) web?.evaluateJavascript("window.VEditor&&VEditor.onRotate()", null)
    }

    fun hide() {
        val r = root
        val w = web
        root = null
        web = null
        pageLoaded = false
        if (r != null) {
            try { wm.removeView(r) } catch (e: Exception) { /* already removed */ }
        }
        if (w != null) {
            try {
                w.stopLoading()
                w.removeJavascriptInterface("VBridge")
                w.destroy()
            } catch (e: Exception) {
                Log.w(TAG, "WebView destroy", e)
            }
        }
    }

    private companion object {
        const val TAG = "VClientHudEditor"
    }
}

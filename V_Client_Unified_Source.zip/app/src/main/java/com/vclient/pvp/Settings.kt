package com.vclient.pvp

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

object Keys {
    const val THEME = "theme"
    const val WORLD_MODE = "world_mode"          // auto | public | personal (what the user is playing on)
    const val ADDON_API_VERSION = "addon_api_version" // @minecraft/server version for the add-on manifest (depends on the game version)
    const val ADDON_DIAG = "addon_diag"          // add-on shows raw diagnostic values
    const val ADDON_INTERVAL = "addon_interval"  // in-game HUD refresh, in ticks
    const val THEME_CUSTOM_ON = "theme_custom_on"      // use the two colours below instead of the preset
    const val THEME_CUSTOM_PRIMARY = "theme_custom_primary"
    const val THEME_CUSTOM_ACCENT = "theme_custom_accent"
    const val ICON_SIDE = "icon_side"          // 0 = left edge, 1 = right edge
    const val ICON_Y_FRAC = "icon_y_frac"      // 0..1 of the free vertical range
    const val ICON_X_FRAC = "icon_x_frac"      // 0..1 of the free horizontal range (the icon can sit anywhere)
    const val ICON_SNAP = "icon_snap"          // optional: snap to the nearest side edge after dragging
    const val HUD_SIZE = "hud_size"
    const val HUD_OPACITY = "hud_opacity"
    const val HUD_COLOR = "hud_color"
    const val HUD_CUSTOM_TEXT = "hud_custom_text"
    const val HUD_EDIT = "hud_edit"            // drag-to-place mode, always reset when the overlay starts
    const val XH_ENABLED = "xh_enabled"
    const val XH_SHAPE = "xh_shape"
    const val XH_SIZE = "xh_size"
    const val XH_THICK = "xh_thick"
    const val XH_GAP = "xh_gap"
    const val XH_OPACITY = "xh_opacity"
    const val XH_COLOR = "xh_color"
    const val XH_DX = "xh_dx"
    const val XH_DY = "xh_dy"
    const val XH_OUTLINE = "xh_outline"
    const val XH_DOT = "xh_dot"
    const val PING_HOST = "ping_host"
    const val PING_PORT = "ping_port"
    const val ONLY_IN_GAME = "only_in_game"
    const val AUTO_START = "auto_start"
    const val AUTO_SEND_PACKS = "auto_send_packs"
    const val DND_ON = "dnd_on"
    const val SMOOTH_ANIM = "smooth_anim"
    const val LITE_UI = "lite_ui"
    const val KEEP_SCREEN_ON = "keep_screen_on"
}

/** In-game modules delivered by the V CLIENT add-on (Script API). Each has its own on/off switch. */
object Addon {
    val ids: List<String> = listOf("coords", "direction", "armor", "keystrokes", "attack_cps", "combo")
    fun keyOn(id: String) = "ao_" + id + "_on"
}

/** Modules that need the native (in-game) tier. Switches exist but stay locked until native support is verified. */
object Native {
    val ids: List<String> = listOf("fps", "frame_time", "zoom", "hit_counter", "target", "combat_stats", "freelook")
    fun keyOn(id: String) = "nt_" + id + "_on"
}

/** Every HUD item is its own overlay widget with its own on/off switch and position (percent of the screen). */
object Widgets {
    // New elements are appended so the default positions of the existing ones do not change.
    // fps, attack_cps, coords, direction, keystrokes, armor and combo have NO live data source in the overlay: they show a
    // clear "Needs Native Integration" status and are placeable. They never show an invented value.
    val ids: List<String> = listOf(
        "battery", "clock", "ram", "storage", "refresh", "uptime", "ping", "cps", "custom",
        "fps", "attack_cps", "coords", "direction", "keystrokes", "armor", "combo"
    )
    val labels: Map<String, String> = mapOf(
        "battery" to "Battery",
        "clock" to "Clock",
        "ram" to "Free RAM",
        "storage" to "Free storage",
        "refresh" to "Display refresh",
        "uptime" to "Overlay time",
        "ping" to "Server ping",
        "cps" to "Touch CPS",
        "custom" to "Custom text",
        "fps" to "FPS",
        "attack_cps" to "Attack CPS",
        "coords" to "Coordinates",
        "direction" to "Direction",
        "keystrokes" to "Keystrokes",
        "armor" to "Armor HUD",
        "combo" to "Combo counter"
    )

    fun keyOn(id: String) = "w_" + id + "_on"
    fun keyX(id: String) = "w_" + id + "_x"
    fun keyY(id: String) = "w_" + id + "_y"
}

object Defaults {
    val values: Map<String, Any> = linkedMapOf<String, Any>().also { m ->
        m[Keys.THEME] = ThemeManager.DEFAULT_ID
        m[Keys.WORLD_MODE] = "auto"
        m[Keys.ADDON_API_VERSION] = ""
        m[Keys.ADDON_DIAG] = false
        m[Keys.ADDON_INTERVAL] = 2
        Addon.ids.forEach { id -> m[Addon.keyOn(id)] = false }
        Native.ids.forEach { id -> m[Native.keyOn(id)] = false }
        m[Keys.THEME_CUSTOM_ON] = false
        m[Keys.THEME_CUSTOM_PRIMARY] = "#6366F1"
        m[Keys.THEME_CUSTOM_ACCENT] = "#818CF8"
        m[Keys.ICON_SIDE] = 1
        m[Keys.ICON_Y_FRAC] = 0.35f
        m[Keys.ICON_X_FRAC] = 1f
        m[Keys.ICON_SNAP] = false
        m[Keys.HUD_SIZE] = 14
        m[Keys.HUD_OPACITY] = 85
        m[Keys.HUD_COLOR] = "#FFFFFF"
        m[Keys.HUD_CUSTOM_TEXT] = "V CLIENT"
        m[Keys.HUD_EDIT] = false
        m[Keys.XH_ENABLED] = false
        m[Keys.XH_SHAPE] = "cross"
        m[Keys.XH_SIZE] = 20
        m[Keys.XH_THICK] = 2
        m[Keys.XH_GAP] = 4
        m[Keys.XH_OPACITY] = 100
        m[Keys.XH_COLOR] = "#00FF66"
        m[Keys.XH_DX] = 0
        m[Keys.XH_DY] = 0
        m[Keys.XH_OUTLINE] = true
        m[Keys.XH_DOT] = false
        m[Keys.PING_HOST] = ""
        m[Keys.PING_PORT] = 19132
        m[Keys.ONLY_IN_GAME] = true
        m[Keys.AUTO_START] = true
        m[Keys.AUTO_SEND_PACKS] = true
        m[Keys.DND_ON] = false
        m[Keys.SMOOTH_ANIM] = true
        m[Keys.LITE_UI] = true
        m[Keys.KEEP_SCREEN_ON] = false
        Widgets.ids.forEachIndexed { i, id ->
            m[Widgets.keyOn(id)] = (id == "battery" || id == "clock")
            m[Widgets.keyX(id)] = 2 + (i / 5) * 24
            m[Widgets.keyY(id)] = 4 + (i % 5) * 12
        }
    }

    val intRanges: Map<String, IntRange> = linkedMapOf<String, IntRange>().also { m ->
        m[Keys.ICON_SIDE] = 0..1
        m[Keys.ADDON_INTERVAL] = 1..20
        m[Keys.HUD_SIZE] = 10..28
        m[Keys.HUD_OPACITY] = 20..100
        m[Keys.XH_SIZE] = 6..60
        m[Keys.XH_THICK] = 1..10
        m[Keys.XH_GAP] = 0..20
        m[Keys.XH_OPACITY] = 10..100
        m[Keys.XH_DX] = -100..100
        m[Keys.XH_DY] = -100..100
        m[Keys.PING_PORT] = 1..65535
        Widgets.ids.forEach { id ->
            m[Widgets.keyX(id)] = 0..95
            m[Widgets.keyY(id)] = 0..95
        }
    }

    val worldModes: Set<String> = setOf("auto", "public", "personal")
    val apiVersion = Regex("^\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$")
    val shapes: Set<String> = setOf("cross", "plus", "dot", "circle", "square")
    val hexColor = Regex("^#[0-9A-Fa-f]{6}$")
    val hostName = Regex("^[A-Za-z0-9.-]{0,100}$")
}

/** Persistent settings shared by the dashboard, the floating icon, the HUD, the crosshair and the PvP menu. */
class SettingsStore(context: Context) {
    val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("v_client_settings", Context.MODE_PRIVATE)

    fun getBool(key: String): Boolean {
        val def = Defaults.values[key] as Boolean
        return try { prefs.getBoolean(key, def) } catch (e: ClassCastException) { def }
    }

    fun getInt(key: String): Int {
        val def = Defaults.values[key] as Int
        return try { prefs.getInt(key, def) } catch (e: ClassCastException) { def }
    }

    fun getFloat(key: String): Float {
        val def = Defaults.values[key] as Float
        return try { prefs.getFloat(key, def) } catch (e: ClassCastException) { def }
    }

    fun getString(key: String): String {
        val def = Defaults.values[key] as String
        return try { prefs.getString(key, def) ?: def } catch (e: ClassCastException) { def }
    }

    fun getAsString(key: String): String = when (Defaults.values[key]) {
        is Boolean -> getBool(key).toString()
        is Int -> getInt(key).toString()
        is Float -> getFloat(key).toString()
        is String -> getString(key)
        else -> ""
    }

    /** Validates and stores a value coming from JavaScript. Returns false if it was rejected. */
    fun setFromString(key: String, raw: String): Boolean {
        val def = Defaults.values[key] ?: return false
        val editor = prefs.edit()
        when (def) {
            is Boolean -> {
                val v = raw.toBooleanStrictOrNull() ?: return false
                editor.putBoolean(key, v)
            }
            is Int -> {
                val n = raw.toIntOrNull() ?: return false
                val range = Defaults.intRanges[key]
                editor.putInt(key, if (range != null) n.coerceIn(range.first, range.last) else n)
            }
            is Float -> {
                val f = raw.toFloatOrNull() ?: return false
                editor.putFloat(key, f.coerceIn(0f, 1f))
            }
            is String -> {
                val v = validateString(key, raw) ?: return false
                editor.putString(key, v)
            }
            else -> return false
        }
        editor.apply()
        return true
    }

    private fun validateString(key: String, raw: String): String? = when (key) {
        Keys.THEME -> ThemeManager.byIdOrNull(raw)?.id
        Keys.HUD_COLOR, Keys.XH_COLOR, Keys.THEME_CUSTOM_PRIMARY, Keys.THEME_CUSTOM_ACCENT -> if (Defaults.hexColor.matches(raw)) raw.uppercase() else null
        Keys.WORLD_MODE -> if (raw in Defaults.worldModes) raw else null
        Keys.ADDON_API_VERSION -> raw.trim().let { if (it.isEmpty() || Defaults.apiVersion.matches(it)) it else null }
        Keys.XH_SHAPE -> if (raw in Defaults.shapes) raw else null
        Keys.PING_HOST -> raw.trim().let { if (Defaults.hostName.matches(it)) it else null }
        Keys.HUD_CUSTOM_TEXT -> raw.filter { !it.isISOControl() }.take(40)
        else -> null
    }

    /** Settings as JSON for the user to keep (no theme list). */
    fun toBackupJson(): String {
        val o = JSONObject(toJson())
        o.remove("themes")
        return o.toString(2)
    }

    /** Applies every known, valid key found in [text]. Returns how many values were applied. */
    fun importJson(text: String): Int {
        val o = try { JSONObject(text) } catch (e: Exception) { return 0 }
        var n = 0
        for (key in Defaults.values.keys) {
            if (o.has(key) && setFromString(key, o.get(key).toString())) n++
        }
        return n
    }

    fun resetAll() {
        prefs.edit().clear().apply()
    }

    fun toJson(): String {
        val o = JSONObject()
        for (key in Defaults.values.keys) {
            when (Defaults.values[key]) {
                is Boolean -> o.put(key, getBool(key))
                is Int -> o.put(key, getInt(key))
                is Float -> o.put(key, getFloat(key).toDouble())
                is String -> o.put(key, getString(key))
            }
        }
        val themes = JSONArray()
        for (t in ThemeManager.all) {
            themes.put(
                JSONObject()
                    .put("id", t.id)
                    .put("name", t.displayName)
                    .put("primary", t.primaryHex)
                    .put("accent", t.accentHex)
            )
        }
        o.put("themes", themes)
        return o.toString()
    }
}

package com.vclient.pvp

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import org.json.JSONArray
import org.json.JSONObject

data class MinecraftInfo(
    val packageName: String,
    val label: String,
    val versionName: String,
    val hasLaunchIntent: Boolean,
    val isOfficialPackageName: Boolean
)

/**
 * Detects Minecraft-like launcher apps. Sideloaded builds can use any package name, so this is a
 * best-effort heuristic (package or label contains "minecraft"/"mojang"). It never claims that
 * a detected build is compatible with anything.
 */
object MinecraftDetector {
    const val OFFICIAL_PACKAGE = "com.mojang.minecraftpe"

    fun looksLikeMinecraft(pkg: String, label: String): Boolean =
        pkg.contains("minecraft", ignoreCase = true) ||
            pkg.contains("mojang", ignoreCase = true) ||
            label.contains("minecraft", ignoreCase = true)

    @Suppress("DEPRECATION")
    fun detectAll(ctx: Context): List<MinecraftInfo> {
        val pm = ctx.packageManager
        val found = LinkedHashMap<String, MinecraftInfo>()
        try {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            for (ri in pm.queryIntentActivities(main, 0)) {
                val pkg = ri.activityInfo?.packageName ?: continue
                val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
                if (looksLikeMinecraft(pkg, label)) found[pkg] = describe(pm, pkg, label)
            }
        } catch (e: Exception) {
            // Package visibility restricted; fall through to the explicit official-package check.
        }
        if (!found.containsKey(OFFICIAL_PACKAGE)) {
            try {
                pm.getPackageInfo(OFFICIAL_PACKAGE, 0)
                found[OFFICIAL_PACKAGE] = describe(pm, OFFICIAL_PACKAGE, "Minecraft")
            } catch (e: PackageManager.NameNotFoundException) {
                // not installed
            } catch (e: Exception) {
                // not visible
            }
        }
        return found.values.toList()
    }

    @Suppress("DEPRECATION")
    private fun describe(pm: PackageManager, pkg: String, label: String): MinecraftInfo {
        val version = try { pm.getPackageInfo(pkg, 0).versionName ?: "Unknown" } catch (e: Exception) { "Unavailable" }
        val launch = try { pm.getLaunchIntentForPackage(pkg) != null } catch (e: Exception) { false }
        return MinecraftInfo(pkg, label, version, launch, pkg == OFFICIAL_PACKAGE)
    }

    fun primary(all: List<MinecraftInfo>): MinecraftInfo? =
        all.firstOrNull { it.isOfficialPackageName && it.hasLaunchIntent }
            ?: all.firstOrNull { it.hasLaunchIntent }
            ?: all.firstOrNull()

    private fun toJson(i: MinecraftInfo): JSONObject = JSONObject()
        .put("package", i.packageName)
        .put("label", i.label)
        .put("version", i.versionName)
        .put("hasLaunchIntent", i.hasLaunchIntent)
        .put("officialPackageName", i.isOfficialPackageName)

    fun statusJson(ctx: Context): String {
        val all = detectAll(ctx)
        val p = primary(all)
        val o = JSONObject()
        o.put("status", if (p == null) "not_detected" else "detected")
        o.put("primary", if (p == null) JSONObject.NULL else toJson(p))
        val arr = JSONArray()
        all.forEach { arr.put(toJson(it)) }
        o.put("all", arr)
        o.put(
            "note",
            "Detection only reads package info. It does not verify compatibility, signature or game state."
        )
        return o.toString()
    }

    /** Launches the detected build through its normal launcher intent. Returns false if impossible. */
    fun launch(ctx: Context): Boolean {
        val p = primary(detectAll(ctx)) ?: return false
        if (!p.hasLaunchIntent) return false
        return try {
            val intent = ctx.packageManager.getLaunchIntentForPackage(p.packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }
}

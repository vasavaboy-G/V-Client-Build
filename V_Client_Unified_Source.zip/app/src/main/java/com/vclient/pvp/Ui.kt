package com.vclient.pvp

import android.content.Context
import android.graphics.Color
import android.graphics.Point
import android.os.Build
import android.util.DisplayMetrics
import android.view.WindowManager

object Ui {
    fun dp(ctx: Context, v: Float): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    /** Full real screen size in the current orientation. */
    @Suppress("DEPRECATION")
    fun screen(wm: WindowManager): Point {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            Point(b.width(), b.height())
        } else {
            val dm = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(dm)
            Point(dm.widthPixels, dm.heightPixels)
        }
    }

    /**
     * Lets an overlay window use the whole physical screen, including the camera cut-out area. Without this, on phones with a
     * notch the overlay coordinate system is shifted compared with the game in landscape, so HUD items and the crosshair
     * would sit in the wrong place.
     */
    fun applyCutout(lp: WindowManager.LayoutParams) {
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
    }

    fun parseColor(hex: String, fallback: Int): Int =
        try { Color.parseColor(hex) } catch (e: IllegalArgumentException) { fallback }

    fun withOpacity(color: Int, percent: Int): Int {
        val a = (percent.coerceIn(0, 100) * 255 / 100)
        return (color and 0x00FFFFFF) or (a shl 24)
    }
}

package com.vclient.pvp

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface

/** Implemented by whoever hosts a WebView (MainActivity for the dashboard, the service for the menu). */
interface BridgeHost {
    fun closeMenu() {}
    fun onReset() {}
    fun toggleOverlay() {}
    fun launchMinecraft() {}
    fun overlayState(): String = "{\"granted\":false,\"running\":false}"
    fun importPack(type: String) {}
    fun openFiles() {}
    fun backupSettings() {}
    fun restoreSettings() {}
    fun saveSkin(name: String, dataUrl: String) {}
    fun sendPack(name: String) {}
    fun sendAllPacks() {}
    fun openHudEditor(select: String?) {}
    fun closeHudEditor() {}
}

/**
 * JavaScript bridge, exposed as window.VBridge. It is only ever attached to WebViews that load
 * local assets; the dashboard WebView blocks navigation to remote pages.
 */
class VBridge(private val ctx: Context, private val host: BridgeHost) {
    private val store = SettingsStore(ctx)
    private val main = Handler(Looper.getMainLooper())

    @JavascriptInterface fun getSettings(): String = store.toJson()
    @JavascriptInterface fun getSetting(key: String): String = store.getAsString(key)
    @JavascriptInterface fun setSetting(key: String, value: String): Boolean = store.setFromString(key, value)

    @JavascriptInterface fun resetDefaults() {
        store.resetAll()
        main.post { host.onReset() }
    }

    @JavascriptInterface fun getDevice(): String = DeviceTelemetry.toJson(ctx)
    @JavascriptInterface fun getMinecraft(): String = MinecraftDetector.statusJson(ctx)
    @JavascriptInterface fun getAccess(): String = host.overlayState()
    @JavascriptInterface fun getTapStats(): String = "{\"cps\":" + TouchStats.cps() + ",\"max\":" + TouchStats.max() + "}"

    @JavascriptInterface fun requestUsageAccess() { main.post { Access.openUsageSettings(ctx) } }
    @JavascriptInterface fun requestDndAccess() { main.post { Access.openDndSettings(ctx) } }

    @JavascriptInterface fun closeMenu() { main.post { host.closeMenu() } }
    @JavascriptInterface fun toggleOverlay() { main.post { host.toggleOverlay() } }
    @JavascriptInterface fun launchMinecraft() { main.post { host.launchMinecraft() } }
    @JavascriptInterface fun getOverlayState(): String = host.overlayState()
    @JavascriptInterface fun importPack(type: String) { main.post { host.importPack(type) } }
    @JavascriptInterface fun openFiles() { main.post { host.openFiles() } }
    @JavascriptInterface fun backupSettings() { main.post { host.backupSettings() } }
    @JavascriptInterface fun restoreSettings() { main.post { host.restoreSettings() } }
    @JavascriptInterface fun saveSkin(name: String, dataUrl: String) { main.post { host.saveSkin(name, dataUrl) } }

    // ---- HUD editor and HUD profiles (all values are validated and clamped by HudJson / HudProfiles) ----
    private val hud: HudProfiles get() = HudStore.get(ctx)

    @JavascriptInterface fun getScreenInfo(): String {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        val s = Ui.screen(wm)
        return org.json.JSONObject()
            .put("w", s.x).put("h", s.y)
            .put("density", ctx.resources.displayMetrics.density.toDouble())
            .put("landscape", HudGeometry.isLandscape(s.x, s.y))
            .toString()
    }

    /** Active profile: its name, all profile names, and every element with its look and both positions. */
    @JavascriptInterface fun getHudLayout(): String {
        val o = org.json.JSONObject(hud.activeJson())
        val st = org.json.JSONObject()
        for (id in Widgets.ids) {
            st.put(id, org.json.JSONObject()
                .put("label", Widgets.labels[id] ?: id)
                .put("status", GameData.status(id))
                .put("on", store.getBool(Widgets.keyOn(id))))
        }
        o.put("info", st)
        return o.toString()
    }

    @JavascriptInterface fun setHudElement(id: String, json: String): Boolean {
        if (id !in Widgets.ids) return false
        return try {
            val base = hud.element(id)
            hud.setElement(id, HudJson.elementFromJson(id, org.json.JSONObject(json), base))
            main.post { HudStore.changed() }
            true
        } catch (e: Exception) { false }
    }

    @JavascriptInterface fun resetHudElement(id: String): Boolean {
        if (id !in Widgets.ids) return false
        hud.resetElement(id)
        main.post { HudStore.changed() }
        return true
    }

    @JavascriptInterface fun resetHudLayout(): Boolean {
        hud.resetActive()
        main.post { HudStore.changed() }
        return true
    }

    @JavascriptInterface fun createHudProfile(name: String): Boolean = hud.create(name)
    @JavascriptInterface fun duplicateHudProfile(name: String, newName: String): Boolean = hud.duplicate(name, newName)
    @JavascriptInterface fun renameHudProfile(old: String, newName: String): Boolean = hud.rename(old, newName)
    @JavascriptInterface fun deleteHudProfile(name: String): Boolean {
        val ok = hud.delete(name)
        if (ok) main.post { HudStore.changed() }
        return ok
    }
    @JavascriptInterface fun switchHudProfile(name: String): Boolean {
        val ok = hud.switchTo(name)
        if (ok) main.post { HudStore.changed() }
        return ok
    }
    @JavascriptInterface fun exportHudProfile(name: String): String = hud.exportText(name) ?: ""
    @JavascriptInterface fun importHudProfile(text: String, name: String): String = hud.importText(text, name) ?: ""

    @JavascriptInterface fun openHudEditor(select: String) { main.post { host.openHudEditor(if (select.isEmpty()) null else select) } }
    @JavascriptInterface fun closeHudEditor() { main.post { host.closeHudEditor() } }

    @JavascriptInterface fun getTouchStatus(): String =
        org.json.JSONObject().put("total", TouchStats.total()).put("lastAgeMs", TouchStats.lastTapAgeMs()).toString()

    @JavascriptInterface fun getModules(): String = ModuleRegistry.toJson(
        WorldMode.from(store.getString(Keys.WORLD_MODE)),
        PackLibrary.isSent(ctx, AddonBuilder.FILE_NAME),
        NativeCapability.current(ctx)
    )

    // ---- Native tier: status and read-only readiness probe ----
    @JavascriptInterface fun getNativeStatus(): String {
        val st = NativeCapability.current(ctx)
        return org.json.JSONObject()
            .put("code", st.code).put("text", st.text).put("verified", st.verified)
            .put("tierImplemented", NativeCapability.TIER_IMPLEMENTED)
            .put("libLoaded", NativeBridge.loaded)
            .put("libError", NativeBridge.loadError ?: org.json.JSONObject.NULL)
            .toString()
    }
    @JavascriptInterface fun runNativeProbe(): String = NativeProbe.run(ctx)
    @JavascriptInterface fun shareText(text: String): Boolean = try {
        val send = android.content.Intent(android.content.Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(android.content.Intent.EXTRA_TEXT, text)
        val chooser = android.content.Intent.createChooser(send, "Share report")
        chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(chooser)
        true
    } catch (e: Exception) { false }

    // ---- World add-on (Script API behavior pack built on the phone) ----
    @JavascriptInterface fun getAddonInfo(): String = AddonBuilder.infoJson(ctx)
    @JavascriptInterface fun buildAddon(): String = resultJson(AddonBuilder.build(ctx))
    @JavascriptInterface fun sendAddon(): String = resultJson(AddonBuilder.send(ctx))
    private fun resultJson(r: AddonResult): String =
        org.json.JSONObject().put("ok", r.ok).put("message", r.message).toString()

    // ---- Saved servers: Minecraft's own minecraft:// links do the adding and joining ----
    @JavascriptInterface fun getServers(): String = ServerLibrary.toJson(ctx)
    @JavascriptInterface fun addServer(name: String, host: String, port: Int): Boolean = ServerLibrary.add(ctx, name, host, port)
    @JavascriptInterface fun removeServer(index: Int): Boolean = ServerLibrary.remove(ctx, index)
    /** action = "add" (save into Minecraft's server list) or "join". Best effort: Minecraft may open another screen. */
    @JavascriptInterface fun openServer(index: Int, action: String): Boolean {
        val s = ServerLibrary.list(ctx).getOrNull(index) ?: return false
        val uri = if (action == "join") ServerLinks.connectUri(s) else ServerLinks.addServerUri(s)
        return try {
            val i = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(uri))
            MinecraftDetector.primary(MinecraftDetector.detectAll(ctx))?.let { i.setPackage(it.packageName) }
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface fun getProfiles(): String = ConfigProfiles.toJson(ctx)
    @JavascriptInterface fun saveProfile(name: String): Boolean = ConfigProfiles.save(ctx, name, store.toBackupJson())
    @JavascriptInterface fun deleteProfile(name: String): Boolean = ConfigProfiles.delete(ctx, name)
    /** Applies a saved profile. Returns how many settings were applied (0 = not found or empty). */
    @JavascriptInterface fun loadProfile(name: String): Int {
        val text = ConfigProfiles.read(ctx, name) ?: return 0
        val n = store.importJson(text)
        if (n > 0) main.post { host.onReset() }
        return n
    }

    @JavascriptInterface fun getPacks(): String = PackLibrary.toJson(ctx)
    @JavascriptInterface fun removePack(name: String) { PackLibrary.remove(ctx, name) }
    @JavascriptInterface fun sendPack(name: String) { main.post { host.sendPack(name) } }
    @JavascriptInterface fun sendAllPacks() { main.post { host.sendAllPacks() } }
}

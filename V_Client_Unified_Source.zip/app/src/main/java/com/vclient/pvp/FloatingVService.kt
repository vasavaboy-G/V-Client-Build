package com.vclient.pvp

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentCallbacks2
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlin.math.abs
import kotlin.math.max

/**
 * Foreground service owning every overlay window: floating V icon, PvP menu, HUD and crosshair.
 * All views are created once in onCreate and removed in onDestroy, so there are never duplicates.
 */
class FloatingVService : Service(), BridgeHost {

    companion object {
        const val ACTION_STOP = "com.vclient.pvp.action.STOP"
        private const val CHANNEL_ID = "v_client_overlay"
        private const val NOTIFICATION_ID = 101
        private const val TAG = "VClientService"
        private const val ICON_IDLE_ALPHA = 0.7f

        @Volatile
        var isRunning: Boolean = false
            private set
    }

    private lateinit var wm: WindowManager
    private lateinit var store: SettingsStore
    private lateinit var menu: PvPMenuController
    private lateinit var hud: HudOverlay
    private lateinit var crosshair: CrosshairOverlay
    private lateinit var editor: HudEditorController

    private val main = Handler(Looper.getMainLooper())
    private var iconView: FrameLayout? = null
    private var iconBg: GradientDrawable? = null
    private var iconParams: WindowManager.LayoutParams? = null
    private var snapAnimator: ValueAnimator? = null
    private var watcher: ForegroundWatcher? = null
    private var prevFilter: Int? = null
    private var prefsListener: SharedPreferences.OnSharedPreferenceChangeListener? = null

    private var slop = 0
    private var startX = 0
    private var startY = 0
    private var downRawX = 0f
    private var downRawY = 0f
    private var dragging = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // startForegroundService() obliges us to call startForeground quickly, even if we then quit.
        try {
            promoteToForeground()
        } catch (e: Exception) {
            Log.e(TAG, "startForeground failed", e)
            Toast.makeText(this, "V CLIENT overlay could not start: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission missing - stopping")
            Toast.makeText(this, "Allow \"Display over other apps\" for V CLIENT to see the floating icon.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = SettingsStore(this)
        slop = ViewConfiguration.get(this).scaledTouchSlop
        menu = PvPMenuController(this, wm, this)
        hud = HudOverlay(this, wm, store, android.os.SystemClock.elapsedRealtime())
        crosshair = CrosshairOverlay(this, wm, store)
        editor = HudEditorController(this, wm, this)

        // Edit-HUD mode and Do-Not-Disturb are per-session switches: always start them off.
        store.prefs.edit().putBoolean(Keys.HUD_EDIT, false).putBoolean(Keys.DND_ON, false).apply()
        buildIcon()
        hud.refresh()
        crosshair.refresh()
        HudStore.onChanged = { if (isRunning) hud.refresh() }
        watcher = ForegroundWatcher(this) { inGame -> applyVisibility(inGame) }
        syncWatcher()
        registerPrefsListener()
        isRunning = true
        // Create the menu's WebView shortly after start so the first tap on the icon opens it at once.
        main.postDelayed({ if (isRunning) menu.prewarm() }, 1500L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun promoteToForeground() {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr?.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "V CLIENT overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingVService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_v)
            .setContentTitle("V CLIENT overlay running")
            .setContentText("Tap the floating V icon to open the PvP menu")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, n)
        }
    }

    // ---------------------------------------------------------------- floating icon

    private fun buildIcon() {
        if (iconView != null) return          // never create a second icon
        val window = Ui.dp(this, 52f)         // touch target
        val circle = Ui.dp(this, 44f)         // visible circle
        val theme = ThemeManager.resolve(store)

        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(theme.primary)
        bg.setStroke(Ui.dp(this, 2f), theme.accent)
        iconBg = bg

        val label = TextView(this)
        label.text = "V"
        label.setTextColor(Color.WHITE)
        label.textSize = 20f
        label.typeface = Typeface.DEFAULT_BOLD
        label.gravity = Gravity.CENTER
        label.background = bg

        val frame = FrameLayout(this)
        frame.contentDescription = "V Client floating icon"
        frame.addView(label, FrameLayout.LayoutParams(circle, circle, Gravity.CENTER))
        frame.alpha = ICON_IDLE_ALPHA          // dimmed while idle so it hides less of the game

        val lp = WindowManager.LayoutParams(
            window, window,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        Ui.applyCutout(lp)
        applySavedPosition(lp)

        frame.setOnTouchListener { _, ev -> handleTouch(ev) }
        try {
            wm.addView(frame, lp)
            iconView = frame
            iconParams = lp
        } catch (e: Exception) {
            Log.e(TAG, "Could not add floating icon", e)
            Toast.makeText(this, "Could not show the floating icon: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    /** The icon can sit anywhere: its position is stored as fractions of the free screen range (x and y). */
    private fun applySavedPosition(lp: WindowManager.LayoutParams) {
        val screen = Ui.screen(wm)
        val xFrac = if (store.prefs.contains(Keys.ICON_X_FRAC)) store.getFloat(Keys.ICON_X_FRAC)
        else if (store.getInt(Keys.ICON_SIDE) == 0) 0f else 1f   // positions saved by older versions
        lp.x = IconPlacement.px(xFrac, screen.x, lp.width)
        lp.y = IconPlacement.px(store.getFloat(Keys.ICON_Y_FRAC), screen.y, lp.height)
    }

    private fun repositionIfNeeded() {
        val lp = iconParams ?: return
        val v = iconView ?: return
        if (dragging) return
        val oldX = lp.x
        val oldY = lp.y
        applySavedPosition(lp)
        if (abs(lp.x - oldX) > 3 || abs(lp.y - oldY) > 3) safeUpdate(v, lp)
        else { lp.x = oldX; lp.y = oldY }
    }

    private fun iconRect(): Rect {
        val lp = iconParams
        return if (lp == null) Rect(0, 0, 0, 0) else Rect(lp.x, lp.y, lp.x + lp.width, lp.y + lp.height)
    }

    private fun handleTouch(ev: MotionEvent): Boolean {
        val lp = iconParams ?: return false
        val v = iconView ?: return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snapAnimator?.cancel()
                startX = lp.x
                startY = lp.y
                downRawX = ev.rawX
                downRawY = ev.rawY
                dragging = false
                v.alpha = 1f
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.rawX - downRawX
                val dy = ev.rawY - downRawY
                if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                    dragging = true
                    menu.forceClose()          // never drag the icon with a menu open next to it
                }
                if (dragging) {
                    val screen = Ui.screen(wm)
                    lp.x = (startX + dx).toInt().coerceIn(0, max(0, screen.x - lp.width))
                    lp.y = (startY + dy).toInt().coerceIn(0, max(0, screen.y - lp.height))
                    safeUpdate(v, lp)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    if (store.getBool(Keys.ICON_SNAP)) snapToEdge() else saveIconPosition()
                } else {
                    v.performClick()
                    menu.toggle(iconRect())
                }
                dragging = false
                v.alpha = if (menu.isShowing) 1f else ICON_IDLE_ALPHA
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) saveIconPosition()
                dragging = false
                v.alpha = ICON_IDLE_ALPHA
                return true
            }
        }
        return false
    }

    /** Optional (setting icon_snap): glide to the nearest side edge after a drag. */
    private fun snapToEdge() {
        val lp = iconParams ?: return
        val v = iconView ?: return
        val screen = Ui.screen(wm)
        val targetX = IconPlacement.snapX(lp.x, screen.x, lp.width)

        snapAnimator?.cancel()
        val anim = ValueAnimator.ofInt(lp.x, targetX)
        anim.duration = 180L
        anim.addUpdateListener {
            lp.x = it.animatedValue as Int
            safeUpdate(v, lp)
        }
        anim.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                lp.x = targetX
                safeUpdate(v, lp)
                saveIconPosition()
            }
        })
        snapAnimator = anim
        anim.start()
    }

    /** Remembers where the icon is, as fractions, so the same place is used after a restart or a rotation. */
    private fun saveIconPosition() {
        val lp = iconParams ?: return
        val screen = Ui.screen(wm)
        val xf = IconPlacement.frac(lp.x, screen.x, lp.width)
        val yf = IconPlacement.frac(lp.y, screen.y, lp.height)
        store.prefs.edit()
            .putFloat(Keys.ICON_X_FRAC, xf)
            .putFloat(Keys.ICON_Y_FRAC, yf)
            .putInt(Keys.ICON_SIDE, if (xf > 0.5f) 1 else 0)
            .apply()
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, lp) } catch (e: Exception) { Log.w(TAG, "updateViewLayout", e) }
    }

    /** Icon, HUD, crosshair and menu are only shown while Minecraft is in front (when that option is on). */
    private fun applyVisibility(show: Boolean) {
        iconView?.visibility = if (show) View.VISIBLE else View.GONE
        hud.setVisible(show)
        crosshair.setVisible(show)
        if (!show) menu.forceClose()
    }

    private fun syncWatcher() {
        if (store.getBool(Keys.ONLY_IN_GAME)) {
            watcher?.start()
        } else {
            watcher?.stop()
            applyVisibility(true)
        }
    }

    private fun applyDnd(on: Boolean) {
        val nm = getSystemService(NotificationManager::class.java) ?: return
        if (!nm.isNotificationPolicyAccessGranted) {
            if (on) {
                store.prefs.edit().putBoolean(Keys.DND_ON, false).apply()
                Toast.makeText(this, "Allow Do Not Disturb access for V CLIENT first.", Toast.LENGTH_LONG).show()
                Access.openDndSettings(this)
            }
            return
        }
        try {
            if (on) {
                if (prevFilter == null) prevFilter = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
            } else {
                prevFilter?.let { nm.setInterruptionFilter(it) }
                prevFilter = null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Do Not Disturb", e)
        }
    }

    private fun applyThemeToIcon() {
        val t = ThemeManager.resolve(store)
        iconBg?.setColor(t.primary)
        iconBg?.setStroke(Ui.dp(this, 2f), t.accent)
        iconView?.invalidate()
    }

    // ---------------------------------------------------------------- settings changes

    private fun registerPrefsListener() {
        // Strong reference kept in a field: SharedPreferences only holds listeners weakly.
        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, key -> main.post { onSettingChanged(key) } }
        prefsListener = l
        store.prefs.registerOnSharedPreferenceChangeListener(l)
    }

    private fun onSettingChanged(key: String?) {
        if (!isRunning) return
        when {
            key == null -> applyAll()
            key == Keys.THEME || key.startsWith("theme_") -> { applyThemeToIcon(); menu.refreshTheme(); hud.refresh() }
            key == Keys.HUD_SIZE || key == Keys.HUD_OPACITY || key == Keys.HUD_COLOR -> {
                // The old "Look of all widgets" controls now set the look of every element in the active profile.
                HudStore.get(this).applyGlobalLook(
                    store.getInt(Keys.HUD_SIZE).toFloat(),
                    HudJson.parseHex(store.getString(Keys.HUD_COLOR), 0xFFFFFF),
                    store.getInt(Keys.HUD_OPACITY)
                )
                hud.refresh()
            }
            key.startsWith("hud_") || key.startsWith("w_") || key.startsWith("ping_") -> hud.refresh()
            key.startsWith("xh_") -> crosshair.refresh()
            key == Keys.ONLY_IN_GAME -> syncWatcher()
            key == Keys.DND_ON -> applyDnd(store.getBool(Keys.DND_ON))
            key == Keys.ICON_SIDE || key == Keys.ICON_Y_FRAC || key == Keys.ICON_X_FRAC -> repositionIfNeeded()
        }
    }

    private fun applyAll() {
        applyThemeToIcon()
        repositionIfNeeded()
        hud.refresh()
        crosshair.refresh()
        syncWatcher()
        applyDnd(false)
        menu.refreshAll()
    }

    // BridgeHost (menu side)
    override fun closeMenu() {
        menu.hide()
        iconView?.alpha = ICON_IDLE_ALPHA
    }
    override fun onReset() { applyAll() }
    override fun openHudEditor(select: String?) {
        menu.forceClose()
        editor.show(select)
    }
    override fun closeHudEditor() { editor.hide() }
    override fun overlayState(): String = Access.json(this, true)

    // ---------------------------------------------------------------- lifecycle

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!isRunning) return
        // Rotation / display-size / fold change: close the menu, re-clamp everything.
        menu.forceClose()
        main.post {
            repositionIfNeeded()
            hud.refresh()
            crosshair.refresh()
            editor.onRotate()
        }
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        // The kept menu WebView is the biggest thing we hold. Free it when the system is short of memory.
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW && ::menu.isInitialized && !menu.isShowing) menu.releaseWebView()
    }

    override fun onDestroy() {
        isRunning = false
        HudStore.onChanged = null
        snapAnimator?.cancel()
        watcher?.stop()
        watcher = null
        if (prevFilter != null) applyDnd(false)
        if (::store.isInitialized) {
            prefsListener?.let { store.prefs.unregisterOnSharedPreferenceChangeListener(it) }
        }
        prefsListener = null
        if (::editor.isInitialized) editor.hide()
        if (::menu.isInitialized) menu.releaseWebView()
        if (::hud.isInitialized) hud.remove()
        if (::crosshair.isInitialized) crosshair.remove()
        val v = iconView
        iconView = null
        iconParams = null
        if (v != null && ::wm.isInitialized) {
            try { wm.removeView(v) } catch (e: Exception) { /* already gone */ }
        }
        super.onDestroy()
    }
}

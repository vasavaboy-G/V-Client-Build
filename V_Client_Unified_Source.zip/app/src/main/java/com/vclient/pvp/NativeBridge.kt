package com.vclient.pvp

/**
 * JNI bridge to libvclient_native.so (frame statistics engine). The library exists only in builds made with
 * -PenableNative=true. Without it every call is skipped and [loaded] stays false.
 * IMPORTANT: no game hook feeds this engine yet, so its numbers are NOT Minecraft FPS and must not be shown as such.
 */
object NativeBridge {
    @Volatile var loaded: Boolean = false
        private set
    @Volatile var loadError: String? = null
        private set
    private var tried = false

    @Synchronized
    fun tryLoad() {
        if (tried) return
        tried = true
        try {
            System.loadLibrary("vclient_native")
            loaded = true
        } catch (e: UnsatisfiedLinkError) {
            loadError = e.message ?: "UnsatisfiedLinkError"
        } catch (e: Exception) {
            loadError = e.toString()
        }
    }

    @JvmStatic external fun nativeVersion(): String
    @JvmStatic external fun nativeOnPresent(nowNs: Long)
    @JvmStatic external fun nativeFps(nowNs: Long): Double
    @JvmStatic external fun nativeOnePercentLowMs(nowNs: Long): Double
    @JvmStatic external fun nativeReset()

    fun versionOrNull(): String? = if (loaded) try { nativeVersion() } catch (e: Throwable) { null } else null
}

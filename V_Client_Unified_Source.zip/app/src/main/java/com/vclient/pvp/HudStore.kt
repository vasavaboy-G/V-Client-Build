package com.vclient.pvp

import android.content.Context
import java.io.File

/**
 * Process-wide access to the HUD profiles. The floating service (which draws the HUD) and the WebView bridge (which edits it)
 * share one instance, so a change made in the editor is seen by the HUD immediately.
 */
object HudStore {
    private const val FILE_NAME = "hud_profiles.json"

    @Volatile private var inst: HudProfiles? = null

    /** Set by the service. Called (on the main thread) after the editor changed something that the HUD must redraw. */
    @Volatile var onChanged: (() -> Unit)? = null

    fun get(ctx: Context): HudProfiles {
        inst?.let { return it }
        synchronized(this) {
            inst?.let { return it }
            val app = ctx.applicationContext
            val file = File(app.filesDir, FILE_NAME)
            val firstRun = !file.isFile
            val p = HudProfiles(file, Widgets.ids) { id -> factoryDefault(id) }
            p.load()
            if (firstRun) migrateLegacy(SettingsStore(app), p)
            inst = p
            return p
        }
    }

    fun factoryDefault(id: String): HudElement = HudDefaults.element(id)

    /**
     * Old versions stored one global look (size, colour, opacity) and a percent position per widget in the settings.
     * The first time the new layout file is created, those values are carried over so nobody loses their layout.
     */
    private fun migrateLegacy(store: SettingsStore, p: HudProfiles) {
        val prefs = store.prefs
        val size = store.getInt(Keys.HUD_SIZE).toFloat()
        val color = HudJson.parseHex(store.getString(Keys.HUD_COLOR), 0xFFFFFF)
        val opacity = store.getInt(Keys.HUD_OPACITY)
        val hadLook = prefs.contains(Keys.HUD_SIZE) || prefs.contains(Keys.HUD_COLOR) || prefs.contains(Keys.HUD_OPACITY)
        for (id in Widgets.ids) {
            val hadPos = prefs.contains(Widgets.keyX(id)) || prefs.contains(Widgets.keyY(id))
            if (!hadPos && !hadLook) continue
            val base = p.element(id)
            val pos = if (hadPos) HudPos(store.getInt(Widgets.keyX(id)) / 100f, store.getInt(Widgets.keyY(id)) / 100f) else base.portrait
            val style = if (hadLook) base.style.copy(
                textSizeSp = size, textColor = color, textOpacity = opacity, bgOpacity = opacity * 70 / 100
            ) else base.style
            p.setElement(id, HudElement(id, style, pos, pos))
        }
    }

    fun changed() {
        onChanged?.invoke()
    }
}

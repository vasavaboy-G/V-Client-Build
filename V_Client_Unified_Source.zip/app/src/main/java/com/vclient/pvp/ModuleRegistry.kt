package com.vclient.pvp

import org.json.JSONArray
import org.json.JSONObject

/** Where a module gets its data from. This decides where it can work. */
enum class Requirement {
    /** Drawn or measured by Android itself (overlay). Works on public servers and personal worlds. */
    ANDROID_OVERLAY,
    /** Needs the V CLIENT add-on (Script API) running inside the world. Not available on public servers. */
    WORLD_ADDON,
    /** Needs the native tier (code inside the Minecraft process). Locked until native support is verified for the installed version. */
    NATIVE,
    /** No legitimate route known at all. Listed with the reason, never faked. (No module uses this right now.) */
    GAME_INTERNAL
}

data class ModuleInfo(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val requires: Requirement,
    /** Why it is unavailable or locked. Shown to the user. */
    val reason: String = "",
    val planned: Boolean = false,
    /** A WORLD_ADDON module that the native tier could also provide (for example on public servers) once verified. */
    val nativeCapable: Boolean = false
)

/** The single module list used by the ClickGUI, the HUD, the config system and the add-on builder. */
object ModuleRegistry {
    private const val NATIVE_REASON = "Needs code inside the Minecraft process (the native tier)."

    val all: List<ModuleInfo> = listOf(
        ModuleInfo("battery", "Battery", "HUD", "Battery percentage", Requirement.ANDROID_OVERLAY),
        ModuleInfo("clock", "Clock", "HUD", "Current time", Requirement.ANDROID_OVERLAY),
        ModuleInfo("ram", "Free RAM", "HUD", "Available memory in MB", Requirement.ANDROID_OVERLAY),
        ModuleInfo("storage", "Free storage", "HUD", "Free space on the phone", Requirement.ANDROID_OVERLAY),
        ModuleInfo("refresh", "Display refresh", "HUD", "Screen refresh rate in Hz (not Minecraft's FPS)", Requirement.ANDROID_OVERLAY),
        ModuleInfo("uptime", "Overlay time", "HUD", "How long V CLIENT has been running", Requirement.ANDROID_OVERLAY),
        ModuleInfo("ping", "Server ping", "HUD", "Round trip to a server address you enter", Requirement.ANDROID_OVERLAY),
        ModuleInfo("custom", "Custom text", "HUD", "Your own label", Requirement.ANDROID_OVERLAY),
        ModuleInfo("cps", "Touch CPS", "PvP", "Counts touch gestures on the screen, not Minecraft attacks. NOT attack CPS.", Requirement.ANDROID_OVERLAY),
        ModuleInfo("crosshair", "Crosshair", "PvP", "External crosshair at the screen centre", Requirement.ANDROID_OVERLAY),

        ModuleInfo("coords", "Coordinates", "World add-on", "XYZ position, shown in the game", Requirement.WORLD_ADDON, nativeCapable = true),
        ModuleInfo("direction", "Direction", "World add-on", "Facing direction (N, NE, E ...)", Requirement.WORLD_ADDON, nativeCapable = true),
        ModuleInfo("armor", "Armor HUD", "World add-on", "Armor durability per slot", Requirement.WORLD_ADDON, nativeCapable = true),
        ModuleInfo("keystrokes", "Keystrokes", "World add-on", "Movement, jump and sneak", Requirement.WORLD_ADDON, nativeCapable = true),
        ModuleInfo("attack_cps", "Attack CPS", "World add-on", "Attack swings per second", Requirement.WORLD_ADDON, nativeCapable = true),
        ModuleInfo("combo", "Combo counter", "World add-on", "Consecutive landed hits", Requirement.WORLD_ADDON, nativeCapable = true),

        ModuleInfo("fps", "Minecraft FPS", "Native", "Frames per second inside Minecraft", Requirement.NATIVE,
            "Measured from the game's real frame presentation. $NATIVE_REASON"),
        ModuleInfo("frame_time", "Frame time", "Native", "Frame time and 1% lows", Requirement.NATIVE,
            "Measured from the game's real frame presentation. $NATIVE_REASON"),
        ModuleInfo("zoom", "Zoom", "Native", "Narrow the field of view (visual only)", Requirement.NATIVE,
            "Changes rendering only. $NATIVE_REASON Not possible from the add-on on public servers."),
        ModuleInfo("hit_counter", "Hit counter", "Native", "Landed hits, from real game events", Requirement.NATIVE, NATIVE_REASON),
        ModuleInfo("target", "Target tracking", "Native", "Current target identity, from real game events", Requirement.NATIVE, NATIVE_REASON),
        ModuleInfo("combat_stats", "Combat statistics", "Native", "Session hit and combo statistics", Requirement.NATIVE, NATIVE_REASON),
        ModuleInfo("freelook", "FreeLook", "Native", "Look around without turning the player. Highest risk module: may be restricted by servers.", Requirement.NATIVE, NATIVE_REASON)
    )

    /** True when the module has an element in the HUD editor (placeable even if its live data is not available yet). */
    fun hasHudElement(id: String): Boolean = id in Widgets.ids || id == "crosshair"

    fun byId(id: String): ModuleInfo? = all.firstOrNull { it.id == id }

    fun overlayModules(): List<ModuleInfo> = all.filter { it.requires == Requirement.ANDROID_OVERLAY }

    fun addonModules(): List<ModuleInfo> = all.filter { it.requires == Requirement.WORLD_ADDON }

    fun nativeModules(): List<ModuleInfo> = all.filter { it.requires == Requirement.NATIVE }

    /** The settings key that switches a module on or off, or null if nothing real could ever sit behind it. */
    fun toggleKey(id: String): String? {
        val m = byId(id) ?: return null
        return when (m.requires) {
            Requirement.ANDROID_OVERLAY -> if (id == "crosshair") Keys.XH_ENABLED else Widgets.keyOn(id)
            Requirement.WORLD_ADDON -> Addon.keyOn(id)
            Requirement.NATIVE -> Native.keyOn(id)
            Requirement.GAME_INTERNAL -> null
        }
    }

    fun toJson(mode: WorldMode, addonSent: Boolean, native: NativeState = NativeState.NOT_BUILT): String {
        val arr = JSONArray()
        for (m in all) {
            val st = Integrations.statusFor(m, mode, addonSent, native)
            arr.put(
                JSONObject()
                    .put("id", m.id)
                    .put("name", m.name)
                    .put("category", m.category)
                    .put("description", m.description)
                    .put("requires", m.requires.name)
                    .put("nativeCapable", m.nativeCapable)
                    .put("hud", hasHudElement(m.id))
                    .put("key", toggleKey(m.id) ?: JSONObject.NULL)
                    .put("status", st.code)
                    .put("statusText", st.text)
                    .put("reason", m.reason)
            )
        }
        return arr.toString()
    }
}

package com.vclient.pvp

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.Process
import android.os.StatFs
import android.view.WindowManager
import org.json.JSONObject

/** Real Android API values only. Anything that cannot be read is reported as JSON null ("Unavailable"). */
object DeviceTelemetry {
    private const val MB = 1024L * 1024L

    fun batteryPercent(ctx: Context): Int? {
        return try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) level * 100 / scale else null
        } catch (e: Exception) {
            null
        }
    }

    fun availRamMb(ctx: Context): Long? = try {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        if (am == null) null else {
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            mi.availMem / MB
        }
    } catch (e: Exception) {
        null
    }

    fun freeStorageGb(): Double? = try {
        StatFs(Environment.getDataDirectory().path).availableBytes / (1024.0 * 1024.0 * 1024.0)
    } catch (e: Exception) {
        null
    }

    fun toJson(ctx: Context): String {
        val o = JSONObject()
        o.put("manufacturer", Build.MANUFACTURER ?: "Unavailable")
        o.put("model", Build.MODEL ?: "Unavailable")
        o.put("androidRelease", Build.VERSION.RELEASE ?: "Unavailable")
        o.put("sdkInt", Build.VERSION.SDK_INT)
        o.put("refreshHz", JSONObject.NULL)
        try {
            @Suppress("DEPRECATION")
            val hz = (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.refreshRate
            if (hz > 0f) o.put("refreshHz", hz.toDouble())
        } catch (e: Exception) {
            // leave as null
        }
        o.put("totalRamMb", JSONObject.NULL)
        o.put("availRamMb", JSONObject.NULL)
        o.put("appMemMb", JSONObject.NULL)
        o.put("batteryPercent", JSONObject.NULL)
        o.put("batteryTempC", JSONObject.NULL)

        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            if (am != null) {
                val mi = ActivityManager.MemoryInfo()
                am.getMemoryInfo(mi)
                o.put("totalRamMb", mi.totalMem / MB)
                o.put("availRamMb", mi.availMem / MB)
                val pm = am.getProcessMemoryInfo(intArrayOf(Process.myPid()))
                if (pm.isNotEmpty()) o.put("appMemMb", pm[0].totalPss / 1024)
            }
        } catch (e: Exception) {
            // leave as null -> "Unavailable"
        }

        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val pct = batteryPercent(ctx)
                if (pct != null) o.put("batteryPercent", pct)
                val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
                if (t != Int.MIN_VALUE && t > 0) o.put("batteryTempC", t / 10.0)
            }
        } catch (e: Exception) {
            // leave as null
        }
        return o.toString()
    }
}

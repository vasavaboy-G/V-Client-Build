package com.vclient.pvp

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.system.Os
import android.system.OsConstants
import androidx.core.content.pm.PackageInfoCompat
import dalvik.system.PathClassLoader
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.lang.reflect.Modifier
import java.security.MessageDigest

/**
 * Read-only "native readiness" report (probe_version 2).
 *
 * HARD RULES of this probe:
 *  - It never starts Minecraft, never starts any Minecraft activity or service, and never changes anything.
 *  - It never loads Minecraft's native libraries (no System.load / dlopen of any Minecraft file).
 *  - It looks classes up WITHOUT initialising them (Class.forName(name, false, loader)), so no static initialiser
 *    of the game runs (those usually load the game's native library).
 *  - Every failure is recorded with its exact exception class and message. Nothing is hidden or guessed.
 * The report is saved to files/native_probe.json and can be shared from the menu.
 */
object NativeProbe {
    private const val MAIN_ACTIVITY_CLASS = "com.mojang.minecraftpe.MainActivity"
    private val XAL_CLASSES = listOf("com.microsoft.xal.XalApplicationInfo", "com.microsoft.xbox.idp.interop.Interop")

    private fun err(t: Throwable): String = t.javaClass.name + ": " + (t.message ?: "")

    fun run(ctx: Context): String {
        val o = JSONObject()
        o.put("probe_version", 2)
        o.put("read_only", true)
        o.put("started_minecraft", false)
        o.put("loaded_minecraft_native_libraries", false)
        o.put("time_ms", System.currentTimeMillis())

        // --- 1. Phone ---
        val phone = JSONObject()
        phone.put("device", Build.MANUFACTURER + " " + Build.MODEL)
        phone.put("android_release", Build.VERSION.RELEASE)
        phone.put("android_sdk", Build.VERSION.SDK_INT)
        phone.put("abis", JSONArray(Build.SUPPORTED_ABIS.toList()))
        phone.put("process_is_64bit", Process.is64Bit())
        try {
            phone.put("page_size_bytes", Os.sysconf(OsConstants._SC_PAGESIZE))
        } catch (t: Throwable) {
            phone.put("page_size_error", err(t))
        }
        phone.put("vclient_target_sdk", ctx.applicationInfo.targetSdkVersion)
        o.put("phone", phone)

        // --- 2. V CLIENT native library (our own, not Minecraft's) ---
        NativeBridge.tryLoad()
        val nat = JSONObject()
        nat.put("tier_implemented", NativeCapability.TIER_IMPLEMENTED)
        nat.put("lib_loaded", NativeBridge.loaded)
        nat.put("lib_error", NativeBridge.loadError ?: JSONObject.NULL)
        nat.put("lib_version", NativeBridge.versionOrNull() ?: JSONObject.NULL)
        o.put("vclient_native", nat)

        // --- 3. Minecraft ---
        val mc = MinecraftDetector.primary(MinecraftDetector.detectAll(ctx))
        if (mc == null) {
            o.put("minecraft", "not found")
            return finish(ctx, o)
        }
        val pm = ctx.packageManager
        val m = JSONObject()
        m.put("package", mc.packageName)
        m.put("version_name", mc.versionName)
        val parsed = NativeCapability.parseVersion(mc.versionName)
        m.put("parsed_version", if (parsed == null) JSONObject.NULL else JSONArray(parsed))
        m.put("meets_assumed_minimum_1_21_80", parsed != null && NativeCapability.compare(parsed, NativeCapability.MIN_VERSION) >= 0)
        var sourceDir: String? = null
        var splitDirs: List<String> = emptyList()
        var nativeDir: String? = null
        try {
            val pi = pm.getPackageInfo(mc.packageName, 0)
            m.put("version_code", PackageInfoCompat.getLongVersionCode(pi))
            val ai = pi.applicationInfo
            if (ai != null) {
                sourceDir = ai.sourceDir
                splitDirs = (ai.splitSourceDirs ?: emptyArray<String>()).toList()
                nativeDir = ai.nativeLibraryDir
                m.put("source_dir", sourceDir)
                m.put("split_apks", JSONArray(splitDirs))
                m.put("native_library_dir", nativeDir)
                val libDir = File(nativeDir ?: "")
                val files = libDir.list()
                m.put("lib_dir_listing", if (files == null) "not listable" else JSONArray(files.take(30)))
                val so = File(libDir, "libminecraftpe.so")
                m.put("libminecraftpe_exists", so.exists())
                m.put("libminecraftpe_readable", so.canRead())
                m.put("libminecraftpe_size", if (so.exists()) so.length() else JSONObject.NULL)
            }
        } catch (t: Throwable) {
            m.put("package_info_error", err(t))
        }
        try {
            @Suppress("DEPRECATION")
            val installer = if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(mc.packageName).installingPackageName
            else pm.getInstallerPackageName(mc.packageName)
            m.put("installer", installer ?: JSONObject.NULL)
            m.put("installed_by_google_play", installer == "com.android.vending")
        } catch (t: Throwable) {
            m.put("installer_error", err(t))
        }
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                val sp = pm.getPackageInfo(mc.packageName, PackageManager.GET_SIGNING_CERTIFICATES)
                val signers = sp.signingInfo?.apkContentsSigners
                m.put("signing_cert_sha256", if (signers == null || signers.isEmpty()) JSONObject.NULL else
                    MessageDigest.getInstance("SHA-256").digest(signers[0].toByteArray()).joinToString("") { "%02x".format(it) })
            } catch (t: Throwable) {
                m.put("signing_cert_error", err(t))
            }
        }
        o.put("minecraft", m)

        // --- 4. Launch feasibility (read-only questions that decide which launch method could ever work) ---
        val f = JSONObject()
        f.put("note", "Answers whether V CLIENT's process can even SEE Minecraft's code. It does not start the game.")
        try {
            val pc = ctx.createPackageContext(mc.packageName, Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY)
            f.put("package_context", "ok")
            try {
                Class.forName(MAIN_ACTIVITY_CLASS, false, pc.classLoader)
                f.put("main_activity_via_package_context", "found")
            } catch (t: Throwable) {
                f.put("main_activity_via_package_context", err(t))
            }
        } catch (t: Throwable) {
            f.put("package_context", err(t))
        }
        if (sourceDir != null) {
            // Same question with our own class loader over the installed APK files (what a custom launcher would need).
            try {
                val dexPath = (listOf(sourceDir) + splitDirs).joinToString(File.pathSeparator)
                val loader = PathClassLoader(dexPath, nativeDir, ctx.classLoader)
                try {
                    val c = Class.forName(MAIN_ACTIVITY_CLASS, false, loader)
                    f.put("main_activity_via_own_loader", "found")
                    f.put("main_activity_superclass", c.superclass?.name ?: JSONObject.NULL)
                    try {
                        f.put("main_activity_native_method_count", c.declaredMethods.count { Modifier.isNative(it.modifiers) })
                    } catch (t: Throwable) {
                        f.put("main_activity_methods_error", err(t))
                    }
                } catch (t: Throwable) {
                    f.put("main_activity_via_own_loader", err(t))
                }
                for (name in XAL_CLASSES) {
                    try {
                        Class.forName(name, false, loader)
                        f.put("class_" + name.substringAfterLast('.'), "found")
                    } catch (t: Throwable) {
                        f.put("class_" + name.substringAfterLast('.'), err(t))
                    }
                }
            } catch (t: Throwable) {
                f.put("own_loader_error", err(t))
            }
        }
        // Hidden-API enforcement check (some launch techniques depend on it). Read-only reflection lookup.
        try {
            Class.forName("android.app.ActivityThread").getDeclaredMethod("currentActivityThread")
            f.put("hidden_api_activity_thread", "accessible")
        } catch (t: Throwable) {
            f.put("hidden_api_activity_thread", err(t))
        }
        o.put("launch_feasibility", f)
        return finish(ctx, o)
    }

    private fun finish(ctx: Context, o: JSONObject): String {
        val text = o.toString(2)
        try {
            File(ctx.filesDir, "native_probe.json").writeText(text)
        } catch (t: Throwable) {
            // Report still returned to the caller.
        }
        return text
    }
}

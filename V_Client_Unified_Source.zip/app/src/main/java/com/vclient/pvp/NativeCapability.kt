package com.vclient.pvp

import android.content.Context
import android.os.Build

/** Inputs for the decision, so the rules can be unit tested without Android. */
data class NativeEnv(
    val abis: List<String>,
    val sdkInt: Int,
    val minecraftInstalled: Boolean,
    val minecraftVersion: String?,
    val libLoaded: Boolean
)

/** [verified] is true only for a Minecraft version listed in [NativeCapability.VERIFIED_VERSIONS]. */
data class NativeState(val code: String, val text: String, val verified: Boolean) {
    companion object {
        val NOT_BUILT = NativeState("not_built", "The native tier is not built: no safe in-process launch method has been found yet (see NATIVE_SPIKE.md).", false)
    }
}

/**
 * Decides whether the native (in-game) tier may be offered. It starts at "not built" and can only reach "verified"
 * for a Minecraft version that was tested on a real phone and added to VERIFIED_VERSIONS by hand.
 * Nothing is inferred or assumed to work.
 */
object NativeCapability {
    /** Flip to true only in a build that really contains a launcher and a native module. */
    const val TIER_IMPLEMENTED = false

    const val MIN_ANDROID = 28

    /** Design assumption taken from the LeviLauncher documentation (it rejects older versions). Not our own verification. */
    val MIN_VERSION: List<Int> = listOf(1, 21, 80)

    /** Add a version here ONLY after the native steps of TEST_PLAN.md passed on a real phone. Empty on purpose. */
    val VERIFIED_VERSIONS: Set<String> = emptySet()

    /** "1.21.80.3" -> [1,21,80,3]. New style "26.40.2" (the 1.26 line) -> [1,26,40,2]. Returns null if unreadable. */
    fun parseVersion(raw: String?): List<Int>? {
        if (raw == null) return null
        val parts = Regex("\\d+").findAll(raw).map { it.value.toIntOrNull() }.toList()
        if (parts.size < 2 || parts.any { it == null }) return null
        val nums = parts.map { it!! }
        return if (nums[0] >= 20) listOf(1) + nums else nums
    }

    fun compare(a: List<Int>, b: List<Int>): Int {
        val n = maxOf(a.size, b.size)
        for (i in 0 until n) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    fun evaluate(env: NativeEnv): NativeState {
        if (!TIER_IMPLEMENTED) return NativeState.NOT_BUILT
        if (!env.minecraftInstalled) return NativeState("no_minecraft", "Minecraft is not installed.", false)
        if ("arm64-v8a" !in env.abis) return NativeState("abi", "Needs a 64-bit ARM phone (arm64-v8a).", false)
        if (env.sdkInt < MIN_ANDROID) return NativeState("android_old", "Needs Android 9 or newer.", false)
        val v = parseVersion(env.minecraftVersion)
            ?: return NativeState("version_unknown", "Could not read the Minecraft version.", false)
        if (compare(v, MIN_VERSION) < 0) return NativeState("version_old", "Minecraft is older than the minimum version 1.21.80.", false)
        if (!env.libLoaded) return NativeState("lib_missing", "The native library is not in this build or failed to load.", false)
        val name = env.minecraftVersion ?: ""
        return if (name in VERIFIED_VERSIONS) NativeState("verified", "Verified on a real phone for Minecraft $name.", true)
        else NativeState("unverified", "Minecraft $name has not been verified on a real phone.", false)
    }

    fun current(ctx: Context): NativeState {
        val mc = MinecraftDetector.primary(MinecraftDetector.detectAll(ctx))
        NativeBridge.tryLoad()
        return evaluate(
            NativeEnv(Build.SUPPORTED_ABIS.toList(), Build.VERSION.SDK_INT, mc != null, mc?.versionName, NativeBridge.loaded)
        )
    }
}

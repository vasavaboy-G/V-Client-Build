package com.vclient.pvp

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast

/**
 * The PvP menu: a side panel that opens NEXT TO the floating icon, towards the side with more room
 * (icon on the left half -> opens to the right, icon on the right half -> opens to the left). Its position and width are
 * computed from the icon position and the screen size every time it opens, so it never leaves the screen.
 *
 * Opening is fast because the WebView is created once and kept (detached from the window manager) while the menu is closed.
 * When the menu is closed there is NO window at all, so it cannot block Minecraft's controls. The kept WebView is released
 * when Android reports memory pressure ([releaseWebView]) and when the service stops.
 */
class PvPMenuController(
    private val ctx: Context,
    private val wm: WindowManager,
    private val host: BridgeHost
) {
    private var root: FrameLayout? = null
    private var web: WebView? = null
    private var attached = false
    private var closing = false
    private var pageLoaded = false

    val isShowing: Boolean get() = attached && !closing

    /** Creates the WebView ahead of time so the first tap on the icon opens the menu immediately. */
    fun prewarm() {
        if (root == null) createViews()
    }

    private fun createViews(): Boolean {
        val themed = ContextThemeWrapper(ctx, R.style.Theme_VClient)
        val wv = try {
            WebView(themed)
        } catch (e: Exception) {
            Log.e(TAG, "WebView unavailable", e)
            Toast.makeText(ctx, "WebView is unavailable on this device.", Toast.LENGTH_LONG).show()
            return false
        }
        wv.settings.javaScriptEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.setBackgroundColor(Color.TRANSPARENT)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
            override fun onPageFinished(view: WebView?, url: String?) { pageLoaded = true }
        }
        wv.addJavascriptInterface(VBridge(ctx, host), "VBridge")
        pageLoaded = false
        wv.loadUrl("file:///android_asset/pvp_menu.html")

        val container = object : FrameLayout(themed) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) hide()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        container.isFocusable = true
        container.isFocusableInTouchMode = true
        container.addView(
            wv,
            FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT)
        )
        root = container
        web = wv
        return true
    }

    /** [icon] is the floating icon's rectangle in screen pixels. */
    fun toggle(icon: Rect) {
        if (closing) finishClose()
        if (attached) hide() else show(icon)
    }

    fun show(icon: Rect) {
        if (attached) return
        if (root == null && !createViews()) return
        val r = root ?: return

        val screen = Ui.screen(wm)
        val landscape = screen.x > screen.y
        val desired = (screen.x * (if (landscape) 0.42f else 0.92f)).toInt().coerceIn(Ui.dp(ctx, 300f), Ui.dp(ctx, 440f))
        val place = MenuPlacement.compute(
            iconX = icon.left,
            iconSize = icon.width(),
            screenW = screen.x,
            desiredW = desired,
            minW = Ui.dp(ctx, 240f),
            margin = Ui.dp(ctx, 4f),
            gap = Ui.dp(ctx, 6f)
        )

        val lp = WindowManager.LayoutParams(
            place.width,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = place.x
        lp.y = 0
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        Ui.applyCutout(lp)

        // Slide a short distance away from the icon while fading in.
        val shift = Ui.dp(ctx, 28f).toFloat() * (if (place.opensRight) -1f else 1f)
        r.alpha = 0f
        r.translationX = shift
        try {
            wm.addView(r, lp)
        } catch (e: Exception) {
            Log.e(TAG, "addView failed", e)
            return
        }
        attached = true
        closing = false
        web?.onResume()
        if (pageLoaded) web?.evaluateJavascript("window.VMenu&&VMenu.refreshAll()", null)
        r.requestFocus()
        r.animate().cancel()
        r.animate().alpha(1f).translationX(0f).setDuration(160L).setInterpolator(DecelerateInterpolator()).start()
    }

    fun hide() {
        val r = root ?: return
        if (!attached || closing) return
        closing = true
        val shift = r.translationX
        r.animate().cancel()
        r.animate().alpha(0f).translationX(if (shift == 0f) Ui.dp(ctx, 20f).toFloat() else shift)
            .setDuration(120L)
            .withEndAction { finishClose() }
            .start()
    }

    /** Removes the window right now. The WebView is kept for the next open. */
    private fun finishClose() {
        val r = root
        closing = false
        if (r != null && attached) {
            r.animate().cancel()
            try { wm.removeView(r) } catch (e: Exception) { /* already removed */ }
            attached = false
            web?.onPause()
        }
    }

    /** Immediate removal (rotation, Minecraft left the screen, service shutdown). */
    fun forceClose() {
        finishClose()
    }

    /** Frees the kept WebView (memory pressure, service stop). The next open rebuilds it. */
    fun releaseWebView() {
        finishClose()
        val w = web
        web = null
        root = null
        pageLoaded = false
        if (w != null) {
            try {
                w.stopLoading()
                w.removeJavascriptInterface("VBridge")
                w.destroy()
            } catch (e: Exception) {
                Log.w(TAG, "WebView destroy", e)
            }
        }
    }

    fun refreshTheme() = runJs("window.VMenu&&VMenu.refreshTheme()")
    fun refreshAll() = runJs("window.VMenu&&VMenu.refreshAll()")

    private fun runJs(js: String) {
        if (pageLoaded) web?.evaluateJavascript(js, null)
    }

    private companion object {
        const val TAG = "VClientMenu"
    }
}

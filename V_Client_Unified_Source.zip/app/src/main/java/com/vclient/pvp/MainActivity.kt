package com.vclient.pvp

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import org.json.JSONObject

/** Hosts the ORIGINAL V CLIENT dashboard (assets/V_Client_UI.html) in a WebView. */
class MainActivity : AppCompatActivity(), BridgeHost {

    private var web: WebView? = null
    private lateinit var store: SettingsStore
    private var prefsListener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val main = Handler(Looper.getMainLooper())
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var lastPackType = "general"
    private var pendingOverlayStart = false

    // Lets <input type="file"> inside the dashboard (skin upload) open the Android picker.
    private val chooserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
            fileCallback = null
        }

    private val packPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris != null && uris.isNotEmpty()) addToLibrary(uris)
        }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Granted or denied, the overlay still works; only the notification may be hidden.
            startOverlayService()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SettingsStore(this)

        val wv = try {
            WebView(this)
        } catch (e: Exception) {
            Log.e(TAG, "WebView unavailable", e)
            Toast.makeText(this, "WebView is unavailable on this device.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = false
        wv.settings.allowContentAccess = false
        wv.setBackgroundColor(Color.parseColor("#030712"))
        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return true
                if (uri.scheme == "minecraft") {
                    launchMinecraft()
                    return true
                }
                // Only the bundled dashboard may be the top-level page, so the JS bridge is never exposed to web pages.
                val local = uri.scheme == "file" && (uri.path ?: "").startsWith("/android_asset/")
                return !local
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                if (request?.isForMainFrame == true) Log.e(TAG, "Dashboard load error: ${error?.description}")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                refreshJs()
            }
        }
        wv.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(cm: ConsoleMessage): Boolean {
                Log.d(TAG, "JS ${cm.messageLevel()}: ${cm.message()} (${cm.sourceId()}:${cm.lineNumber()})")
                return true
            }

            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: WebChromeClient.FileChooserParams?
            ): Boolean {
                if (callback == null || params == null) return false
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    chooserLauncher.launch(params.createIntent())
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    callback.onReceiveValue(null)
                    false
                }
            }
        }
        wv.addJavascriptInterface(VBridge(this, this), "VBridge")
        wv.loadUrl("file:///android_asset/V_Client_UI.html")
        web = wv
        setContentView(wv)

        val l = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            runOnUiThread {
                if (key == null || key == Keys.THEME) refreshJs()
                else web?.evaluateJavascript("window.vSyncControls&&vSyncControls();", null)
                if (key == null || key == Keys.KEEP_SCREEN_ON) applyKeepScreenOn()
            }
        }
        prefsListener = l
        store.prefs.registerOnSharedPreferenceChangeListener(l)
        applyKeepScreenOn()
        main.postDelayed({ maybeAutoStart() }, 700L)
    }

    /** Shows the floating icon automatically when the app opens (can be switched off in Settings). */
    private fun maybeAskUsageAccess() {
        if (!store.getBool(Keys.ONLY_IN_GAME) || Access.usage(this)) return
        if (store.prefs.getBoolean("usage_prompted", false)) return
        store.prefs.edit().putBoolean("usage_prompted", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Show the V icon only inside Minecraft?")
            .setMessage(
                "Allow \"Usage access\" for V CLIENT so the floating icon, HUD and crosshair appear only while " +
                    "Minecraft is open. You can skip this; they then stay visible over every app."
            )
            .setPositiveButton("Open settings") { _, _ -> Access.openUsageSettings(this) }
            .setNegativeButton("Skip", null)
            .show()
    }

    private fun maybeAutoStart() {
        if (Settings.canDrawOverlays(this)) main.postDelayed({ maybeAskUsageAccess() }, 1500L)
        if (!store.getBool(Keys.AUTO_START) || FloatingVService.isRunning) return
        if (Settings.canDrawOverlays(this)) {
            toggleOverlay()
        } else if (!store.prefs.getBoolean("onboarded", false)) {
            store.prefs.edit().putBoolean("onboarded", true).apply()
            toggleOverlay()
        }
    }

    private fun applyKeepScreenOn() {
        if (store.getBool(Keys.KEEP_SCREEN_ON)) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onResume() {
        super.onResume()
        web?.onResume()
        refreshJs()
        if (pendingOverlayStart && Settings.canDrawOverlays(this)) {
            pendingOverlayStart = false
            if (!FloatingVService.isRunning) toggleOverlay()
        }
    }

    override fun onPause() {
        web?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        prefsListener?.let { store.prefs.unregisterOnSharedPreferenceChangeListener(it) }
        prefsListener = null
        main.removeCallbacksAndMessages(null)
        web?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.removeJavascriptInterface("VBridge")
            it.destroy()
        }
        web = null
        super.onDestroy()
    }

    private fun refreshJs() {
        web?.evaluateJavascript(
            "window.vApplyTheme&&vApplyTheme();window.vSyncControls&&vSyncControls();window.vRefreshOverlay&&vRefreshOverlay();window.vRenderPacks&&vRenderPacks();", null
        )
    }

    // ---------------------------------------------------------------- BridgeHost

    override fun overlayState(): String = Access.json(this, FloatingVService.isRunning)

    override fun onReset() {
        refreshJs()
    }

    override fun importPack(type: String) {
        lastPackType = type
        try {
            packPicker.launch(arrayOf("*/*"))
        } catch (e: Exception) {
            Toast.makeText(this, "No file picker available.", Toast.LENGTH_LONG).show()
        }
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "file"
            }
        } catch (e: Exception) {
            // fall through
        }
        return uri.lastPathSegment ?: "file"
    }

    /** Adds picked packs to the V CLIENT library. They are sent to Minecraft when it is launched from here. */
    private fun addToLibrary(uris: List<Uri>) {
        Thread {
            var added = 0
            var rejected = 0
            for (uri in uris) {
                val name = displayName(uri)
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in PackLibrary.extensions && PackLibrary.add(this, uri, name)) added++ else rejected++
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    if (added > 0) "Added $added pack(s). They are sent to Minecraft when you press Launch."
                    else "Only .mcpack/.mcworld/.mcaddon/.mctemplate files can be added.",
                    Toast.LENGTH_LONG
                ).show()
                if (rejected > 0 && added > 0) {
                    Toast.makeText(this, "$rejected file(s) skipped (not Minecraft packs).", Toast.LENGTH_SHORT).show()
                }
                refreshJs()
            }
        }.start()
    }

    private fun minecraftOrToast(): MinecraftInfo? {
        val mc = MinecraftDetector.primary(MinecraftDetector.detectAll(this))
        if (mc == null || !mc.hasLaunchIntent) {
            Toast.makeText(this, "Minecraft Bedrock was not detected (or has no launch intent).", Toast.LENGTH_LONG).show()
            return null
        }
        return mc
    }

    override fun sendPack(name: String) {
        val mc = minecraftOrToast() ?: return
        val f = PackLibrary.find(this, name) ?: return
        PackSender.send(this, listOf(f), mc.packageName)
        main.postDelayed({ refreshJs() }, 1500L)
    }

    override fun sendAllPacks() {
        val mc = minecraftOrToast() ?: return
        PackLibrary.clearSent(this)
        val all = PackLibrary.files(this)
        if (all.isEmpty()) {
            Toast.makeText(this, "No packs in the library yet.", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Sending ${all.size} pack(s) to Minecraft...", Toast.LENGTH_LONG).show()
        PackSender.send(this, all, mc.packageName)
        main.postDelayed({ refreshJs() }, all.size * 4000L + 500L)
    }

    override fun saveSkin(name: String, dataUrl: String) {
        val bytes = try {
            Base64.decode(dataUrl.substringAfter("base64,"), Base64.DEFAULT)
        } catch (e: Exception) {
            null
        }
        val magic = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47)
        if (bytes == null || bytes.size < 8 || bytes.size > 2_000_000 || !bytes.copyOfRange(0, 4).contentEquals(magic)) {
            Toast.makeText(this, "That is not a valid PNG skin.", Toast.LENGTH_LONG).show()
            return
        }
        val safe = name.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40).ifBlank { "skin" }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, "$safe.png")
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/V CLIENT")
                val target = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("could not create the file")
                val stream = contentResolver.openOutputStream(target) ?: throw IllegalStateException("could not open the file")
                stream.use { it.write(bytes) }
                Toast.makeText(
                    this,
                    "Saved to Pictures/V CLIENT. In Minecraft: Dressing Room > Classic Skins > Choose New Skin.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                val dir = File(cacheDir, "skins")
                dir.mkdirs()
                val f = File(dir, "$safe.png")
                f.writeBytes(bytes)
                val u = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
                val send = Intent(Intent.ACTION_SEND)
                send.type = "image/png"
                send.putExtra(Intent.EXTRA_STREAM, u)
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(send, "Save skin PNG"))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not save the skin: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun openFiles() {
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(Uri.parse("content://com.android.externalstorage.documents/root/primary"), "vnd.android.document/root")
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE))
            } catch (e2: Exception) {
                Toast.makeText(this, "No file manager found.", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun backupSettings() {
        try {
            val send = Intent(Intent.ACTION_SEND)
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_SUBJECT, "V CLIENT settings backup")
            send.putExtra(Intent.EXTRA_TEXT, store.toBackupJson())
            startActivity(Intent.createChooser(send, "Back up V CLIENT settings"))
        } catch (e: Exception) {
            Toast.makeText(this, "Could not share the backup.", Toast.LENGTH_LONG).show()
        }
    }

    override fun restoreSettings() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val text = try { cm?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() } catch (e: Exception) { null }
        val n = if (text.isNullOrBlank()) 0 else store.importJson(text)
        Toast.makeText(
            this,
            if (n > 0) "Restored $n settings from clipboard." else "Clipboard has no V CLIENT settings backup.",
            Toast.LENGTH_LONG
        ).show()
        refreshJs()
    }

    override fun launchMinecraft() {
        if (Settings.canDrawOverlays(this) && !FloatingVService.isRunning) startOverlayService()
        val pending = if (store.getBool(Keys.AUTO_SEND_PACKS)) PackLibrary.pending(this) else emptyList()
        val mc = MinecraftDetector.primary(MinecraftDetector.detectAll(this))
        if (pending.isNotEmpty() && mc != null && mc.hasLaunchIntent) {
            Toast.makeText(this, "Launching Minecraft and sending ${pending.size} pack(s)...", Toast.LENGTH_LONG).show()
            PackSender.send(this, pending, mc.packageName)
            main.postDelayed({ refreshJs() }, pending.size * 4000L + 500L)
            return
        }
        if (!MinecraftDetector.launch(this)) {
            Toast.makeText(
                this,
                "Minecraft Bedrock was not detected (or has no launch intent). Install it first.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun toggleOverlay() {
        if (FloatingVService.isRunning) {
            stopService(Intent(this, FloatingVService::class.java))
            main.postDelayed({ refreshJs() }, 500L)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Allow display over other apps")
                .setMessage(
                    "V CLIENT needs the \"Display over other apps\" permission to show the floating V icon. " +
                        "Without it the dashboard still works, but the overlay stays off."
                )
                .setPositiveButton("Open settings") { _, _ ->
                    pendingOverlayStart = true
                    try {
                        startActivity(
                            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                        )
                    } catch (e: Exception) {
                        Toast.makeText(this, "Could not open the overlay permission screen.", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton("Not now", null)
                .show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        try {
            ContextCompat.startForegroundService(this, Intent(this, FloatingVService::class.java))
        } catch (e: Exception) {
            Log.e(TAG, "Could not start overlay service", e)
            Toast.makeText(this, "Could not start the overlay: ${e.message}", Toast.LENGTH_LONG).show()
        }
        main.postDelayed({ refreshJs() }, 700L)
    }

    private companion object {
        const val TAG = "VClientMain"
    }
}

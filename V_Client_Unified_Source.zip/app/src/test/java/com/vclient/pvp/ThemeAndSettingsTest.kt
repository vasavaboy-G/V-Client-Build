package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThemeAndSettingsTest {
    @Test
    fun themeIdsAreUniqueAndMatchTheDashboard() {
        val ids = ThemeManager.all.map { it.id }
        assertEquals(listOf("neon", "purple", "emerald", "obsidian"), ids)
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun unknownThemeFallsBackToDefault() {
        assertNull(ThemeManager.byIdOrNull("nope"))
        assertEquals("neon", ThemeManager.byId("nope").id)
    }

    @Test
    fun hexFormatting() {
        assertEquals("#6366F1", ThemeManager.byId("neon").primaryHex)
        assertEquals("#A855F7", ThemeManager.byId("purple").primaryHex)
    }

    @Test
    fun everyIntDefaultIsInsideItsRange() {
        for ((key, range) in Defaults.intRanges) {
            val v = Defaults.values[key] as Int
            assertTrue("$key default $v not in $range", v in range)
        }
    }

    @Test
    fun defaultsHaveSupportedTypesOnly() {
        for ((key, v) in Defaults.values) {
            assertNotNull(key, v)
            assertTrue("$key has unsupported type", v is Boolean || v is Int || v is Float || v is String)
        }
    }

    @Test
    fun defaultColoursAreValidHex() {
        assertTrue(Defaults.hexColor.matches(Defaults.values[Keys.HUD_COLOR] as String))
        assertTrue(Defaults.hexColor.matches(Defaults.values[Keys.XH_COLOR] as String))
        assertTrue((Defaults.values[Keys.XH_SHAPE] as String) in Defaults.shapes)
    }
}

class CustomThemeTest {
    @Test
    fun presetIsUsedWhenCustomIsOff() {
        assertEquals("purple", ThemeManager.resolve("purple", false, "#112233", "#445566").id)
    }

    @Test
    fun customColoursWinWhenOnAndValid() {
        val t = ThemeManager.resolve("neon", true, "#112233", "#445566")
        assertEquals("custom", t.id)
        assertEquals("#112233", t.primaryHex)
        assertEquals("#445566", t.accentHex)
    }

    @Test
    fun invalidCustomColourFallsBackToPreset() {
        assertEquals("neon", ThemeManager.resolve("neon", true, "red", "#445566").id)
    }
}

class WorldSettingsTest {
    @Test
    fun worldDefaultsExistAndAddonModulesStartOff() {
        assertEquals("auto", Defaults.values[Keys.WORLD_MODE])
        assertEquals("", Defaults.values[Keys.ADDON_API_VERSION])
        for (id in Addon.ids) assertEquals(false, Defaults.values[Addon.keyOn(id)])
    }
}

package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Test

class ConfigProfilesTest {
    @Test
    fun safeNameStripsPathAndSymbols() {
        assertEquals("PvP 1", ConfigProfiles.safeName("  PvP 1  "))
        assertEquals("etcpasswd", ConfigProfiles.safeName("../etc/passwd"))
        assertEquals("", ConfigProfiles.safeName("///"))
    }

    @Test
    fun safeNameIsCapped() {
        assertEquals(ConfigProfiles.MAX_NAME, ConfigProfiles.safeName("a".repeat(100)).length)
    }
}

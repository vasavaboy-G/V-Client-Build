package com.vclient.pvp

import org.json.JSONObject
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

class HudProfilesTest {
    private lateinit var dir: File
    private lateinit var file: File
    private val ids = Widgets.ids

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("hudtest").toFile()
        file = File(dir, "hud_profiles.json")
    }

    @After
    fun tearDown() {
        dir.deleteRecursively()
    }

    private fun profiles(): HudProfiles = HudProfiles(file, ids) { HudDefaults.element(it) }.also { it.load() }

    @Test
    fun firstLoadCreatesDefaultProfileWithEveryElement() {
        val p = profiles()
        assertEquals(listOf("Default"), p.names())
        assertEquals("Default", p.active())
        assertEquals(ids.toSet(), p.elements().keys)
        assertTrue(file.isFile)
    }

    @Test
    fun editsSurviveARestart() {
        val p = profiles()
        val e = p.element("fps")
        p.setElement("fps", e.copy(style = e.style.copy(scale = 2f, textColor = 0xFFAA00, borderDp = 3), landscape = HudPos(0.4f, 0.3f)))
        val again = profiles()
        val r = again.element("fps")
        assertEquals(2f, r.style.scale, 0f)
        assertEquals(0xFFAA00, r.style.textColor)
        assertEquals(3, r.style.borderDp)
        assertEquals(0.4f, r.landscape.x, 0.0001f)
        assertEquals(0.3f, r.landscape.y, 0.0001f)
    }

    @Test
    fun portraitAndLandscapePositionsAreIndependent() {
        val p = profiles()
        val before = p.element("clock")
        p.setPosition("clock", true, 0.7f, 0.8f)
        val after = p.element("clock")
        assertEquals(before.portrait, after.portrait)
        assertEquals(0.7f, after.landscape.x, 0.0001f)
        p.setPosition("clock", false, 0.1f, 0.2f)
        assertEquals(0.7f, p.element("clock").landscape.x, 0.0001f)
    }

    @Test
    fun positionsAreClampedWhenStored() {
        val p = profiles()
        p.setPosition("clock", false, 5f, -2f)
        assertEquals(1f, p.element("clock").portrait.x, 0f)
        assertEquals(0f, p.element("clock").portrait.y, 0f)
    }

    @Test
    fun resetElementAndResetAll() {
        val p = profiles()
        val def = HudDefaults.element("clock")
        p.setPosition("clock", true, 0.9f, 0.9f)
        p.setPosition("battery", true, 0.9f, 0.9f)
        p.resetElement("clock")
        assertEquals(def.landscape, p.element("clock").landscape)
        assertEquals(0.9f, p.element("battery").landscape.x, 0.0001f)
        p.resetActive()
        assertEquals(HudDefaults.element("battery").landscape, p.element("battery").landscape)
    }

    @Test
    fun profileLifecycle() {
        val p = profiles()
        assertTrue(p.create("PvP"))
        assertFalse(p.create("PvP"))                 // duplicate name
        assertFalse(p.create("///"))                 // empty after cleaning
        assertTrue(p.switchTo("PvP"))
        p.setPosition("clock", true, 0.6f, 0.6f)
        assertTrue(p.duplicate("PvP", "PvP copy"))
        assertTrue(p.switchTo("PvP copy"))
        assertEquals(0.6f, p.element("clock").landscape.x, 0.0001f)
        assertTrue(p.rename("PvP copy", "Flat"))
        assertEquals("Flat", p.active())
        assertFalse(p.rename("Flat", "PvP"))         // name taken
        assertTrue(p.delete("Flat"))
        assertEquals("Default", p.active())
        assertTrue(p.names().contains("PvP"))
    }

    @Test
    fun lastProfileCannotBeDeletedAndDeletingActiveActivatesAnother() {
        val p = profiles()
        assertFalse(p.delete("Default"))
        p.create("A")
        p.switchTo("A")
        assertTrue(p.delete("A"))
        assertTrue(p.active() in p.names())
        assertEquals(1, p.names().size)
    }

    @Test
    fun profileCountIsLimited() {
        val p = profiles()
        var made = 0
        for (i in 0 until 40) if (p.create("P$i")) made++
        assertEquals(HudProfiles.MAX_PROFILES - 1, made)
    }

    @Test
    fun exportImportRoundTripCreatesANewProfileAndNeverOverwrites() {
        val p = profiles()
        p.setPosition("fps", true, 0.33f, 0.44f)
        val text = p.exportText("Default")!!
        assertEquals(HudJson.FORMAT, JSONObject(text).getString("format"))
        val name = p.importText(text, "Backup")
        assertEquals("Backup", name)
        p.switchTo("Backup")
        assertEquals(0.33f, p.element("fps").landscape.x, 0.0001f)
        val second = p.importText(text, "Backup")
        assertEquals("Backup 2", second)
        assertEquals(setOf("Default", "Backup", "Backup 2"), p.names().toSet())
    }

    @Test
    fun importRejectsGarbageAndWrongFormat() {
        val p = profiles()
        assertNull(p.importText("{not json", "x"))
        assertNull(p.importText("{\"format\":\"something-else\",\"elements\":{}}", "x"))
        assertNull(p.importText("{\"format\":\"${HudJson.FORMAT}\"}", "x"))
        assertEquals(1, p.names().size)
    }

    @Test
    fun importClampsHostileValues() {
        val p = profiles()
        val text = JSONObject()
            .put("format", HudJson.FORMAT).put("version", 1)
            .put("elements", JSONObject().put("fps", JSONObject().put("scale", 999).put("x", 50).put("y", -9).put("textColor", "nope").put("width", 1)))
            .toString()
        val n = p.importText(text, "Evil")!!
        p.switchTo(n)
        val e = p.element("fps")
        assertEquals(3f, e.style.scale, 0f)
        assertEquals(1f, e.portrait.x, 0f)
        assertEquals(0f, e.portrait.y, 0f)
        assertEquals(HudDefaults.element("fps").style.textColor, e.style.textColor)   // invalid colour falls back
        assertEquals(40, e.style.widthDp)
    }

    @Test
    fun corruptFileIsKeptAsBackupAndDefaultsAreUsed() {
        file.writeText("{{{ not json")
        val p = profiles()
        assertEquals(listOf("Default"), p.names())
        assertTrue(File(dir, "hud_profiles.json.corrupt").isFile)
    }

    @Test
    fun elementsAddedByAnAppUpdateAreFilledInWithoutTouchingOthers() {
        val p = profiles()
        p.setPosition("clock", true, 0.5f, 0.5f)
        // Simulate an older file that does not know the "combo" element.
        val root = JSONObject(file.readText())
        root.getJSONObject("profiles").getJSONObject("Default").getJSONObject("elements").remove("combo")
        file.writeText(root.toString())
        val again = profiles()
        assertNotNull(again.element("combo"))
        assertEquals(0.5f, again.element("clock").landscape.x, 0.0001f)
    }

    @Test
    fun globalLookIsAppliedToEveryElement() {
        val p = profiles()
        p.applyGlobalLook(20f, 0x00FF00, 50)
        for (id in ids) {
            val s = p.element(id).style
            assertEquals(20f, s.textSizeSp, 0f)
            assertEquals(0x00FF00, s.textColor)
            assertEquals(50, s.textOpacity)
            assertEquals(35, s.bgOpacity)
        }
    }

    @Test
    fun activeProfileIsRememberedAcrossRestarts() {
        val p = profiles()
        p.create("Second")
        p.switchTo("Second")
        assertEquals("Second", profiles().active())
    }
}

class HudJsonTest {
    @Test
    fun hexParsing() {
        assertEquals(0xFFAA00, HudJson.parseHex("#FFAA00", 0))
        assertEquals(0xFFAA00, HudJson.parseHex("ffaa00", 0))
        assertEquals(7, HudJson.parseHex("red", 7))
        assertEquals(7, HudJson.parseHex(null, 7))
        assertEquals("#00FF66", HudJson.hex(0x00FF66))
    }

    @Test
    fun elementRoundTrip() {
        val e = HudElement("x", HudStyle(scale = 1.5f, textSizeSp = 20f, widthDp = 120, heightDp = 40, textColor = 0x112233, bgColor = 0x445566,
            textOpacity = 80, bgOpacity = 30, borderColor = 0x778899, borderDp = 2, radiusDp = 12), HudPos(0.1f, 0.2f), HudPos(0.3f, 0.4f))
        val back = HudJson.elementFromJson("x", HudJson.elementToJson(e), HudDefaults.element("clock"))
        assertEquals(e.style, back.style)
        assertEquals(e.portrait.x, back.portrait.x, 0.0001f)
        assertEquals(e.landscape.y, back.landscape.y, 0.0001f)
    }

    @Test
    fun missingFieldsKeepTheBase() {
        val base = HudDefaults.element("clock")
        val r = HudJson.elementFromJson("clock", JSONObject().put("scale", 2), base)
        assertEquals(2f, r.style.scale, 0f)
        assertEquals(base.style.textSizeSp, r.style.textSizeSp, 0f)
        assertEquals(base.portrait, r.portrait)
    }
}

class HudDefaultsTest {
    @Test
    fun everyDefaultIsOnScreenInBothOrientations() {
        for (id in Widgets.ids) {
            val e = HudDefaults.element(id)
            for (p in listOf(e.portrait, e.landscape)) {
                assertTrue("$id x=${p.x}", p.x in 0f..1f)
                assertTrue("$id y=${p.y}", p.y in 0f..0.97f)
            }
        }
    }

    @Test
    fun existingElementsKeepTheirOldGridPositions() {
        val b = HudDefaults.element("battery")
        assertEquals(0.02f, b.portrait.x, 0.0001f); assertEquals(0.04f, b.portrait.y, 0.0001f)
        val c = HudDefaults.element("clock")
        assertEquals(0.02f, c.portrait.x, 0.0001f); assertEquals(0.16f, c.portrait.y, 0.0001f)
    }

    @Test
    fun gameElementsDoNotShareAPositionInEitherOrientation() {
        val ids = Widgets.ids.filter { it in GameData.needsGame }
        assertEquals(ids.size, ids.map { HudDefaults.element(it).landscape }.toSet().size)
        assertEquals(ids.size, ids.map { HudDefaults.element(it).portrait }.toSet().size)
    }
}

class GameDataTest {
    @Test
    fun noGameValueIsEverInventedWithoutARealSource() {
        assertNull(GameData.fps())
        assertNull(GameData.attackCps())
        assertNull(GameData.combo())
        assertEquals("FPS: Needs Native Integration", GameData.text("fps", "FPS"))
        assertEquals("Attack CPS: Needs Native Integration", GameData.text("attack_cps", "Attack CPS"))
        for (id in GameData.needsGame) assertEquals(id, "needs_native", GameData.status(id))
    }

    @Test
    fun androidMeasuredElementsAreNotMarkedAsNeedingNative() {
        for (id in listOf("battery", "clock", "ram", "storage", "refresh", "uptime", "ping", "cps", "custom")) {
            assertEquals(id, "android", GameData.status(id))
        }
    }

    @Test
    fun displayRefreshAndTouchCpsAreNeverTreatedAsGameData() {
        assertFalse("refresh" in GameData.needsGame)
        assertEquals("Touch CPS", Widgets.labels["cps"])
        assertEquals("FPS", Widgets.labels["fps"])
    }
}

class VisibilityDebounceTest {
    @Test
    fun showingIsImmediateHidingNeedsConsecutiveMisses() {
        val d = VisibilityDebounce(3)
        assertTrue(d.next(true))
        assertTrue(d.next(false))     // one odd event (keyboard, shade) must not hide anything
        assertTrue(d.next(false))
        assertFalse(d.next(false))    // third miss in a row hides
        assertTrue(d.next(true))      // and coming back shows at once
    }

    @Test
    fun aSingleGoodAnswerResetsTheMissCount() {
        val d = VisibilityDebounce(3)
        d.next(false); d.next(false)
        assertTrue(d.next(true))
        assertTrue(d.next(false))
        assertTrue(d.next(false))
        assertFalse(d.next(false))
    }
}

package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NativeCapabilityTest {
    private fun env(
        abis: List<String> = listOf("arm64-v8a"),
        sdk: Int = 34,
        installed: Boolean = true,
        version: String? = "1.26.40.5",
        lib: Boolean = true
    ) = NativeEnv(abis, sdk, installed, version, lib)

    @Test
    fun parsesBothVersionStyles() {
        assertEquals(listOf(1, 21, 80, 3), NativeCapability.parseVersion("1.21.80.3"))
        assertEquals(listOf(1, 26, 40, 2), NativeCapability.parseVersion("26.40.2"))
        assertEquals(listOf(1, 26, 40, 5), NativeCapability.parseVersion("1.26.40.5"))
        assertNull(NativeCapability.parseVersion("beta"))
        assertNull(NativeCapability.parseVersion(null))
    }

    @Test
    fun comparesVersions() {
        assertTrue(NativeCapability.compare(listOf(1, 21, 79), listOf(1, 21, 80)) < 0)
        assertEquals(0, NativeCapability.compare(listOf(1, 21, 80), listOf(1, 21, 80, 0)))
        assertTrue(NativeCapability.compare(listOf(1, 26, 0), listOf(1, 21, 80)) > 0)
    }

    @Test
    fun thisBuildReportsNotBuiltAndNeverVerified() {
        // The project ships without a native tier and without any verified version. A change here must be deliberate.
        assertFalse(NativeCapability.TIER_IMPLEMENTED)
        assertTrue(NativeCapability.VERIFIED_VERSIONS.isEmpty())
        val st = NativeCapability.evaluate(env())
        assertEquals("not_built", st.code)
        assertFalse(st.verified)
    }

    @Test
    fun noEnvironmentCanReachVerifiedWithoutAVerifiedVersionList() {
        // Even if the tier were built, an empty verified list can only ever give "unverified".
        assertFalse(NativeCapability.evaluate(env()).verified)
        assertFalse(NativeCapability.evaluate(env(version = "1.21.80.3")).verified)
    }
}

package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class AddonBuilderTest {
    @Test
    fun apiVersionMustLookLikeAVersion() {
        assertTrue(AddonBuilder.isValidApiVersion("2.9.0"))
        assertTrue(AddonBuilder.isValidApiVersion("1.21.0"))
        assertFalse(AddonBuilder.isValidApiVersion(""))
        assertFalse(AddonBuilder.isValidApiVersion("2.9"))
        assertFalse(AddonBuilder.isValidApiVersion("2.9.0-beta"))
        assertFalse(AddonBuilder.isValidApiVersion("2.9.0\"}"))
    }

    @Test
    fun uuidsAreStableSoReimportsReplaceThePack() {
        val a = AddonBuilder.deterministicUuid("vclient.stats.bp.header")
        assertEquals(a, AddonBuilder.deterministicUuid("vclient.stats.bp.header"))
        assertFalse(a == AddonBuilder.deterministicUuid("vclient.stats.bp.script"))
        assertTrue(Regex("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$").matches(a))
    }

    @Test
    fun manifestHasScriptModuleDependencyAndBuildNumber() {
        val m = AddonBuilder.manifestJson("2.9.0", 7)
        assertTrue(m.contains("\"type\": \"script\""))
        assertTrue(m.contains("\"language\": \"javascript\""))
        assertTrue(m.contains("\"entry\": \"scripts/main.js\""))
        assertTrue(m.contains("\"module_name\": \"@minecraft/server\", \"version\": \"2.9.0\""))
        assertTrue(m.contains("\"version\": [1, 0, 7]"))
        assertTrue(m.contains("\"min_engine_version\": [1, 21, 0]"))
    }

    @Test
    fun configOnlyEnablesWhatTheUserSwitchedOn() {
        val js = AddonBuilder.configJs(mapOf("coords" to true, "combo" to true), 3, false)
        assertTrue(js.contains("coords: true"))
        assertTrue(js.contains("combo: true"))
        assertTrue(js.contains("armor: false"))
        assertTrue(js.contains("attack_cps: false"))
        assertTrue(js.contains("intervalTicks: 3"))
        assertTrue(js.contains("diagnostic: false"))
    }

    @Test
    fun entriesContainEveryScriptAndZipRoundTrips() {
        val entries = AddonBuilder.buildEntries("2.9.0", 1, mapOf("coords" to true), 2, true) { path -> ("// " + path).toByteArray() }
        assertTrue(entries.containsKey("V_CLIENT_Stats_BP/manifest.json"))
        assertTrue(entries.containsKey("V_CLIENT_Stats_BP/scripts/generated_config.js"))
        for (f in AddonBuilder.staticFiles) assertTrue(f, entries.containsKey("V_CLIENT_Stats_BP/$f"))

        val names = ArrayList<String>()
        ZipInputStream(ByteArrayInputStream(AddonBuilder.zipBytes(entries))).use { z ->
            var e = z.nextEntry
            while (e != null) { names.add(e.name); e = z.nextEntry }
        }
        assertEquals(entries.keys.toList(), names)
    }
}

class ServerLinksTest {
    @Test
    fun cleanRejectsBadInput() {
        assertEquals(null, ServerLinks.clean("", "play.example.com", 19132))
        assertEquals(null, ServerLinks.clean("A", "", 19132))
        assertEquals(null, ServerLinks.clean("A", "bad host", 19132))
        assertEquals(null, ServerLinks.clean("A", "play.example.com", 0))
        assertEquals(null, ServerLinks.clean("A", "play.example.com", 70000))
    }

    @Test
    fun cleanStripsNameSymbolsAndKeepsValidOnes() {
        val s = ServerLinks.clean("My <Server>\t1", " play.example.com ", 19132)!!
        assertEquals("My Server1", s.name)
        assertEquals("play.example.com", s.host)
    }

    @Test
    fun addAndConnectLinksUseMinecraftsOwnSchemes() {
        val s = SavedServer("My Server", "play.example.com", 19132)
        assertEquals("minecraft://?addExternalServer=My%20Server%7Cplay.example.com:19132", ServerLinks.addServerUri(s))
        assertEquals("minecraft://connect/?serverUrl=play.example.com&serverPort=19132", ServerLinks.connectUri(s))
    }
}

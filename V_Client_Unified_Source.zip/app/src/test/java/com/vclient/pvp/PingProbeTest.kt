package com.vclient.pvp

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test
import java.nio.ByteBuffer

class PingProbeTest {
    @Test
    fun rakNetUnconnectedPingLayout() {
        val p = PingProbe.buildPing(1234L)
        assertEquals(33, p.size)
        assertEquals(1, p[0].toInt())                                   // ID_UNCONNECTED_PING
        assertEquals(1234L, ByteBuffer.wrap(p, 1, 8).long)              // client time
        assertArrayEquals(PingProbe.MAGIC, p.copyOfRange(9, 25))        // offline-message magic
    }

    @Test
    fun magicIsTheDocumentedRakNetSequence() {
        val hex = PingProbe.MAGIC.joinToString("") { String.format("%02x", it) }
        assertEquals("00ffff00fefefefefdfdfdfd12345678", hex)
    }

    @Test
    fun textStates() {
        val probe = PingProbe()
        assertEquals("Ping: ...", probe.text())
        probe.lastMs = 42
        assertEquals("Ping 42 ms", probe.text())
        probe.lastMs = -2
        assertEquals("Ping: no reply", probe.text())
        probe.configure("example.org", 19132)
        assertEquals("Server ping: no reply", probe.text())
    }

    @Test
    fun widgetDefaultsAreDistinctAndInRange() {
        val seen = HashSet<Pair<Int, Int>>()
        for (id in Widgets.ids) {
            val x = Defaults.values[Widgets.keyX(id)] as Int
            val y = Defaults.values[Widgets.keyY(id)] as Int
            assertEquals(true, x in 0..95 && y in 0..95)
            assertEquals("overlapping default position for $id", true, seen.add(Pair(x, y)))
        }
    }
}

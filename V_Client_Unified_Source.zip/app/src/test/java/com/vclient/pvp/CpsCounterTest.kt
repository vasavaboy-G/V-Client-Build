package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Test

class CpsCounterTest {
    @Test
    fun countsOnlyEventsInsideTheWindow() {
        var t = 0L
        val c = CpsCounter(1000L) { t }
        c.record()
        t = 500L
        c.record()
        assertEquals(2, c.current())
        t = 1000L
        assertEquals(1, c.current())
        t = 1600L
        assertEquals(0, c.current())
        assertEquals(2L, c.total)
        assertEquals(2, c.max)
    }

    @Test
    fun resetClearsEverything() {
        var t = 0L
        val c = CpsCounter(1000L) { t }
        c.record(); c.record()
        c.reset()
        assertEquals(0, c.current())
        assertEquals(0L, c.total)
        assertEquals(0, c.max)
    }
}

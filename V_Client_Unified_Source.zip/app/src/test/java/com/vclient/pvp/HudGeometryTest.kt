package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The vectors below are the same ones used by addon-tests/hud_geometry.test.js for the editor page. */
class HudGeometryTest {
    @Test
    fun posPxKeepsTheElementFullyOnScreen() {
        assertEquals(0, HudGeometry.posPx(0f, 1080, 200))
        assertEquals(880, HudGeometry.posPx(1f, 1080, 200))
        assertEquals(540, HudGeometry.posPx(0.5f, 1080, 200))
        assertEquals(880, HudGeometry.posPx(0.9f, 1080, 200))
        assertEquals(22, HudGeometry.posPx(0.02f, 1080, 200))
        assertEquals(0, HudGeometry.posPx(0.5f, 100, 200))
        assertEquals(0, HudGeometry.posPx(Float.NaN, 1080, 200))
        assertEquals(0, HudGeometry.posPx(-3f, 1080, 200))
        assertEquals(880, HudGeometry.posPx(9f, 1080, 200))
    }

    @Test
    fun normalizedLayoutMapsToDifferentResolutions() {
        assertEquals(270, HudGeometry.posPx(0.25f, 1080, 100))
        assertEquals(600, HudGeometry.posPx(0.25f, 2400, 100))
        assertEquals(180, HudGeometry.posPx(0.25f, 720, 100))
    }

    @Test
    fun normFromPxClampsAndHandlesZeroScreen() {
        assertEquals(0f, HudGeometry.normFromPx(0, 1080), 0f)
        assertEquals(0.5f, HudGeometry.normFromPx(540, 1080), 0f)
        assertEquals(1f, HudGeometry.normFromPx(5000, 1080), 0f)
        assertEquals(0f, HudGeometry.normFromPx(10, 0), 0f)
    }

    @Test
    fun orientation() {
        assertTrue(HudGeometry.isLandscape(2400, 1080))
        assertFalse(HudGeometry.isLandscape(1080, 2400))
        assertFalse(HudGeometry.isLandscape(1000, 1000))
    }

    @Test
    fun clampStyleEnforcesEveryLimit() {
        val s = HudGeometry.clampStyle(
            HudStyle(scale = 99f, textSizeSp = 1f, widthDp = 5, heightDp = 9999, textOpacity = 500, bgOpacity = -4, borderDp = 99, radiusDp = 99)
        )
        assertEquals(3f, s.scale, 0f)
        assertEquals(8f, s.textSizeSp, 0f)
        assertEquals(40, s.widthDp)
        assertEquals(400, s.heightDp)
        assertEquals(100, s.textOpacity)
        assertEquals(0, s.bgOpacity)
        assertEquals(10, s.borderDp)
        assertEquals(40, s.radiusDp)
        assertEquals(1f, HudGeometry.clampStyle(HudStyle(scale = Float.NaN)).scale, 0f)
        assertEquals(0, HudGeometry.clampStyle(HudStyle(widthDp = 0)).widthDp)      // 0 stays "auto"
    }

    @Test
    fun clampPosKeepsValuesInRange() {
        val p = HudGeometry.clampPos(HudPos(-1f, 7f))
        assertEquals(0f, p.x, 0f)
        assertEquals(1f, p.y, 0f)
        assertEquals(0f, HudGeometry.clampPos(HudPos(Float.NaN, Float.POSITIVE_INFINITY)).x, 0f)
    }

    @Test
    fun sizePxIsZeroForAuto() {
        assertEquals(0, HudGeometry.sizePx(0, 1f, 3f))
        assertEquals(300, HudGeometry.sizePx(100, 1f, 3f))
        assertEquals(750, HudGeometry.sizePx(100, 2.5f, 3f))
    }
}

/** Expected values were computed with an independent port of the same algorithm (see PROGRESS_REPORT). */
class MenuPlacementTest {
    // 1080 px wide portrait phone: icon 156 px, desired 990, min 720, margin 12, gap 18
    @Test
    fun iconOnTheLeftOpensToTheRight() {
        val r = MenuPlacement.compute(0, 156, 1080, 990, 720, 12, 18)
        assertTrue(r.opensRight)
        assertEquals(174, r.x)               // right next to the icon, never under it
        assertEquals(894, r.width)
    }

    @Test
    fun iconOnTheRightOpensToTheLeft() {
        val r = MenuPlacement.compute(1080 - 156, 156, 1080, 990, 720, 12, 18)
        assertFalse(r.opensRight)
        assertEquals(12, r.x)
        assertEquals(894, r.width)
    }

    @Test
    fun landscapeBothSides() {
        val left = MenuPlacement.compute(100, 156, 2400, 1008, 720, 12, 18)
        assertTrue(left.opensRight); assertEquals(274, left.x); assertEquals(1008, left.width)
        val right = MenuPlacement.compute(2400 - 156, 156, 2400, 1008, 720, 12, 18)
        assertFalse(right.opensRight); assertEquals(1218, right.x); assertEquals(1008, right.width)
    }

    @Test
    fun noSideWithRoomUsesTheScreenAndStaysInside() {
        val r = MenuPlacement.compute(400, 156, 1080, 990, 720, 12, 18)
        assertEquals(45, r.x)
        assertEquals(990, r.width)
        val t = MenuPlacement.compute(300, 100, 700, 640, 500, 10, 10)
        assertEquals(30, t.x)
        assertEquals(640, t.width)
    }

    @Test
    fun menuNeverLeavesTheScreen() {
        for (screenW in intArrayOf(500, 720, 1080, 1440, 2400)) {
            var iconX = 0
            while (iconX <= screenW - 100) {
                val r = MenuPlacement.compute(iconX, 100, screenW, 900, 400, 8, 12)
                assertTrue("x=${r.x} iconX=$iconX screen=$screenW", r.x >= 8)
                assertTrue("right edge ${r.x + r.width} iconX=$iconX screen=$screenW", r.x + r.width <= screenW - 8 || r.width > screenW - 16)
                iconX += 37
            }
        }
    }
}

class IconPlacementTest {
    @Test
    fun fractionsMapToPixelsInsideTheScreen() {
        assertEquals(0, IconPlacement.px(0f, 1080, 156))
        assertEquals(924, IconPlacement.px(1f, 1080, 156))
        assertEquals(462, IconPlacement.px(0.5f, 1080, 156))
        assertEquals(924, IconPlacement.px(2f, 1080, 156))
        assertEquals(0, IconPlacement.px(Float.NaN, 1080, 156))
    }

    @Test
    fun pixelsMapBackToFractions() {
        assertEquals(0f, IconPlacement.frac(0, 1080, 156), 0f)
        assertEquals(1f, IconPlacement.frac(924, 1080, 156), 0f)
        assertEquals(0.5f, IconPlacement.frac(462, 1080, 156), 0f)
        assertEquals(1f, IconPlacement.frac(5000, 1080, 156), 0f)
        assertEquals(0f, IconPlacement.frac(10, 100, 156), 0f)
    }

    @Test
    fun positionSurvivesRotation() {
        // Same fractions on a landscape screen of the same phone still land inside it.
        val xf = IconPlacement.frac(924, 1080, 156)
        val yf = IconPlacement.frac(300, 2400, 156)
        assertEquals(2244, IconPlacement.px(xf, 2400, 156))
        assertTrue(IconPlacement.px(yf, 1080, 156) in 0..(1080 - 156))
    }

    @Test
    fun snapPicksTheNearestSide() {
        assertEquals(0, IconPlacement.snapX(100, 1080, 156))
        assertEquals(924, IconPlacement.snapX(600, 1080, 156))
        assertEquals(0, IconPlacement.snapX(462, 1080, 156))
    }
}

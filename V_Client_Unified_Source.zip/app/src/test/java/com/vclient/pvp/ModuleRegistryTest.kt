package com.vclient.pvp

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ModuleRegistryTest {
    @Test
    fun idsAreUnique() {
        val ids = ModuleRegistry.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test
    fun everySwitchableModuleHasARealBooleanSetting() {
        for (m in ModuleRegistry.all.filter { it.requires != Requirement.GAME_INTERNAL }) {
            val key = ModuleRegistry.toggleKey(m.id)
            assertNotNull(m.id, key)
            assertTrue("${m.id} key $key has no boolean default", Defaults.values[key!!] is Boolean)
        }
    }

    @Test
    fun everyHudWidgetIsARegisteredModuleAndOverlayOnesAreSwitchedByTheirWidgetKey() {
        for (id in Widgets.ids) {
            val m = ModuleRegistry.byId(id)
            assertNotNull("HUD element $id has no module", m)
            assertTrue(ModuleRegistry.hasHudElement(id))
            if (m!!.requires == Requirement.ANDROID_OVERLAY) assertEquals(Widgets.keyOn(id), ModuleRegistry.toggleKey(id))
        }
        assertTrue(ModuleRegistry.hasHudElement("crosshair"))
    }

    @Test
    fun hudElementsThatNeedGameDataAreNotOverlayModules() {
        for (id in GameData.needsGame) {
            assertTrue("$id needs game data but claims to be an overlay module", ModuleRegistry.byId(id)!!.requires != Requirement.ANDROID_OVERLAY)
        }
    }

    @Test
    fun addonAndNativeModuleListsMatchSettings() {
        assertEquals(Addon.ids.toSet(), ModuleRegistry.addonModules().map { it.id }.toSet())
        assertEquals(Native.ids.toSet(), ModuleRegistry.nativeModules().map { it.id }.toSet())
    }

    @Test
    fun screenTapsAreNeverCalledAttackCps() {
        val taps = ModuleRegistry.byId("cps")!!
        assertEquals("Touch CPS", taps.name)
        assertFalse(taps.name.contains("attack", ignoreCase = true))
        assertTrue(taps.description.contains("NOT attack CPS"))
        assertEquals(Requirement.WORLD_ADDON, ModuleRegistry.byId("attack_cps")!!.requires)
    }

    @Test
    fun fpsAndFrameTimeNeedTheNativeTierAndHaveAReason() {
        for (id in listOf("fps", "frame_time")) {
            val m = ModuleRegistry.byId(id)!!
            assertEquals(Requirement.NATIVE, m.requires)
            assertTrue(m.reason.isNotBlank())
        }
    }

    @Test
    fun noModuleClaimsToBeNativeWithoutTheNativeTier() {
        // With the default (not built) native state, every native-requiring module must be locked.
        for (m in ModuleRegistry.nativeModules()) {
            val st = Integrations.statusFor(m, WorldMode.AUTO, true)
            assertEquals(m.id, "needs_native", st.code)
        }
    }
}

class IntegrationsTest {
    private fun m(id: String) = ModuleRegistry.byId(id)!!
    private val verified = NativeState("verified", "Verified on a real phone for Minecraft 1.26.40.", true)
    private val unverified = NativeState("unverified", "Minecraft 1.26.40 has not been verified on a real phone.", false)

    @Test
    fun overlayModulesWorkInEveryMode() {
        for (mode in WorldMode.values()) {
            assertEquals("available", Integrations.statusFor(m("battery"), mode, false).code)
        }
    }

    @Test
    fun addonModulesAreUnavailableOnPublicServersWithoutNative() {
        val st = Integrations.statusFor(m("coords"), WorldMode.PUBLIC, true)
        assertEquals("unavailable", st.code)
        assertTrue(st.text.contains("public servers"))
    }

    @Test
    fun addonModulesNeedSetupInPersonalWorldsUntilSent() {
        assertEquals("setup", Integrations.statusFor(m("combo"), WorldMode.PERSONAL, false).code)
        assertEquals("setup_done", Integrations.statusFor(m("combo"), WorldMode.PERSONAL, true).code)
    }

    @Test
    fun autoModeDoesNotPretendToKnowTheWorldType() {
        assertEquals("personal_only", Integrations.statusFor(m("armor"), WorldMode.AUTO, false).code)
    }

    @Test
    fun unverifiedNativeNeverUnlocksAnything() {
        assertEquals("needs_native", Integrations.statusFor(m("fps"), WorldMode.PERSONAL, true, unverified).code)
        assertEquals("unavailable", Integrations.statusFor(m("coords"), WorldMode.PUBLIC, true, unverified).code)
    }

    @Test
    fun verifiedNativeUnlocksNativeModulesAndPublicServerStats() {
        assertEquals("available", Integrations.statusFor(m("fps"), WorldMode.PUBLIC, false, verified).code)
        assertEquals("available", Integrations.statusFor(m("coords"), WorldMode.PUBLIC, false, verified).code)
        // overlay-only module without native capability is unaffected
        assertEquals("available", Integrations.statusFor(m("battery"), WorldMode.PUBLIC, false, verified).code)
    }

    @Test
    fun worldModeParsingFallsBackToAuto() {
        assertEquals(WorldMode.PUBLIC, WorldMode.from("public"))
        assertEquals(WorldMode.AUTO, WorldMode.from("nonsense"))
        assertEquals(WorldMode.AUTO, WorldMode.from(null))
    }
}

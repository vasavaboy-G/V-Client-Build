# V CLIENT development progress report

Updated at the start of the "genuine integration" stage. Nothing in this report claims an APK was built or that anything
ran inside Minecraft: the authoring environment has no network, no Android SDK/NDK, no device and no Minecraft.

## Inventory (from V_Client_Unified_Source.zip)
21 Kotlin files (about 2,900 lines), 6 Kotlin test files (about 370 lines), 2 HTML UIs plus the add-on JavaScript (about 2,200 lines),
11 JavaScript unit tests, 1 GitHub Actions workflow. No native (C/C++) code yet.

## Component status
Legend: DONE = implemented; VERIFIED-HERE = checked in this environment; DEVICE = still needs a phone run.

| Component | Implemented | Verified here | Still needed |
|---|---|---|---|
| Floating icon, overlay service, HUD widgets, HUD editor | Yes (earlier stages) | JVM unit tests for counters/ping/settings only | DEVICE: runtime, permissions, lifecycle |
| Overlay crosshair | Yes | No | DEVICE: alignment with game's aim point |
| ClickGUI (WebView menu): categories, expandable cards, animated toggles, mode selector, status labels | Yes | Headless-browser test (stubbed bridge) | DEVICE: WebView behaviour; search box and keybinds not built |
| Module registry with requirements and per-mode status | Yes | Kotlin tests written, not compiled | CI compile |
| Themes, custom colours | Yes | Pure logic tests written | DEVICE |
| Config profiles (save/load) | Yes | Name sanitising tests written | DEVICE: file IO, apply-on-load |
| Server list + minecraft:// links | Yes | Link building tests written | DEVICE: which screen Minecraft opens |
| World add-on builder (.mcaddon) | Yes | Manifest/config/zip tests written | DEVICE: pack imports and loads; API version mapping |
| Add-on JavaScript (CPS, combo, direction, armor, keys, coords) | Yes | 11 Node tests pass | DEVICE: game event glue |
| Pack library / sender | Yes (earlier) | No | DEVICE |
| GitHub Actions workflow | Yes | YAML parses only | Never run; first run may reveal compile errors |

## Broken / suspect (none confirmed, because nothing has been compiled)
- All Kotlin written in the last two stages is uncompiled. Expect a few compile errors on the first CI run.
- No Gradle wrapper jar; CI uses Gradle 8.7 directly.
- Housekeeping fixed this stage: two test screenshots had ended up in the project root; moved to docs/screenshots/.

## Not started
Native integration (launcher + in-game module), in-game rendering, FPS / frame time, real attack-input events on public servers,
zoom, free look, Replay Studio, export tools, performance measurement harness, ClickGUI search, keybinds, release signing.
See ARCHITECTURE.md for the investigation and ordered plan.

## Preserved
No existing source file, feature or test was removed.

## Native spike stage (this update)
| Item | State |
|---|---|
| Registry v2 (NATIVE requirement, native-capable flag, native status in every module) | Implemented. Kotlin tests written, not compiled. Menu behaviour headless-tested. |
| ClickGUI search | Implemented, headless-tested. |
| Native capability detection | Implemented, tests written. Reports "not built". |
| Frame statistics engine (C++) | Implemented. Host tests pass (6 test cases). |
| JNI bridge + optional CMake/Gradle native build | Written. Real compile only in CI. |
| Readiness probe | Implemented, untested on a phone. |
| LeviLauncher licence review | Incomplete (source not readable here). |
| Launcher, graphics hook, game events, zoom, Replay Studio | Not started (by the agreed order). |

## LeviLauncher review + native build stage
| Item | State |
|---|---|
| LeviLauncher source review (licences, dependencies, launch path, auth, ABIs, versions) | Done from the uploaded ZIP. Findings in LICENSING_REVIEW.md with file and line references. |
| Licence verdict | Intended reuse not permitted/advisable. No code copied. |
| Launcher approach selected | Approach 2 (runtime load of the installed game's Java), as the only compliant candidate. Not implemented. Gated by the probe. |
| Readiness probe v2 | Written (phone, Minecraft, signing cert, class-loading feasibility, XAL classes, hidden API). Read-only. Untested on a phone. |
| JNI symbol checker | Written, passes, negative test passes. Added to native-host-tests. |
| 16 KB page alignment flag for the native library | Added to CMake. |
| Real NDK/Gradle build | NOT run here (no SDK, NDK, Gradle, javac or network). Runs in CI job build-native. |
| Kotlin unit tests | NOT run here (no Kotlin compiler). Run in CI job build. |
| C++ host tests | Passed. |
| Launcher, graphics hook, game events, Replay Studio | Not started. |

## HUD, menu and icon fix stage
| Item | State |
|---|---|
| FPS / Attack CPS / Touch CPS elements and statuses | Implemented. Never show invented values. Phone check pending. |
| Visibility fixes (watcher debounce, cut-out mode, clamping, logging) | Implemented in code. Phone check pending. |
| Menu: warm WebView, adaptive side and width, 44 dp close, Back, double-tap handling, memory release | Implemented. Phone check pending. |
| Floating icon anywhere, remembered x/y, optional snap, adaptive menu | Implemented. Phone check pending. |
| Per-element HUD customization (position, size, scale, colours, opacities, border, radius, show/hide, reset) | Implemented. |
| HUD Editor screen with preview, drag, resize handles, precise fields, reset all, portrait and landscape | Implemented. Headless-browser tested (33 recorded checks, mock bridge). |
| Profiles (create, rename, duplicate, switch, delete, reset, export, import), normalized coordinates, migration | Implemented. Kotlin tests written, not run. |
| Node tests (add-on logic 11 + HUD geometry 7) | Pass (18/18) |
| C++ tests and JNI symbol check | Pass |
| Kotlin tests (87) and the Gradle/NDK builds | Not run here (no Kotlin compiler, SDK or NDK). Run in CI. |
| Debug APK | Not built here. Built by the GitHub Actions workflow. |

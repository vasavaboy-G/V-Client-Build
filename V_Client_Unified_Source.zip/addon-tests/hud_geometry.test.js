// Tests the pure geometry block (between /*GEOM-START*/ and /*GEOM-END*/) of the HUD editor page.
// The same rules are implemented in Kotlin (HudGeometry) and covered by HudGeometryTest; both use the vectors below.
import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import vm from "node:vm";

const html = fs.readFileSync(new URL("../app/src/main/assets/hud_editor.html", import.meta.url), "utf8");
const block = html.split("/*GEOM-START*/")[1].split("/*GEOM-END*/")[0];
const ctx = {};
vm.createContext(ctx);
vm.runInContext(block + "\nthis.HudGeom = HudGeom;", ctx);
const G = ctx.HudGeom;
// Results come from another vm realm; compare plain copies.
const plain = (o) => JSON.parse(JSON.stringify(o));

test("posPx keeps the element fully on screen", () => {
  assert.equal(G.posPx(0, 1080, 200), 0);
  assert.equal(G.posPx(1, 1080, 200), 880);       // far edge: flush, never off screen
  assert.equal(G.posPx(0.5, 1080, 200), 540);
  assert.equal(G.posPx(0.9, 1080, 200), 880);     // 972 would overflow, clamped
  assert.equal(G.posPx(0.02, 1080, 200), 22);
  assert.equal(G.posPx(0.5, 100, 200), 0);        // element wider than the screen
  assert.equal(G.posPx(NaN, 1080, 200), 0);
  assert.equal(G.posPx(-3, 1080, 200), 0);
  assert.equal(G.posPx(9, 1080, 200), 880);
});

test("normFromPx round trip", () => {
  assert.equal(G.normFromPx(0, 1080), 0);
  assert.equal(G.normFromPx(540, 1080), 0.5);
  assert.equal(G.normFromPx(5000, 1080), 1);
  assert.equal(G.normFromPx(10, 0), 0);
});

test("same normalized layout maps consistently to different resolutions", () => {
  const n = 0.25;
  assert.equal(G.posPx(n, 1080, 100), 270);
  assert.equal(G.posPx(n, 2400, 100), 600);
  assert.equal(G.posPx(n, 720, 100), 180);
});

test("orientation", () => {
  assert.equal(G.isLandscape(2400, 1080), true);
  assert.equal(G.isLandscape(1080, 2400), false);
  assert.equal(G.isLandscape(1000, 1000), false);
});

test("clampStyle enforces every limit", () => {
  const s = G.clampStyle({ scale: 99, textSize: 1, width: 5, height: 9999, textOpacity: 500, bgOpacity: -4, border: 99, radius: 99 });
  assert.equal(s.scale, 3);
  assert.equal(s.textSize, 8);
  assert.equal(s.width, 40);
  assert.equal(s.height, 400);
  assert.equal(s.textOpacity, 100);
  assert.equal(s.bgOpacity, 0);
  assert.equal(s.border, 10);
  assert.equal(s.radius, 40);
  assert.equal(G.clampStyle({ scale: NaN, textSize: NaN, width: 0, height: 0 }).scale, 1);
  assert.equal(G.clampStyle({ width: 0, height: 0 }).width, 0);   // 0 stays "auto"
});

test("dragRect cannot leave the screen", () => {
  const b = { w: 1000, h: 500 };
  const r = { x: 100, y: 100, w: 200, h: 50 };
  assert.deepEqual(plain(G.dragRect(r, 50, 20, b)), { x: 150, y: 120, w: 200, h: 50 });
  assert.deepEqual(plain(G.dragRect(r, -500, -500, b)), { x: 0, y: 0, w: 200, h: 50 });
  assert.deepEqual(plain(G.dragRect(r, 5000, 5000, b)), { x: 800, y: 450, w: 200, h: 50 });
});

test("resizeRect: east/south grow, west/north move the origin, always inside bounds", () => {
  const b = { w: 1000, h: 500 };
  const min = { w: 60, h: 30 }, max = { w: 900, h: 400 };
  const r = { x: 100, y: 100, w: 200, h: 100 };
  assert.deepEqual(plain(G.resizeRect(r, "se", 50, 30, b, min, max)), { x: 100, y: 100, w: 250, h: 130 });
  assert.deepEqual(plain(G.resizeRect(r, "nw", -40, -20, b, min, max)), { x: 60, y: 80, w: 240, h: 120 });
  assert.deepEqual(plain(G.resizeRect(r, "e", -500, 0, b, min, max)), { x: 100, y: 100, w: 60, h: 100 });   // min width
  assert.deepEqual(plain(G.resizeRect(r, "e", 5000, 0, b, min, max)), { x: 100, y: 100, w: 900, h: 100 });  // max width, then pushed in bounds
  const big = G.resizeRect({ x: 900, y: 450, w: 50, h: 40 }, "se", 400, 400, b, min, max);
  assert.ok(big.x >= 0 && big.y >= 0 && big.x + big.w <= 1000 && big.y + big.h <= 500);
});

import test from "node:test";
import assert from "node:assert/strict";
import { SlidingCounter } from "../app/src/main/assets/addon/scripts/lib/cps.js";
import { ComboTracker } from "../app/src/main/assets/addon/scripts/lib/combo.js";
import { cardinal, coordsText, durabilityPercent, armorText, keyStates, keysText, buildLine } from "../app/src/main/assets/addon/scripts/lib/format.js";
import { normalizeConfig, DEFAULT_CONFIG, MODULE_IDS } from "../app/src/main/assets/addon/scripts/lib/defaults.js";

test("SlidingCounter counts only events inside the window", () => {
  const c = new SlidingCounter(20);
  c.record(0); c.record(10);
  assert.equal(c.count(10), 2);
  assert.equal(c.count(20), 1);   // tick 0 has left the window
  assert.equal(c.count(31), 0);
  assert.equal(c.total, 2);
});

test("SlidingCounter handles a 15-swing second", () => {
  const c = new SlidingCounter(20);
  for (let i = 0; i < 15; i++) c.record(i); // 15 swings in 15 ticks
  assert.equal(c.count(19), 15);
});

test("Combo counts same-target hits and resets on hurt", () => {
  const k = new ComboTracker(60);
  k.hit("a", 0); k.hit("a", 10); k.hit("a", 20);
  assert.equal(k.current(20), 3);
  k.hurt();
  assert.equal(k.current(21), 0);
  assert.equal(k.best, 3);
});

test("Combo restarts on a new target and after the timeout", () => {
  const k = new ComboTracker(60);
  k.hit("a", 0); k.hit("a", 5);
  k.hit("b", 10);
  assert.equal(k.current(10), 1);
  k.hit("b", 11);
  assert.equal(k.current(200), 0);  // timed out when read
  k.hit("b", 200);
  assert.equal(k.current(200), 1);  // expired combo restarts at 1
});

test("cardinal follows Minecraft yaw (0 = south, 90 = west, 180 = north, -90 = east)", () => {
  assert.equal(cardinal(0), "S");
  assert.equal(cardinal(90), "W");
  assert.equal(cardinal(180), "N");
  assert.equal(cardinal(-180), "N");
  assert.equal(cardinal(-90), "E");
  assert.equal(cardinal(270), "E");
  assert.equal(cardinal(-135), "NE");
  assert.equal(cardinal(NaN), "?");
});

test("coordsText floors negative values like the game", () => {
  assert.equal(coordsText({ x: 10.9, y: 64.2, z: -0.1 }), "XYZ 10 64 -1");
  assert.equal(coordsText(null), "XYZ ?");
});

test("durabilityPercent", () => {
  assert.equal(durabilityPercent(0, 363), 100);
  assert.equal(durabilityPercent(363, 363), 0);
  assert.equal(durabilityPercent(181, 363), 50);
  assert.equal(durabilityPercent(0, 0), null);
  assert.equal(durabilityPercent(999, 100), 0);
});

test("armorText marks empty slots and items without durability", () => {
  const t = armorText([
    { label: "H", present: true, pct: 80 },
    { label: "C", present: false, pct: null },
    { label: "L", present: true, pct: null },
    { label: "B", present: true, pct: 0 },
  ]);
  assert.equal(t, "Armor H80 C- L* B0");
});

test("keystrokes from movement vector", () => {
  assert.equal(keysText(keyStates({ x: 0, y: 1 }, false, false)), "W---");
  assert.equal(keysText(keyStates({ x: 1, y: 1 }, true, false)), "WA-- JUMP");
  assert.equal(keysText(keyStates({ x: -1, y: -1 }, false, true)), "--SD SNEAK");
  assert.equal(keysText(keyStates({ x: 0.3, y: 0.3 }, false, false)), "----");
  assert.equal(keysText(keyStates(undefined, false, false)), "----");
});

test("buildLine skips empty parts", () => {
  assert.equal(buildLine(["a", "", "b", undefined]), "a  |  b");
  assert.equal(buildLine([]), "");
});

test("normalizeConfig rejects junk and clamps numbers", () => {
  const c = normalizeConfig({ modules: { coords: true, combo: "yes", evil: true }, intervalTicks: 999, cpsWindowTicks: "x", diagnostic: 1 });
  assert.equal(c.modules.coords, true);
  assert.equal(c.modules.combo, false);
  assert.equal("evil" in c.modules, false);
  assert.equal(c.intervalTicks, 20);
  assert.equal(c.cpsWindowTicks, DEFAULT_CONFIG.cpsWindowTicks);
  assert.equal(c.diagnostic, false);
  assert.deepEqual(Object.keys(normalizeConfig(null).modules), MODULE_IDS);
});

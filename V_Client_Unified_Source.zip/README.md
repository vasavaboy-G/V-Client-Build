# V CLIENT (Android)

One V CLIENT app for public servers and personal worlds: floating V icon, ClickGUI menu, HUD widgets,
crosshair, pack manager, server list, themes, saved configs, plus an in-game add-on for personal worlds. Minimum Android 8.0 (API 26).

No root, no Shizuku, no injection. See `FEATURE_COMPATIBILITY.md` for exactly what works and what
cannot be done from outside the game.

## Build with GitHub Actions (no PC needed)
1. Create a GitHub repository and upload the **contents** of this folder (so `.github/workflows/build.yml` is at the repo root).
2. Open the **Actions** tab. The build runs on every push; or choose *Build debug APK* > *Run workflow*.
3. When it is green, open the run and download the **V-Client-debug-apk** artifact (a zip containing `app-debug.apk`).

## Build locally
Needs JDK 17, the Android SDK (platform 34) with `ANDROID_HOME` set, and Gradle 8.7.

    gradle wrapper --gradle-version 8.7     # only if you want a wrapper; gradle-wrapper.jar is not included
    gradle testDebugUnitTest
    gradle assembleDebug

Output: `app/build/outputs/apk/debug/app-debug.apk`

## Install on a phone
1. Copy `app-debug.apk` to the phone and open it (allow *Install unknown apps* for your file manager).
2. Open V CLIENT, tap **Settings > Start overlay**, and grant *Display over other apps*.
3. Optional: grant *Usage access* (icon only shows while Minecraft is in front) and *Do Not Disturb access*.
4. Tap the floating **V** icon to open the ClickGUI.

## Public servers vs personal worlds (one app)
- Overlay features (HUD, crosshair, HUD editor, themes, configs, packs, server list) work everywhere.
- In-game stats (coordinates, direction, armor, keystrokes, attack CPS, combo) come from a small add-on that V CLIENT builds on the phone. It only runs in worlds where you enable it (personal or hosted), not on public servers.
- Minecraft FPS is not available. See `FEATURE_COMPATIBILITY.md`, `KNOWN_ISSUES.md` and `TEST_PLAN.md`.

## Project documents
`PROGRESS_REPORT.md` (what is done and verified), `ARCHITECTURE.md` (native integration investigation and plan),
`FEATURE_COMPATIBILITY.md`, `KNOWN_ISSUES.md`, `TEST_PLAN.md`.

## HUD editor
ClickGUI > **Open HUD Editor**. Drag elements in the preview, use the handles or fields to size them, style each element, and manage
profiles. See HUD_SYSTEM.md and BUGFIX_REPORT.md.

# V CLIENT: unfinished modules, bugs and compatibility limits

Status as of this development stage. "Untested" means written but not yet run on a phone with Minecraft.
No final APK has been built yet.

## Compatibility limits (by design, not bugs)
| Limit | Detail |
|---|---|
| One integration cannot cover both worlds | Public servers: only Android-side features and global resource packs. Personal/hosted worlds: also the Script API add-on. A behavior pack installed locally is not expected to run on a server you join (not yet confirmed on device). |
| Mode detection | Android does not tell V CLIENT which world is open. "Auto" therefore shows both facts. The Public / Personal selector only changes what V CLIENT tells you; it never switches anything on by itself. |
| No add-on to overlay link | The add-on cannot send data to the overlay (no network or file access in client worlds). Its stats are drawn inside Minecraft. |
| Minecraft FPS | No legitimate route. Not shown, not estimated. |
| Display refresh (Hz) | Screen refresh rate. Not Minecraft's FPS. |
| Screen taps / sec | Every tap on the screen. Not attack CPS. Real attack CPS comes only from the add-on. |
| Public-server HUD stats | Coordinates, direction, armor, keystrokes, attack CPS and combo are not available on public servers. |

## Unfinished modules
- **Zoom** (personal worlds): a Script API camera field-of-view method exists in recent versions, but the trigger design (touch has no zoom key) and a device test are not done. Public servers: not possible.
- **In-game crosshair via global resource pack** (works on public servers per community packs): not implemented. The texture path inside the current Minecraft is unconfirmed, so no pack is generated yet. The overlay crosshair stays; it is drawn at the screen centre and may not match the game's aiming point.
- **Positioned in-game HUD**: add-on stats currently appear as one line on the action bar (shared with other action-bar text). A resource-pack HUD with real positions and themes is not done.
- **Armor icons**: text durability only.
- **Per-server live ping** in the Servers tab: only the single HUD ping widget exists.

## Untested (needs a phone with Minecraft)
1. The add-on manifest loading: the `@minecraft/server` version must match the installed Minecraft version. V CLIENT cannot work it out; you enter it. Wrong value = pack fails to load.
2. `playerSwingStart` with the Attack filter: event field names (`player`) assumed from the API pattern.
3. `getMovementVector` sign convention for A/D (taken from the API docs example; yaw convention taken from Minecraft's yaw rules).
4. Action-bar refresh rate and flicker at 1-3 ticks.
5. `minecraft://` add/join links: a Mojang bug report shows the add-server link opening the Friends tab on some older versions. Treated as best effort.
6. Pack import/send flow for `.mcaddon` (the existing pack sender is reused).
7. Whether the add-on disables achievements on your version (older docs say experiments do; stable modules may not).
8. All new Kotlin code: written without a compiler in the authoring environment. First CI run may show compile errors to fix.

## Known bugs / risks
- Gradle wrapper jar is not in the repo; CI uses Gradle 8.7 directly.
- `min_engine_version` is set to 1.21.0 in the generated manifest; may need raising for newer module versions.
- Rebuilding the add-on changes its file time, so it counts as "not sent" again (by design).
- Deleting a saved config does not delete the add-on settings baked into an already built pack: rebuild and resend.

## Added at the integration investigation stage
- Native in-game integration (real FPS, real attack events on public servers, in-game UI, zoom): NOT started. See ARCHITECTURE.md section 6 for the exact blockers.
- Replay Studio: NOT started.
- ClickGUI search box and keybinds: NOT built.
- Performance numbers (FPS before/after, CPU, memory, battery): none exist. No "no lag" claim is made.

## Native spike stage
- Launcher (running Minecraft inside V CLIENT): NOT built. Exact blocker and options in NATIVE_SPIKE.md (blocker 1).
- Graphics-hook FPS: NOT built. The C++ engine exists and is host-tested but has no source of frames.
- JNI bridge: only syntax-checked against a stub here; real compile is the CI job build-native (allowed to fail).
- Readiness probe: untested on a phone.
- LeviLauncher licence review: incomplete because its source was not readable from here (LICENSING_REVIEW.md).
- Keybinds: not built. Touch has no keys; hardware keyboard or gamepad keys could only be read by the native tier.
- Native-only modules (FPS, frame time, zoom, hit counter, target, combat stats, FreeLook): listed and locked.

## LeviLauncher review stage
- **Blocker (native launcher):** the only compliant candidate (approach 2) may fail because the game's licence, Play Integrity and Xbox identity checks are tied to package `com.mojang.minecraftpe`. If so, no compliant in-process launcher exists on stock Android. Exact analysis in NATIVE_SPIKE.md section 2. Decided by the probe and a device test, not by guessing.
- LeviLauncher's launcher approach cannot be reused: unlicensed reproduced game Java (`minecraft/`, 35,630 lines, no licence or origin statement), unlicensed Microsoft binaries in `jniLibs`, absent hook-engine submodule, LGPL-3.0 controls module, and a Microsoft login using the game's own client identity (LICENSING_REVIEW.md).
- The real NDK/CMake/JNI build has not been run (no SDK/NDK in the authoring environment). Only the host C++ tests and the JNI symbol-name check ran.
- Kotlin tests (including registry v2 and native capability tests) have never been run.
- Probe v2 is untested on a phone. If class loading of another package triggers a crash on some device, the report will be missing; the probe never initialises game classes, which should prevent that, but this is unverified.

## HUD / menu / icon update
- All new Kotlin (HudModel, HudJson, HudProfiles, HudStore, HudDefaults, HudOverlay, PvPMenuController, HudEditorController, FloatingVService changes, VBridge additions, ForegroundWatcher fix) has never been compiled or run. 87 Kotlin unit tests exist (about 60 are new) and have never been run either. Expect possible compile errors on the first CI run.
- Root causes in BUGFIX_REPORT.md are from code reading; none is device-verified.
- Touch CPS probably misses a second finger (Android reports only new gestures). It can never be Minecraft attack CPS.
- FPS, attack CPS, coordinates, direction, keystrokes, armor and combo elements can only show "Needs Native Integration". No live data exists for them in the overlay.
- Back button closes the menu only while the menu window has keyboard focus (lost when you touch the game).
- The editor preview is a schematic, not the real game frame; element sizes in the preview can differ from the real HUD by a few pixels because the browser and Android measure text slightly differently.
- Positions are stored per orientation: a layout made in portrait does not change landscape.
- The kept menu WebView costs memory while closed (released on memory pressure). Not measured.
- The HUD still uses one overlay window per enabled element (up to 16). Not measured for overhead.
- The mock used by ui-tests re-implements the Kotlin store rules; it does not prove the Kotlin code.
- `ICON_SIDE` is still written for compatibility with older versions.

#!/usr/bin/env python3
"""Checks that every `external fun` in NativeBridge.kt has a matching exported JNI symbol in jni_bridge.cpp (and vice versa).

Compiles jni_bridge.cpp to an object file against a minimal jni.h stub and reads its symbols with `nm`.
This catches name/package typos. It does NOT prove the real NDK build works.
"""
import os, re, subprocess, sys, tempfile

root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
kt = open(os.path.join(root, "app/src/main/java/com/vclient/pvp/NativeBridge.kt")).read()
expected = {"Java_com_vclient_pvp_NativeBridge_" + n for n in re.findall(r"external\s+fun\s+(\w+)", kt)}

with tempfile.TemporaryDirectory() as d:
    obj = os.path.join(d, "jni_bridge.o")
    subprocess.check_call([
        os.environ.get("CXX", "g++"), "-std=c++17", "-Wall", "-Wextra", "-Werror", "-c",
        "-I", os.path.join(root, "native-tests/jni_stub"),
        os.path.join(root, "app/src/main/cpp/jni_bridge.cpp"), "-o", obj,
    ])
    out = subprocess.check_output(["nm", "-g", "--defined-only", obj], text=True)
actual = {l.split()[-1] for l in out.splitlines() if " T " in l and "Java_" in l}

ok = True
for name in sorted(expected - actual):
    print("MISSING in C++: " + name); ok = False
for name in sorted(actual - expected):
    print("EXTRA in C++ (no Kotlin external fun): " + name); ok = False
if ok:
    print("jni symbols match: %d exported, %d declared" % (len(actual), len(expected)))
sys.exit(0 if ok else 1)

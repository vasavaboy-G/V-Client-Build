// Host unit tests for the frame statistics engine. Build and run: make -C native-tests
#include <cmath>
#include <cstdio>
#include <cstdlib>

#include "../app/src/main/cpp/frame_stats.h"

static int failures = 0;
#define CHECK(cond)                                                      \
    do {                                                                 \
        if (!(cond)) {                                                   \
            std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);  \
            failures++;                                                  \
        }                                                                \
    } while (0)
static bool near(double a, double b, double tol) { return std::fabs(a - b) <= tol; }

using vclient::FrameStats;
static const int64_t MS = 1000000LL;

int main() {
    {   // steady 60 fps (16.667 ms)
        FrameStats s;
        int64_t t = 0;
        for (int i = 0; i < 120; i++) { s.onPresent(t); t += 16666667LL; }
        const int64_t now = t - 16666667LL;
        CHECK(near(s.fps(now), 60.0, 0.5));
        CHECK(near(s.avgFrameMs(now), 16.667, 0.05));
        CHECK(near(s.onePercentLowMs(now), 16.667, 0.05));
    }
    {   // not enough frames
        FrameStats s;
        CHECK(s.fps(0) == 0.0);
        s.onPresent(5 * MS);
        CHECK(s.fps(5 * MS) == 0.0);
    }
    {   // game stopped presenting: stale newest frame
        FrameStats s;
        for (int i = 0; i < 10; i++) s.onPresent(i * 10 * MS);
        CHECK(s.fps(90 * MS) > 90.0);
        CHECK(s.fps(5000 * MS) == 0.0);
    }
    {   // stutter: 99 fast frames and 1 slow one; the 1% low must show the spike, the average must not hide it
        FrameStats s(1000);
        int64_t t = 0;
        for (int i = 0; i < 99; i++) { s.onPresent(t); t += 8 * MS; }   // 125 fps
        s.onPresent(t); t += 100 * MS;                                  // one 100 ms frame
        s.onPresent(t);
        const int64_t now = t;
        CHECK(s.onePercentLowMs(now, 2000 * MS) >= 99.0);
        CHECK(s.avgFrameMs(now, 2000 * MS) < 20.0);
    }
    {   // ring buffer wrap keeps only the newest samples
        FrameStats s(8);
        int64_t t = 0;
        for (int i = 0; i < 100; i++) { s.onPresent(t); t += 20 * MS; }
        CHECK(s.totalFrames() == 100);
        CHECK(near(s.fps(t - 20 * MS, 1000 * MS), 50.0, 0.5));
    }
    {   // reset
        FrameStats s;
        for (int i = 0; i < 10; i++) s.onPresent(i * MS);
        s.reset();
        CHECK(s.totalFrames() == 0);
        CHECK(s.fps(10 * MS) == 0.0);
    }
    if (failures == 0) std::printf("frame_stats: all tests passed\n");
    return failures == 0 ? 0 : 1;
}

Minimal stand-in for the Android NDK's jni.h, used ONLY to check that jni_bridge.cpp parses and that its exported
symbol names match the Kotlin `external fun` declarations (see ../check_jni_symbols.py).
It is NOT a substitute for the real NDK build. The real build is the CI job "build-native".

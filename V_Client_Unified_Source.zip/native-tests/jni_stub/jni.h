#pragma once
#include <cstdint>
typedef int64_t jlong; typedef double jdouble; typedef void* jclass; typedef void* jstring;
struct JNIEnv { jstring NewStringUTF(const char*) { return nullptr; } };
#define JNIEXPORT
#define JNICALL

# On-device test plan (run against YOUR Minecraft version)

Record the exact Minecraft version (Settings > About) and Android version. Fill the result column.

## 0. Setup
1. Install the debug APK from CI. Start the overlay.
2. Open ClickGUI > World add-on. Note "Minecraft: x.y.z" shown there.
3. Enter the `@minecraft/server` version that matches that Minecraft version (see the Script API docs for your version).
4. Switch on all six World add-on modules and Diagnostic mode. Tap **Build add-on**, then **Send**.
5. In Minecraft: import the pack, create a NEW personal world, under Behavior Packs activate "V CLIENT Stats", create the world.

| # | Test | Expected | Result |
|---|---|---|---|
| 1 | Pack loads | No "missing dependency" error; action bar text appears | |
| 2 | Coordinates | XYZ matches the game's own coordinates display | |
| 3 | Direction | Face north/east/south/west: N/E/S/W matches the in-game compass or F3-style coordinates | |
| 4 | Armor | Equip/damage armor: percentages change; empty slot shows "-" | |
| 5 | Keystrokes | Joystick up/left/right/down show W/A/D/S; jump and sneak buttons show | |
| 6 | Attack CPS | Tap attack 10 times in 1 s: reads about 10, including misses | |
| 7 | Attack CPS vs taps | Tap the empty screen (not attack): CPS does not change | |
| 8 | Combo | Hit a mob 3 times, then get hurt: counts 3, then resets to 0 | |
| 9 | DIAG line | swings/hits/mv/yaw values look sane | |
| 10 | Rebuild | Change a switch, rebuild, send, re-import: new setting applies (pack replaced, not duplicated) | |
| 11 | Public server | Join a public server with the pack enabled locally: record whether ANY stats appear (expected: none) | |
| 12 | Overlay on server | HUD widgets, crosshair, HUD editor still work on the server | |
| 13 | Server list | Save a server, tap Add and Join: record which screen Minecraft opens | |
| 14 | Achievements | Record whether the world shows achievements disabled | |

## Regression (existing features)
Dashboard, floating icon, HUD editor drag, crosshair, themes + custom colours, configs save/load, pack library send, Do Not Disturb, backup/restore.

## Reporting back
Send: Minecraft version, Android version, the table above, and the DIAG line text if anything is wrong.

## Native tier: phone testing (what to do now)
Nothing that launches Minecraft through V CLIENT exists yet, so there is nothing native to pass or fail. What you can do now is
collect facts and baselines. **Do not report a result you did not observe.** Write "not tested" if you skip a step.

### A. Readiness probe (read-only; Minecraft does not need to be running and the probe never starts it)
1. Install the debug APK from the GitHub Actions run (artifact `V-Client-debug-apk`), start the overlay.
2. Open the V CLIENT menu > ClickGUI > scroll to "Native integration (in-game)".
3. Tap **Run readiness probe**. Wait until JSON text appears. Tap **Share report** and send it to the developer (or copy the file `files/native_probe.json`).
4. Check the status line says "not_built" and that no native module can be switched on.

What each part of the report tells us:
| Report field | Item you were asked about |
|---|---|
| `phone.android_release`, `phone.android_sdk` | Android version |
| `phone.abis`, `phone.process_is_64bit` | CPU architecture (need `arm64-v8a`) |
| `minecraft.package`, `minecraft.version_name`, `installed_by_google_play` | Minecraft package and version |
| `minecraft.libminecraftpe_exists`, `libminecraftpe_readable`, `lib_dir_listing` | Native library availability |
| `launch_feasibility.*` | Launcher compatibility (can V CLIENT see and load the game's classes; no launch happens) |
| `vclient_native.lib_loaded` | Whether V CLIENT's own native library is in this APK (false for the normal build) |

### B. Vanilla Minecraft baselines (use Minecraft normally, WITHOUT V CLIENT's overlay running)
These are the "before" results every later native test will be compared with. Record Yes / No / Not tested and the Minecraft version.
| # | Baseline | Result |
|---|---|---|
| B1 | Minecraft starts and reaches the title screen | |
| B2 | Xbox/Microsoft sign-in works (signed in with your gamertag) | |
| B3 | Join a public multiplayer server and play 5 minutes | |
| B4 | Open a personal world and play 5 minutes | |
| B5 | Average FPS you see in a normal world (from any independent counter you trust, name it) | |
| B6 | Phone model, RAM, battery level at start | |

### C. V CLIENT tier-0 checks (existing features, overlay running)
| # | Test | Expected | Result |
|---|---|---|---|
| C1 | Native card | Says "not_built" and no in-game launcher | |
| C2 | Search "fps" | One locked result, "Needs native tier", no switch | |
| C3 | FPS, frame time, zoom, hit counter, target, combat stats, FreeLook | None can be switched on | |
| C4 | Overlay HUD, crosshair, HUD editor, server list, themes | Work as before | |
| C5 | Add-on build and send, personal world (steps 0 to 10 of the earlier plan) | As before | |
| C6 | Minecraft plays normally with the overlay running (join a server, 5 minutes) | No new problems; note any lag you see | |

### D. Not testable yet
Launching Minecraft through V CLIENT, Xbox sign-in inside V CLIENT, multiplayer inside V CLIENT, native FPS and its overhead.
Milestones M0 to M7 are in NATIVE_SPIKE.md. They only become testable if the probe shows approach 2 is possible, and after it is built.

### Reporting back
Send: the shared probe report, the filled table B and C, Minecraft version, phone model, Android version, and any crash text.


## HUD, menu and icon fixes: phone tests (nothing below has been run; fill in only what you observe)
Build the APK from CI first. Record phone model, Android version, Minecraft version, portrait or landscape.

| # | Requirement | Test | Expected | Result |
|---|---|---|---|---|
| 1a | FPS HUD | Menu > HUD Editor > chip "FPS" > "Shown on HUD" | FPS element appears on the game screen with `FPS: Needs Native Integration`, no number | |
| 1b | FPS HUD | Drag it to a corner, resize it, change colours | Moves and restyles live; stays on screen | |
| 1c | FPS HUD | Compare with "Display refresh" element | Shows `Display ... Hz`, clearly separate from FPS | |
| 2a | CPS HUD | Show "Touch CPS" and "Attack CPS" | Touch CPS shows a number; Attack CPS shows `Needs Native Integration` | |
| 2b | CPS HUD | Tap the screen with one finger repeatedly while NOT holding anything | Touch CPS rises | |
| 2c | CPS HUD | Hold the joystick with one finger and tap attack with another | Record whether Touch CPS counts the second finger (expected: probably not) | |
| 2d | CPS HUD | ClickGUI > Touch CPS card | Shows "Touches received so far" or the "none received" explanation | |
| 3a | HUD visibility | Turn on 5 different elements, then toggle each off and on | Each appears and disappears immediately | |
| 3b | HUD visibility | Open the keyboard (menu text field) and pull down the notification shade, then return | HUD and menu stay; HUD does not vanish for more than 3 seconds | |
| 3c | HUD placement | Place an element at the top-left corner in landscape, compare with the game's own corner | It sits in the real corner, not shifted (check on a phone with a notch) | |
| 3d | HUD placement | Rotate the phone | Elements stay on screen at the positions saved for that orientation | |
| 4a | Menu | Tap the icon 20 times quickly (open/close) | Opens and closes every time, no stuck state | |
| 4b | Menu | Time from tap to visible menu | Record seconds (first open and later opens) | |
| 4c | Menu | Close with the X button, with Back, and by tapping the icon | All three close it | |
| 4d | Menu | Type in a text field and change several settings | Menu does not close by itself | |
| 4e | Menu closed | Close the menu and play | Minecraft controls work everywhere on screen | |
| 5a | Icon | Drag the icon to the middle of the screen, then to each corner | It stays where dropped | |
| 5b | Icon | Restart the overlay / reboot | Icon returns to the same place | |
| 5c | Menu direction | Icon on the left half: open menu. Then icon on the right half | Opens right, then left; never off screen, never over the icon | |
| 5d | Menu direction | Same in landscape and portrait | Same behaviour | |
| 6 | HUD controls | For one element change: X/Y, width/height, scale, text size, text and background colour, both opacities, border colour and thickness, radius, show/hide, reset | Each works independently of other elements | |
| 7 | Editor | Drag in the preview, use handles, type X/Y, reset all layout, rotate while open | Preview and real HUD agree; nothing gets stuck off screen | |
| 8 | Profiles | Create, rename, duplicate, switch, delete, export, import a profile; restart the phone | All work; layouts survive restart | |
| 9 | Regression | Overlay crosshair, themes, configs, pack library, add-on build/send, server list | As before | |

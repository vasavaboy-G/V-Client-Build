# Phase 2: Minecraft integration architecture investigation

Question: can V CLIENT become a genuinely Minecraft-integrated client on Android (one APK, public servers + personal worlds,
no root, no Shizuku), and what exactly blocks it?

## 1. Short answer
Yes in principle, but not through anything the current overlay or a behavior pack can reach. It needs code running **inside the
Minecraft process**. Public precedent exists (see section 2). I cannot build or test that part in the current authoring
environment. The blockers are practical, not conceptual, and are listed in section 6.

## 2. What the research found (with confidence)
| Finding | Source | Confidence |
|---|---|---|
| Flarial is not a texture/behavior pack. On Windows it injects a DLL into Minecraft. On Android it ships as its own app that launches your Minecraft. | flarial.xyz pages, 9minecraft listing | Medium: marketing/download-site text; Android build described as beta |
| The Flarial XAPK you supplied: its own package, Minecraft loader strings, a Shizuku permission, packed/encrypted payloads. Its modules run in the game process. Its code was NOT analysed or reused. | Own inspection (manifest + strings only) | High for what was seen |
| An open-source (Apache-2.0) Android launcher, LeviLauncher, imports the user's official Minecraft APK, runs it without system install, loads external native `.so` modules, manages multiple Xbox accounts, and exposes a Preloader API (hooks, input callbacks, in-game mod menu). Requires a licensed Google Play copy. | github.com/LiteLDev/LeviLaunchroid README + docs | High that it exists and what it advertises; not independently run |
| Its docs list minimum supported Minecraft versions (currently rejects older than 1.21.80) and ARM64 + Android 9+. | LeviLaunchroid docs | Medium |
| A third-party mod runtime for it advertises signature-based engine hooking for several 1.26.x builds. | github.com/spygamingog/LeviLamroid releases | Medium |
| Native libraries of the Android game have historically exposed C++ symbol names usable for hooks (seen in mcpelauncher logs, 1.19.70). | minecraft-linux/mcpelauncher-manifest issue logs | Medium; may not hold for current versions |
| Public servers set their own rules. Example: The Hive bans any client modification that gives a benefit the vanilla client lacks, and lists only a tiny allow-list. | support.playhive.com | High for that server |
| Behavior packs (Script API) run in the world's simulation. They do not run on servers you join. | Earlier research + API docs | Medium: needs the device test (TEST_PLAN #11) |

## 3. How in-process integration works (three layers)
1. **Launcher layer (Kotlin).** V CLIENT starts Minecraft itself, from the user's own licensed, installed copy, instead of the user
   tapping the Minecraft icon. No root. Xbox sign-in and multiplayer are Minecraft's own code and are expected to keep working,
   but that is **unproven for V CLIENT** until tested (LeviLauncher advertises it for itself).
2. **Native module (C++ via NDK).** A `.so` loaded into the same process. It can hook functions in the game's native library.
3. **Bridge (JNI).** Native events flow to Kotlin; the ClickGUI/HUD can be drawn by Android views inside the game's own window.
   That removes the floating overlay window and its overhead.

## 4. What each kind of hook can give
| Data | Hook family | Version dependence | Notes |
|---|---|---|---|
| **Real FPS and frame time** | Graphics API (`eglSwapBuffers` / `vkQueuePresentKHR`) | Low: independent of game internals (design inference, unverified) | Needs no game offsets. Measures what the game really presents. |
| Raw touch events | Android Activity / input callbacks | None | Touches only. Does not say "this was an attack". Must NOT be used as attack CPS. |
| **Attack CPS, hit, combo, target id** | Game-function hooks (attack/swing/hit) | High: per version signatures | Counts real game events. Observation only: hooks call the original and never change the result. |
| Coordinates, rotation, armor | Game-object reads | High | Same signature work. |
| Zoom, free look | FOV / camera hooks | High | Modifies rendering only. Free look touches camera/input, so it is high risk for servers. |
| Ping | Network layer | High | Only if a real measured value exists. Otherwise keep the existing separate ping probe, labelled. |

## 5. Options
| | Option | Pros | Cons |
|---|---|---|---|
| A | Stay: overlay + behavior pack (today) | Safe, supported, works now | No FPS, no real attack input on servers, no zoom, no in-game UI |
| B | **Layered one-APK: A plus in-process native tier (recommended)** | Keeps everything that works. Gains real FPS, real events, in-game UI. Falls back to A where native is unsupported for a version. | Large effort. Per-version maintenance. Policy risk on servers. |
| C | Ship V CLIENT as a module for an existing launcher | Least work | Two apps. Violates "one APK". Dependent on another project. |
| D | Embed/fork an Apache-2.0 launcher core | Faster than writing a launcher | **Rejected after reading the source (LICENSING_REVIEW.md):** the launcher depends on unlicensed reproduced game Java, Microsoft binaries, an absent hook-engine submodule, and a Microsoft sign-in that impersonates the game's client identity |

Recommendation: keep **B** as the goal, but see the update below: the launcher method that exists in the open is not usable by V CLIENT. Capability detection per Minecraft version decides
what is shown as working. If the version is unsupported, V CLIENT falls back to Tier 0 (today's overlay + add-on) and says so.

## 6. Exact blockers right now
1. No Minecraft binary, no Android device, no NDK, no network in the authoring environment: native code cannot be compiled, run or measured here.
2. Game-function hooks need signatures found by analysing the user's own installed Minecraft on a real device. I cannot do that here.
3. Flarial's payload is packed and proprietary and must not be used, so all hook knowledge has to be independent.
4. Version fragility: every Minecraft update can break signatures. Needs a per-version compatibility table and a safe "disable on unknown version" rule.
5. Unverified: Xbox sign-in, Realms and multiplayer behaviour when launched through V CLIENT.
6. Policy and account risk: modified clients are prohibited or restricted on many public servers; Mojang/Microsoft enforcement is unknown to me.

## 7. Safety rules for the native tier (non-negotiable)
- Observation only. Hooks call the original function; they never alter attacks, hit registration, reach, knockback or input timing.
- No anti-cheat bypass, no Xbox spoofing, no pirated or modified game files. Requires the user's own installed licensed Minecraft.
- Off by default on first launch with a plain-language notice that servers may forbid modified clients; per-feature enable.
- Unknown Minecraft version = native tier stays off, overlay tier continues.
- Never show a native module as working unless a real event/frame source feeds it in the current version.

## 8. Ordered implementation plan
Each step ends with tests that can run here (J = JVM/Node) and checks that need a phone (D). Nothing is called done until D passes.

| Step | Work | Checks |
|---|---|---|
| 1 | **Registry v2**: add `NATIVE` requirement, version-compat table, ClickGUI search, keybind labels, capability detection API | J |
| 2 | **Replay Studio recording**: MediaProjection foreground service, MediaStore MP4 (Movies/V CLIENT), audio capture where allowed, recording indicator, library (rename/delete/share), low-storage and interruption handling | J for helpers; D for recording |
| 3 | **Native spike**: NDK build in Gradle + CI, JNI bridge, launcher activity that starts Minecraft, in-process Android HUD, graphics-hook FPS only | D: launches, signs in, joins a server, FPS matches an independent counter, overhead measured |
| 4 | **Game events**: attack swing, hit, target id, per-version signatures, observation only | D with TEST_PLAN extensions; combat unaffected |
| 5 | **Visual modules**: zoom (FOV), crosshair in-game, HUD in-game, free look only if proven safe | D |
| 6 | **Replay editing and export**: Media3-based trim, speed, text/music, 1080p/1440p presets, 30/60 fps where encoder supports; label scaled output honestly | J + D |
| 7 | **Performance harness**: frame-time log, memory, CPU, battery protocol; before/after table with real numbers | D only |
| 8 | **Hardening**: lifecycle, permissions, version-change handling, release signing | D |

## 9. Replay Studio: what is genuine and what is not
- Screen recording (MediaProjection) is genuine and needs no server or add-on. Editing it (zoom, pan, keyframes, easing, speed) is **2D video processing**, and the UI will say so.
- A real 3D replay (free camera in the recorded world) needs recorded game state. Bedrock has no replay data format available to V CLIENT. Closest honest options: (a) in personal worlds, a Script API camera path can fly a real 3D camera while you screen-record; (b) native recording of entity state is a research item for the native tier and is not promised.
- Export at 1080p or 1440p from a lower-resolution capture is scaling. It adds no detail and will be labelled "scaled".
- Android 14+ needs a mediaProjection foreground service type and a user consent prompt per session; the app must handle the user stopping the share from the system UI. Audio capture of other apps' playback requires API 29+ and works only if the app allows capture. All of this is Android behaviour I know but have not tested on a device.

## 10. Performance protocol (to be run on devices, results go in a table, no estimates)
Same device, same world/server, 3 runs each: vanilla vs overlay tier vs native tier vs while recording. Record average FPS, 1% low frame time, RAM (dumpsys meminfo), CPU, battery % per 10 minutes, input latency where a tool allows. "No lag" is never claimed without these numbers.

## Sources
flarial.xyz/mcpe-client, flarial.xyz/bedrock-launcher; github.com/LiteLDev/LeviLaunchroid and its docs; github.com/spygamingog/LeviLamroid/releases;
github.com/minecraft-linux/mcpelauncher-manifest (issues); support.playhive.com/allowed-and-denied-mods; Script API docs (jaylydev.github.io/scriptapi-docs).


## Update after the LeviLauncher source review
- The only open-source Android launcher examined runs the game inside its own process using a reproduction of the game's Java, copied game libraries, a faked package identity and a Microsoft login made with the game's own client id. None of that is licensable or acceptable for V CLIENT (LICENSING_REVIEW.md).
- The only licence-clean variant is "approach 2" in NATIVE_SPIKE.md: load the game's Java from the user's installed APK at runtime. Whether the game then starts and signs in under V CLIENT's package identity is unknown, and is exactly what the readiness probe starts to answer.
- If it fails, the honest conclusion is that stock Android offers no compliant way to run V CLIENT code inside the real game. Tier 0 (overlay + Behavior Pack) would remain the product, with approximate, clearly labelled alternatives (for example screen-capture-based presented-frame rate), never "Minecraft FPS".
- Real FPS, real attack events on public servers, zoom and in-game UI stay locked until a version is verified on your phone.

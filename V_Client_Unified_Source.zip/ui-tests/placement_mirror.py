# Python port of MenuPlacement.compute / IconPlacement / HudGeometry.posPx, used ONLY to double-check the expected
# numbers written into the Kotlin unit tests (the Kotlin code itself cannot be run in this environment).
import math
def rnd(x): return int(math.floor(x + 0.5))      # Kotlin roundToInt (half up)
def coerce(v, lo, hi): return min(max(v, lo), hi)

def menu(iconX, iconSize, screenW, desiredW, minW, margin, gap):
    usable = max(0, screenW - 2*margin)
    want = min(desiredW, usable)
    prefer_right = (iconX + iconSize//2) < screenW//2
    right_room = screenW - margin - (iconX + iconSize + gap)
    left_room = (iconX - gap) - margin
    room = lambda r: right_room if r else left_room
    if room(prefer_right) >= min(minW, usable): side = prefer_right
    elif room(not prefer_right) >= min(minW, usable): side = not prefer_right
    else: side = None
    if side is None:
        w = want
        x = (screenW - w)//2
        return (coerce(x, margin, max(margin, screenW - margin - w)), w, prefer_right)
    width = max(min(want, room(side)), min(minW, usable))
    x = iconX + iconSize + gap if side else iconX - gap - width
    return (coerce(x, margin, max(margin, screenW - margin - width)), width, side)

def icon_px(frac, screen, size):
    free = max(0, screen - size); f = coerce(frac, 0, 1)
    return coerce(rnd(f*free), 0, free)
def icon_frac(px, screen, size):
    free = screen - size
    return 0.0 if free <= 0 else coerce(px/free, 0, 1)
def snap_x(cur, screenW, size):
    return max(0, screenW - size) if cur + size//2 > screenW//2 else 0
def pos_px(norm, screen, size):
    return coerce(rnd(coerce(norm,0,1)*screen), 0, max(0, screen - size))

if __name__ == "__main__":
    # portrait phone 1080 wide, dp = 3 px: icon 52dp=156px, desired 92% -> min(max()) ; use px directly
    cases = {
     "icon at left edge, portrait": menu(0,156,1080,990,720,12,18),
     "icon at right edge, portrait": menu(1080-156,156,1080,990,720,12,18),
     "icon mid-left landscape": menu(100,156,2400,1008,720,12,18),
     "icon at right edge landscape": menu(2400-156,156,2400,1008,720,12,18),
     "icon centre-left narrow": menu(400,156,1080,990,720,12,18),
     "tiny screen both sides too narrow": menu(300,100,700,640,500,10,10),
    }
    for k,v in cases.items(): print(k, v)
    print("icon_px", icon_px(0,1080,156), icon_px(1,1080,156), icon_px(0.5,1080,156), icon_px(2,1080,156), icon_px(float('nan') if False else 0.0,1080,156))
    print("icon_frac", icon_frac(0,1080,156), icon_frac(924,1080,156), icon_frac(462,1080,156), icon_frac(5000,1080,156))
    print("snap", snap_x(100,1080,156), snap_x(600,1080,156), snap_x(462,1080,156))
    print("pos_px", pos_px(0,1080,200), pos_px(1,1080,200), pos_px(0.5,1080,200), pos_px(0.9,1080,200), pos_px(0.02,1080,200), pos_px(0.5,100,200))

import json, pathlib, os, sys
from playwright.sync_api import sync_playwright

def mod(id,name,cat,req,key,desc="d",reason=""):
    return {"id":id,"name":name,"category":cat,"description":desc,"requires":req,"key":key,"reason":reason,"hud":id in ("battery","cps","coords","attack_cps","fps","zoom") and id!="zoom"}
BASE=[mod("battery","Battery","HUD","ANDROID_OVERLAY","w_battery_on"),
 mod("cps","Touch CPS","PvP","ANDROID_OVERLAY","w_cps_on","Counts touch gestures, not Minecraft attacks. NOT attack CPS."),
 mod("coords","Coordinates","World add-on","WORLD_ADDON","ao_coords_on"),
 mod("attack_cps","Attack CPS","World add-on","WORLD_ADDON","ao_attack_cps_on"),
 mod("fps","Minecraft FPS","Native","NATIVE","nt_fps_on",reason="Needs the native tier."),
 mod("zoom","Zoom","Native","NATIVE","nt_zoom_on",reason="Needs the native tier.")]
settings={"theme":"neon","themes":[{"id":"neon","name":"Neon","primary":"#6366F1","accent":"#818CF8"}],"world_mode":"auto",
 "w_battery_on":True,"w_cps_on":False,"ao_coords_on":False,"ao_attack_cps_on":False,"addon_api_version":"","addon_diag":False,
 "hud_size":14,"hud_opacity":85,"hud_color":"#FFFFFF","hud_edit":False,"only_in_game":True,"dnd_on":False,"auto_send_packs":True,"auto_start":True,"lite_ui":True,
 "xh_enabled":False,"xh_shape":"cross","xh_size":20,"xh_thick":2,"xh_gap":4,"xh_opacity":100,"xh_dx":0,"xh_dy":0,"xh_outline":True,"xh_dot":False,"xh_color":"#00FF66",
 "ping_host":"","ping_port":19132,"hud_custom_text":"V","theme_custom_on":False,"theme_custom_primary":"#6366F1","theme_custom_accent":"#818CF8","smooth_anim":True}
stub="""
window.__s=%s; window.__mods=%s; window.__servers=[]; window.__opened=[];
function status(m){var mode=window.__s.world_mode;
 if(m.requires==='ANDROID_OVERLAY') return ['available','Works on public servers and personal worlds.'];
 if(m.requires==='WORLD_ADDON'){ if(mode==='public') return ['unavailable','Add-ons do not run on public servers you join.']; return [mode==='auto'?'personal_only':'setup','Build and send the add-on.']; }
 return ['needs_native', m.reason+' Native tier: not built.']; }
window.VBridge={
 getSettings:()=>JSON.stringify(window.__s),
 getModules:()=>JSON.stringify(window.__mods.map(m=>{var st=status(m);return Object.assign({},m,{status:st[0],statusText:st[1]});})),
 setSetting:(k,v)=>{window.__s[k]=(v==='true'?true:v==='false'?false:v);return true;},
 getProfiles:()=>'[]',saveProfile:()=>true,loadProfile:()=>0,deleteProfile:()=>true,
 getAddonInfo:()=>JSON.stringify({built:false,sent:false,build:0,enabled:0,minecraft:'1.26.40'}),
 buildAddon:()=>JSON.stringify(window.__s.addon_api_version?{ok:true,message:'Built.'}:{ok:false,message:'Enter the Script API module version first'}),
 sendAddon:()=>JSON.stringify({ok:false,message:'Build the add-on first.'}),
 getServers:()=>JSON.stringify(window.__servers),
 addServer:(n,h,p)=>{if(!n||!h)return false;window.__servers.push({name:n,host:h,port:p});return true;},
 removeServer:(i)=>{window.__servers.splice(i,1);return true;},
 openServer:(i,a)=>{window.__opened.push(a+':'+i);return true;},
 getNativeStatus:()=>JSON.stringify({code:'not_built',text:'The native tier is not built into this APK yet.',verified:false,tierImplemented:false,libLoaded:false,libError:null}),
 runNativeProbe:()=>JSON.stringify({probe_version:1,minecraft:{version_name:'1.26.40.5'}}),
 shareText:(t)=>{window.__shared=t;return true;},
 getTouchStatus:()=>JSON.stringify({total:0,lastAgeMs:-1}),
 openHudEditor:(id)=>{window.__editor=(window.__editor||[]);window.__editor.push(id);},
 getDevice:()=>'{}',getTapStats:()=>'{"cps":0,"max":0}',getMinecraft:()=>'{"primary":null}',getAccess:()=>'{"usage":true,"dnd":true}',
 closeMenu:()=>{},resetDefaults:()=>{},requestUsageAccess:()=>{},requestDndAccess:()=>{}};
"""%(json.dumps(settings),json.dumps(BASE))
errs=[];res={}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":400,"height":820})
    pg.on("pageerror",lambda e:errs.append(str(e))); pg.add_init_script(stub)
    pg.goto((pathlib.Path(__file__).resolve().parent.parent/"app"/"src"/"main"/"assets"/"pvp_menu.html").as_uri()); pg.wait_for_timeout(300)
    res["auto_pills"]=pg.locator("#mods .pill").count()                      # battery,cps + 2 addon = 4
    res["auto_badges"]=[t for t in pg.locator("#mods .badge").all_inner_texts()]
    pg.click("#modeSeg button[data-mode=public]"); pg.wait_for_timeout(100)
    res["public_pills"]=pg.locator("#mods .pill").count()                    # addon modules lock -> 2
    res["public_badges"]=pg.locator("#mods .badge").all_inner_texts()
    res["mode_saved"]=pg.evaluate("window.__s.world_mode")
    pg.click("#cats button:has-text('Unavailable')"); res["unavailable_tab"]=pg.locator("#mods .mod").count()
    pg.click("#cats button:has-text('All')")
    pg.click("#modeSeg button[data-mode=personal]")
    pg.click("#addonBuild"); res["build_no_version"]=pg.inner_text("#addonMsg")
    pg.fill("[data-key=addon_api_version]","2.9.0"); pg.dispatch_event("[data-key=addon_api_version]","change")
    pg.click("#addonBuild"); res["build_with_version"]=pg.inner_text("#addonMsg")
    res["api_saved"]=pg.evaluate("window.__s.addon_api_version")
    res["cps_label_has_attack_word"]="attack" in pg.locator("#mods .mod:has-text('Touch CPS') .nm b").inner_text().lower()
    pg.screenshot(path=os.environ.get("SHOTS","/tmp")+"/clickgui.png",full_page=False)
    pg.fill("#modSearch","fps"); res["search_fps_rows"]=pg.locator("#mods .mod").count()
    res["search_fps_locked"]=pg.locator("#mods .mod.locked").count()
    res["search_fps_pills"]=pg.locator("#mods .pill").count()
    res["fps_badge"]=pg.locator("#mods .badge").all_inner_texts()
    # --- HUD rows ---
    pg.fill("#modSearch","fps"); pg.click("#mods .mod:has-text('Minecraft FPS') .top")
    res["fps_has_show_on_hud_pill"]=pg.locator("#mods .mod:has-text('Minecraft FPS') [data-key='w_fps_on']").count()
    pg.click("#mods .mod:has-text('Minecraft FPS') button:has-text('Edit position')"); res["edit_fps_calls"]=pg.evaluate("window.__editor")
    pg.fill("#modSearch","touch"); res["touch_rows"]=pg.locator("#mods .mod").count()
    pg.click("#mods .mod:has-text('Touch CPS') .top"); res["touch_note"]=pg.inner_text("#mods .mod:has-text('Touch CPS') .mbody")[:160]
    pg.fill("#modSearch","")
    pg.click("#hudEditorBtn"); res["editor_btn_calls"]=pg.evaluate("window.__editor")
    cb=pg.locator("#close").bounding_box(); res["close_button_size"]=[round(cb["width"]),round(cb["height"])]
    pg.click("#cats button:has-text('Native')"); res["native_tab_rows"]=pg.locator("#mods .mod").count()
    pg.click("#cats button:has-text('All')")
    res["native_info"]=pg.inner_text("#nativeInfo")
    pg.click("#probeRun"); res["probe_out"]=pg.inner_text("#probeOut")
    pg.click("#probeShare"); res["shared"]=pg.evaluate("window.__shared||null") is not None
    res["js_errors"]=errs
    print(json.dumps(res,indent=1)); b.close()

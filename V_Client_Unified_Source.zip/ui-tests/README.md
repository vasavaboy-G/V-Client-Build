# UI tests (headless browser)

These run the real `pvp_menu.html` and `hud_editor.html` in headless Chromium with a MOCK of the Android `VBridge`.
They prove the page logic (dragging, resizing, clamping, profiles UI, locked modules, search). They do NOT prove anything about
Android: the mock re-implements the Kotlin store rules, it is not the Kotlin code.

    pip install playwright && playwright install chromium
    python3 ui-tests/hud_editor_test.py
    python3 ui-tests/clickgui_test.py

`placement_mirror.py` is a Python port of `MenuPlacement` / `IconPlacement` / `HudGeometry.posPx`. It was used to double-check
the expected numbers in the Kotlin unit tests, because the Kotlin tests could not be run in the authoring environment.

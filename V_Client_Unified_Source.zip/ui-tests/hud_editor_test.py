import json, sys, pathlib, os
from playwright.sync_api import sync_playwright

IDS=["battery","clock","ram","storage","refresh","uptime","ping","cps","custom","fps","attack_cps","coords","direction","keystrokes","armor","combo"]
LABELS={"battery":"Battery","clock":"Clock","ram":"Free RAM","storage":"Free storage","refresh":"Display refresh","uptime":"Overlay time","ping":"Server ping","cps":"Touch CPS","custom":"Custom text","fps":"FPS","attack_cps":"Attack CPS","coords":"Coordinates","direction":"Direction","keystrokes":"Keystrokes","armor":"Armor HUD","combo":"Combo counter"}
NEEDS={"fps","attack_cps","coords","direction","keystrokes","armor","combo"}

STUB = """
(function(){
 var IDS=%s, LABELS=%s, NEEDS=%s;
 var screen={w:2400,h:1080,density:2.75,landscape:true};
 function def(i){ var x=(2+Math.floor(i/5)*24)/100, y=(4+(i%%5)*12)/100;
   return {scale:1,textSize:14,width:0,height:0,textColor:"#FFFFFF",bgColor:"#000000",textOpacity:100,bgOpacity:70,borderColor:"#FFFFFF",border:0,radius:8,x:x,y:y,xl:x,yl:y}; }
 function defaults(){ var o={}; IDS.forEach(function(id,i){o[id]=def(i);}); return o; }
 var profiles={Default:defaults()}, active="Default";
 var settings={theme:"neon",themes:[{id:"neon",primary:"#6366F1",accent:"#818CF8"}],xh_enabled:true,xh_dx:0,xh_dy:0,xh_size:20,xh_thick:2,xh_color:"#00FF66",hud_edit:false};
 IDS.forEach(function(id){settings["w_"+id+"_on"]=(id==="battery"||id==="clock"||id==="fps");});
 var calls=[], closed=0, shared=null;
 function clampEl(e,o){ // mirrors HudJson.elementFromJson + HudGeometry.clampStyle/clampPos
   var r=Object.assign({},e,o);
   function c(v,lo,hi){return Math.min(hi,Math.max(lo,v));}
   r.scale=c(+r.scale||1,0.5,3); r.textSize=c(+r.textSize||14,8,40);
   r.width=r.width<=0?0:c(Math.round(r.width),40,800); r.height=r.height<=0?0:c(Math.round(r.height),16,400);
   r.textOpacity=c(Math.round(r.textOpacity),0,100); r.bgOpacity=c(Math.round(r.bgOpacity),0,100);
   r.border=c(Math.round(r.border),0,10); r.radius=c(Math.round(r.radius),0,40);
   ["x","y","xl","yl"].forEach(function(k){r[k]=c(+r[k]||0,0,1);});
   ["textColor","bgColor","borderColor"].forEach(function(k){ if(!/^#[0-9A-Fa-f]{6}$/.test(r[k])) r[k]=e[k]; });
   return r; }
 function safe(n){ return String(n).replace(/[^A-Za-z0-9 _-]/g,"").trim().slice(0,32).trim(); }
 window.__calls=calls; window.__state=function(){return {profiles:profiles,active:active,settings:settings,closed:closed,shared:shared,screen:screen};};
 window.__setScreen=function(w,h){screen.w=w;screen.h=h;screen.landscape=w>h;};
 window.VBridge={
  getScreenInfo:function(){return JSON.stringify(screen);},
  getSettings:function(){return JSON.stringify(settings);},
  setSetting:function(k,v){calls.push(["setSetting",k,v]); settings[k]=(v==="true"?true:v==="false"?false:(isNaN(+v)?v:+v)); return true;},
  getHudLayout:function(){ var info={}; IDS.forEach(function(id){info[id]={label:LABELS[id],status:NEEDS.has?(NEEDS.has(id)?"needs_native":"android"):"android",on:!!settings["w_"+id+"_on"]};});
     return JSON.stringify({active:active,profiles:Object.keys(profiles),elements:profiles[active],info:info}); },
  setHudElement:function(id,json){ calls.push(["setHudElement",id]); if(IDS.indexOf(id)<0) return false; profiles[active][id]=clampEl(profiles[active][id],JSON.parse(json)); return true; },
  resetHudElement:function(id){ calls.push(["resetHudElement",id]); profiles[active][id]=def(IDS.indexOf(id)); return true; },
  resetHudLayout:function(){ calls.push(["resetHudLayout"]); profiles[active]=defaults(); return true; },
  createHudProfile:function(n){n=safe(n); if(!n||profiles[n]||Object.keys(profiles).length>=20) return false; profiles[n]=defaults(); return true;},
  duplicateHudProfile:function(o,n){o=safe(o);n=safe(n); if(!profiles[o]||!n||profiles[n]) return false; profiles[n]=JSON.parse(JSON.stringify(profiles[o])); return true;},
  renameHudProfile:function(o,n){o=safe(o);n=safe(n); if(!n||!profiles[o]||(n!==o&&profiles[n])) return false; if(n===o) return true; var r={}; Object.keys(profiles).forEach(function(k){r[k===o?n:k]=profiles[k];}); profiles=r; if(active===o) active=n; return true;},
  deleteHudProfile:function(n){n=safe(n); if(!profiles[n]||Object.keys(profiles).length<=1) return false; delete profiles[n]; if(active===n) active=Object.keys(profiles)[0]; return true;},
  switchHudProfile:function(n){n=safe(n); if(!profiles[n]) return false; active=n; return true;},
  exportHudProfile:function(n){n=safe(n); if(!profiles[n]) return ""; return JSON.stringify({format:"vclient-hud-profile",version:1,name:n,elements:profiles[n]});},
  importHudProfile:function(t,n){ try{ var r=JSON.parse(t); if(r.format!=="vclient-hud-profile") return ""; var b=safe(n)||safe(r.name)||"Imported", nm=b, k=2; while(profiles[nm]){nm=b+" "+k;k++;} var els={}; IDS.forEach(function(id,i){els[id]=clampEl(def(i),(r.elements||{})[id]||{});}); profiles[nm]=els; return nm; }catch(e){return "";} },
  closeHudEditor:function(){closed++;}, shareText:function(t){shared=t;return true;}
 };
})();
""" % (json.dumps(IDS), json.dumps(LABELS), "new Set(%s)" % json.dumps(sorted(NEEDS)))

URL=(pathlib.Path(__file__).resolve().parent.parent/"app"/"src"/"main"/"assets"/"hud_editor.html").as_uri()
res={}; errs=[]
def state(pg): return pg.evaluate("window.__state()")
def el(pg,id): return state(pg)["profiles"][state(pg)["active"]][id]

with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={"width":900,"height":420})   # landscape phone
    pg.on("pageerror",lambda e:errs.append(str(e))); pg.add_init_script(STUB)
    pg.goto(URL); pg.wait_for_timeout(300)
    res["chips"]=pg.locator("#chips button").count()
    res["stage_elements"]=pg.locator("#stage .el").count()
    # 1. FPS element: needs-native text + badge, and it is selectable/editable
    pg.click('#chips button:has-text("FPS")')
    res["fps_badge"]=pg.inner_text("#panel .badge")
    res["fps_preview_text"]=pg.inner_text('#stage .el[data-id="fps"]')
    res["no_fake_number_in_fps_preview"]=not any(ch.isdigit() for ch in res["fps_preview_text"])
    # 2. drag fps element
    before=dict(el(pg,"fps")); box=pg.locator('#stage .el[data-id="fps"]').bounding_box()
    pg.mouse.move(box["x"]+box["width"]/2, box["y"]+box["height"]/2); pg.mouse.down(); pg.mouse.move(box["x"]+box["width"]/2+120, box["y"]+box["height"]/2+60, steps=6); pg.mouse.up(); pg.wait_for_timeout(200)
    after=el(pg,"fps"); res["drag_moved"]=(after["xl"]>before["xl"] and after["yl"]>before["yl"])
    res["portrait_pos_untouched_by_landscape_drag"]=(after["x"]==before["x"] and after["y"]==before["y"])
    # 3. drag far outside the stage: must clamp inside
    box=pg.locator('#stage .el[data-id="fps"]').bounding_box()
    pg.mouse.move(box["x"]+box["width"]/2, box["y"]+box["height"]/2); pg.mouse.down(); pg.mouse.move(2000,2000,steps=6); pg.mouse.up(); pg.wait_for_timeout(200)
    n=pg.locator('#stage .el[data-id="fps"]').bounding_box(); st=pg.locator("#stage").bounding_box()
    res["clamped_inside_stage"]=(n["x"]>=st["x"]-1 and n["y"]>=st["y"]-1 and n["x"]+n["width"]<=st["x"]+st["width"]+1 and n["y"]+n["height"]<=st["y"]+st["height"]+1)
    e=el(pg,"fps"); res["stored_x_y_in_range"]=(0<=e["xl"]<=1 and 0<=e["yl"]<=1)
    # 4. resize with SE handle
    h=pg.locator('#stage .h[data-h="se"]').bounding_box()
    pg.mouse.move(h["x"]+h["width"]/2,h["y"]+h["height"]/2); pg.mouse.down(); pg.mouse.move(h["x"]+h["width"]/2-40,h["y"]+h["height"]/2-20,steps=4); pg.mouse.up(); pg.wait_for_timeout(200)
    e=el(pg,"fps"); res["resize_sets_fixed_size"]=(e["width"]>=40 and e["height"]>=16)
    # 5. numeric X/Y with out-of-range value
    pg.fill("#eX","150"); pg.dispatch_event("#eX","change"); pg.wait_for_timeout(100)
    res["x_150_percent_clamped_to_1"]=(el(pg,"fps")["xl"]<=1.0)
    pg.fill("#eY","12.5"); pg.dispatch_event("#eY","change"); pg.wait_for_timeout(100)
    res["y_12_5"]=abs(el(pg,"fps")["yl"]-0.125)<0.002
    # 6. look controls
    pg.fill("#eTcT","#FFAA00"); pg.dispatch_event("#eTcT","change")
    pg.fill("#eBcT","#112233"); pg.dispatch_event("#eBcT","change")
    pg.fill("#eBdcT","#00FF00"); pg.dispatch_event("#eBdcT","change")
    pg.fill("#eTcT","red"); pg.dispatch_event("#eTcT","change")          # invalid must be rejected
    pg.evaluate("var r=document.getElementById('eScale'); r.value=2.5; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change'));")
    pg.evaluate("var r=document.getElementById('eTo'); r.value=40; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change'));")
    pg.evaluate("var r=document.getElementById('eBo'); r.value=0; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change'));")
    pg.evaluate("var r=document.getElementById('eBd'); r.value=4; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change'));")
    pg.evaluate("var r=document.getElementById('eRad'); r.value=30; r.dispatchEvent(new Event('input')); r.dispatchEvent(new Event('change'));")
    pg.wait_for_timeout(200)
    e=el(pg,"fps")
    res["look_saved"]=dict(textColor=e["textColor"],bgColor=e["bgColor"],borderColor=e["borderColor"],scale=e["scale"],textOpacity=e["textOpacity"],bgOpacity=e["bgOpacity"],border=e["border"],radius=e["radius"])
    # 7. show/hide
    pg.click("#eOn"); res["hide_calls"]=[c for c in pg.evaluate("window.__calls") if c[0]=="setSetting" and c[1]=="w_fps_on"][-1]
    pg.click("#eOn"); res["show_calls"]=[c for c in pg.evaluate("window.__calls") if c[0]=="setSetting" and c[1]=="w_fps_on"][-1]
    # 8. reset element
    pg.click("#eReset"); pg.wait_for_timeout(150); res["reset_element_style"]=(el(pg,"fps")["scale"]==1 and el(pg,"fps")["border"]==0)
    # 9. profiles
    def name_dialog(btn,val):
        pg.click(btn); pg.fill("#mName",val); pg.click("#mYes"); pg.wait_for_timeout(150)
    name_dialog("#pNew","PvP 1"); res["after_new_active"]=state(pg)["active"]
    pg.click('#chips button:has-text("Coordinates")'); pg.fill("#eX","40"); pg.dispatch_event("#eX","change")
    name_dialog("#pDup","PvP 1 copy"); res["after_dup"]=[state(pg)["active"],list(state(pg)["profiles"].keys())]
    name_dialog("#pRen","Flat"); res["after_rename"]=[state(pg)["active"],list(state(pg)["profiles"].keys())]
    res["copy_kept_edit"]=abs(el(pg,"coords")["xl"]-0.4)<0.002
    pg.click("#pExp"); exp=pg.input_value("#mTxt"); pg.click("#mYes"); res["export_format"]=json.loads(exp)["format"]
    pg.click("#pImp"); pg.fill("#mTxt",exp); pg.fill("#mName","Imported A"); pg.click("#mYes"); pg.wait_for_timeout(150)
    res["after_import"]=[state(pg)["active"],list(state(pg)["profiles"].keys())]
    pg.click("#pImp"); pg.fill("#mTxt","{not json"); pg.click("#mYes"); pg.wait_for_timeout(100); res["bad_import_toast"]=pg.inner_text("#toast"); pg.click("#mNo")
    # switch profile via select
    pg.select_option("#profSel","Default"); pg.wait_for_timeout(150); res["switched_to"]=state(pg)["active"]
    # delete until one is left
    for _ in range(10):
        if len(state(pg)["profiles"])<=1: break
        pg.click("#pDel"); pg.click("#mYes"); pg.wait_for_timeout(100)
    res["profiles_left"]=list(state(pg)["profiles"].keys())
    pg.click("#pDel"); res["delete_last_toast"]=pg.inner_text("#toast")
    # 10. reset all layout
    pg.click('#chips button:has-text("Clock")'); pg.fill("#eX","77"); pg.dispatch_event("#eX","change")
    pg.click("#eAll"); pg.click("#mYes"); pg.wait_for_timeout(150)
    res["reset_all"]=abs(el(pg,"clock")["xl"]-0.02)<0.001 or abs(el(pg,"clock")["xl"]-0.26)<0.001
    pg.screenshot(path=os.environ.get("SHOTS","/tmp")+"/editor_landscape.png")
    # 11. crosshair drag
    pg.click('#chips button:has-text("Crosshair")'); xb=pg.locator("#xhair").bounding_box()
    pg.mouse.move(xb["x"]+xb["width"]/2,xb["y"]+xb["height"]/2); pg.mouse.down(); pg.mouse.move(xb["x"]+xb["width"]/2+300,xb["y"]+xb["height"]/2+200,steps=5); pg.mouse.up(); pg.wait_for_timeout(100)
    s=state(pg)["settings"]; res["crosshair_offsets"]=[s["xh_dx"],s["xh_dy"]]
    # 12. rotate to portrait
    pg.set_viewport_size({"width":420,"height":860}); pg.evaluate("window.__setScreen(1080,2400)"); pg.evaluate("VEditor.onRotate()"); pg.wait_for_timeout(250)
    sb=pg.locator("#stage").bounding_box(); res["portrait_stage_aspect"]=round(sb["width"]/sb["height"],3)
    inside=True
    st=pg.locator("#stage").bounding_box()
    for i in range(pg.locator("#stage .el").count()):
        n=pg.locator("#stage .el").nth(i).bounding_box()
        if n["x"]<st["x"]-2 or n["y"]<st["y"]-2 or n["x"]+n["width"]>st["x"]+st["width"]+2 or n["y"]+n["height"]>st["y"]+st["height"]+2: inside=False
    res["portrait_all_inside_visual_2px"]=inside
    rects=pg.evaluate("(function(){var o=[];document.querySelectorAll('#stage .el').forEach(function(n){o.push([n.dataset.id,n._rect]);});return o;})()")
    scr=state(pg)["screen"]
    res["portrait_all_rects_inside_exact"]=all(r["x"]>=0 and r["y"]>=0 and r["x"]+r["w"]<=scr["w"] and r["y"]+r["h"]<=scr["h"] for _,r in rects)
    pg.click('#chips button:has-text("Clock")'); pg.screenshot(path=os.environ.get("SHOTS","/tmp")+"/editor_portrait.png")
    # 13. close
    pg.click("#closeBtn"); res["close_called"]=state(pg)["closed"]
    res["js_errors"]=errs
    print(json.dumps(res,indent=1)); b.close()
    failed=[k for k,v in res.items() if v is False]
    if failed or res["js_errors"]:
        print("FAILED CHECKS:",failed,res["js_errors"]); sys.exit(1)
    print("hud_editor: all %d recorded checks passed" % len(res))

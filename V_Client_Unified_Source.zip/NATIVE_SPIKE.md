# Native integration spike: findings, decision and exact blockers

Goal: V CLIENT's own native code running inside the Minecraft process, using the user's own licensed Minecraft, without root or
Shizuku, without impersonation, and with Minecraft's own Xbox sign-in and multiplayer.

**Status: not working. No launcher exists. Nothing in this repository has run inside Minecraft. No claim of native integration is made.**
The overlay and the Behavior Pack remain the working fallback and are untouched. An Android Intent that merely opens Minecraft
is not native integration and is not presented as such.

## 1. What the LeviLauncher source showed (details: LICENSING_REVIEW.md section 4)
It runs the game in its own process by (a) bundling a reproduction of the game's Java side (`minecraft/` module), (b) copying the
installed game's native libraries into its private storage, (c) faking the game's `ApplicationInfo`, (d) logging in to Microsoft
with the game's own client identity and writing XAL data, (e) loading a separate hook engine that is not in the uploaded ZIP.

## 2. Approaches compared
| # | Approach | Licence | Security / terms | Technical | Verdict |
|---|---|---|---|---|---|
| 1 | LeviLauncher as built | Needs unlicensed game Java, blobs and an absent submodule | Impersonates the game's Microsoft identity, fakes package identity | Proven by its authors on their targets | **Rejected** |
| 2 | Same host-in-own-process idea, but load the game's Java **at runtime from the user's installed APK** (own `ClassLoader`, supplied through the public `AppComponentFactory` hook on API 28+), no copy of Mojang code in V CLIENT, no spoofing, no custom login | Clean (nothing redistributed) | Acceptable only if the game runs and signs in on its own terms | Unproven. The game's code would run under V CLIENT's package name; its own licence, Play and XAL identity checks may fail. Needs resources/assets from split APKs, JNI registration tied to the game's class, storage paths, Firebase, FileProvider. LeviLauncher needed about 3,600 lines of launch code plus 35,630 lines of game-side Java for this. | **Selected as the only candidate worth testing.** Not implemented. Gated by the probe (section 4). |
| 3 | Patch a copy of the user's APK and install it as a second package | n/a | Re-signing changes identity; higher terms risk | Unknown effect on licence and sign-in | Rejected |
| 4 | Ship V CLIENT as a module for LeviLauncher | Depends on its hook engine (licence unknown) | Inherits its identity issues | Two apps | Rejected (violates one APK) |
| 5 | Root / Shizuku injection | n/a | Excluded by requirements | n/a | Rejected |
| 6 | Stay at Tier 0 (overlay + Behavior Pack) | Clean | Clean | Works, with the known limits | **Current product** |

### Why approach 2 may still fail (exact reasoning, to be confirmed by the probe)
- Android creates activities from the host's manifest with the host's class loader. `AppComponentFactory.instantiateClassLoader` /
  `instantiateActivity` are the supported way to supply a different loader, so the class-loading part has a legitimate route.
- The game's activity and native code were built for package `com.mojang.minecraftpe`. Anything keyed to that package name or its
  signing certificate (Google Play licensing, Play Integrity, Xbox/XAL title identity) sees V CLIENT instead. The LeviLauncher authors
  worked around this by faking identity and logging in with the game's client id. V CLIENT will not do that.
- If the game refuses to start or sign in under V CLIENT's identity, approach 2 is blocked and **no compliant in-process launcher
  exists on stock Android**. That is a possible final outcome, and it will be reported as such.

## 3. What exists in this build
| Piece | State |
|---|---|
| Capability gate (`NativeCapability`) | Always "not built". Cannot reach "verified" until a version is added to `VERIFIED_VERSIONS` after a real-phone test. |
| Registry v2, search, locked native modules | Done. Native modules cannot be switched on. |
| Frame statistics engine (C++, `app/src/main/cpp/frame_stats.*`) | Host tests pass. No frame source. **Not Minecraft FPS.** |
| JNI bridge (`jni_bridge.cpp`) + optional CMake/Gradle build | Symbol names verified against the Kotlin declarations by `native-tests/check_jni_symbols.py` (has a negative test). **The real NDK build was not run here** (see section 5). |
| Readiness probe v2 | Read-only. Never starts Minecraft, never loads its native libraries, never initialises its classes. Untested on a phone. |
| Launcher, graphics hook, game events | Not built. |

## 4. The probe answers the gating questions
Menu > ClickGUI > Native integration > Run readiness probe > Share report. Fields that decide approach 2:
| Field | Question |
|---|---|
| `phone.*` | Android version, ABI, 64-bit process, memory page size |
| `minecraft.version_name`, `meets_assumed_minimum_1_21_80`, `installed_by_google_play`, `signing_cert_sha256` | Which build, and is it the Play build |
| `minecraft.libminecraftpe_exists/readable`, `lib_dir_listing` | Are the game's native libraries visible to V CLIENT |
| `launch_feasibility.package_context`, `main_activity_via_package_context`, `main_activity_via_own_loader` | Can V CLIENT's process see and load the game's activity class from the installed APK |
| `launch_feasibility.main_activity_superclass`, `main_activity_native_method_count` | Does the class resolve with its dependencies |
| `launch_feasibility.class_XalApplicationInfo`, `class_Interop` | Are the Xbox sign-in classes present |
| `launch_feasibility.hidden_api_activity_thread` | Is hidden-API reflection blocked |
A "found" for the own-loader fields means only that class loading is possible. It does not mean the game would start or sign in.

## 5. Build status of the native prototype (honest)
| Check | Result |
|---|---|
| C++ frame statistics tests (host g++, `-Wall -Wextra -Werror`) | Passed |
| JNI symbol names vs Kotlin `external fun` | Passed (5/5); checker fails when a name is broken |
| `jni_bridge.cpp` compile with the real NDK `jni.h`, CMake, `-PenableNative=true`, ARM64 output | **Not run: this environment has no Android SDK, NDK, Gradle, javac or network.** The CI job `build-native` is the first real check and is allowed to fail without affecting the normal APK. |
| Kotlin unit tests | **Not run: no Kotlin compiler here.** They run in the CI job `build`. |

## 6. Milestones (all on your phone; none passed)
| # | Milestone | Pass condition | Result |
|---|---|---|---|
| M0 | Readiness probe | Report shared | not run |
| M1 | Decide approach 2 | Probe shows the game's classes load under V CLIENT's loader | not run |
| M2 | Launch | Game reaches the title screen inside V CLIENT, with no spoofing | not built |
| M3 | Sign-in | Minecraft's own Xbox sign-in completes | not built |
| M4 | Multiplayer | Join a public server for 10 minutes | not built |
| M5 | Stability | 30 minutes in a world and on a server | not built |
| M6 | FPS | V CLIENT FPS matches an independent measurement | not built |
| M7 | Overhead | Vanilla vs V CLIENT numbers, 3 runs each | not built |

## 7. Safety rules (unchanged)
Observation only; never alters attacks, hit registration or input; requires the user's own licensed Minecraft; off by default with a
warning; unknown version keeps the native tier off; no identity spoofing, no impersonation, no redistribution of game code.

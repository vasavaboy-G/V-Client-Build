# HUD system

## Elements
Each HUD element has its own on/off switch (`w_<id>_on`), look and position. Elements: battery, clock, free RAM, free storage, display
refresh, overlay time, server ping, Touch CPS, custom text, **FPS, attack CPS, coordinates, direction, keystrokes, armor, combo**, plus the
**crosshair** (drawn separately, position offset in dp, edited in the same editor).

Elements that need game data (FPS, attack CPS, coordinates, direction, keystrokes, armor, combo) show `<Name>: Needs Native Integration`
and can still be placed and styled. `GameData` returns null for all of them until a verified real source exists. Nothing is estimated.

## What you can change per element
Position (drag, or X/Y in percent), width and height (drag handles, or dp; 0 = automatic), scale (0.5 to 3), text size (8 to 40 sp), text colour,
text opacity, background colour, background opacity, border colour, border thickness (0 to 10 dp), corner radius (0 to 40 dp), show/hide,
and reset for the single element. Every value is clamped on save and on import.

## Coordinates
Positions are fractions (0 to 1) of the screen width and height for the element's top-left corner, stored **separately for portrait and
landscape**. A layout therefore adapts to other resolutions. At draw time the position is converted to pixels and clamped using the
element's measured size, so an element is always fully on screen, and re-clamped when its size or the screen changes.

## Profiles
Stored in `files/hud_profiles.json` (private app storage: survives app updates and restarts; written atomically; a corrupt file is
kept as `.corrupt` and defaults are used). A profile holds look and both positions of every element. Whether an element is shown stays a
global module switch, not part of a profile. Operations: create, rename, duplicate, switch, delete (the last profile cannot be deleted),
reset (active profile), export and import as text (`vclient-hud-profile`, version 1; import always creates a NEW profile and clamps every
value). Maximum 20 profiles, names 32 characters of letters, digits, space, - and _.
Elements added by a later app version are filled in with defaults without touching existing ones.

## Migration
On first run, the old percent positions and the old global look (size, colour, opacity) are carried into the Default profile. The old
"Look of all widgets" controls in the ClickGUI now apply their values to every element of the active profile.

## Editing
- **HUD Editor** (ClickGUI > Open HUD Editor, or "Edit position and look" on a module card): full-screen page with a schematic preview of the
  Minecraft screen (not a live game view), selection borders, 8 resize handles (corner handles only on small elements), precise fields,
  grid, profile menu, and "Reset all layout".
- **Drag on the real screen:** turn on "Edit HUD positions" and drag elements directly; the result is saved in normalized form.
- Changes are sent to the running HUD immediately.

## Performance notes
One small overlay window per enabled element, not touchable during play; text is updated every 500 ms and only when it changed.
The editor exists only while open (no window, no WebView otherwise). The menu WebView is kept in memory while closed for fast opening
and is released on memory pressure. No measurements have been taken yet (TEST_PLAN.md).

# Bug-fix report: HUD, menu and floating icon

Every cause below comes from reading the code. **None has been confirmed on a phone yet** (the authoring environment has no Android
device, no Kotlin compiler and no Minecraft). "Fixed in code" means the code was changed and, where possible, tested in a headless
browser or with unit tests written for it. It does not mean verified on your device. The phone checks are in TEST_PLAN.md.

## 1. FPS HUD not appearing
- **Finding:** there was no FPS element in the HUD at all. FPS only existed as a locked module in the ClickGUI list. The "Display refresh"
  element shows the screen's refresh rate, which is not Minecraft FPS.
- **Fix:** an FPS element now exists. It can be shown, moved, resized and styled. Its text is `FPS: Needs Native Integration`
  (`GameData.fps()` returns null, so no number is ever shown). Display refresh is labelled "Display ... Hz" and stays separate.
- **Not possible yet:** a real Minecraft FPS value. It needs frame data from inside the game (NATIVE_SPIKE.md).

## 2. CPS HUD not appearing or not working
- **Finding:** the existing CPS element was a touch counter (labelled "Screen taps / sec") fed by a 1x1 window that asks Android to
  report touches outside it. From the Android input dispatcher source: such events carry no coordinates, and they appear to be
  generated when a **new touch gesture starts**. In Minecraft, attacking while moving is a second finger, so it is probably not
  reported at all. That would make the counter read 0 or far too low during real play. (Source reading, not device-verified.)
- **Fix:** renamed to **Touch CPS** everywhere, with a note in the ClickGUI and the editor and a "touches received so far" line, so an
  always-zero counter is explained instead of silent. A separate **Attack CPS** element exists and shows
  `Attack CPS: Needs Native Integration`. It is never filled from touches.
- **Real attack CPS today:** only in personal worlds, from the add-on (draws on the action bar, from attack swing events).

## 3. HUD elements enabled but not visible, or in the wrong place
Likely causes found, all fixed in code:
1. **Auto-hide while "only in game" is on:** `ForegroundWatcher` treated any app that came to the front as "Minecraft left", including
   the keyboard, the notification shade, game-assistant sidebars and V CLIENT itself. One such event hid every HUD element, the icon and
   the open menu. Now: events from V CLIENT, system UI and installed keyboards are ignored, and hiding needs 3 "not in game" polls in a
   row (`VisibilityDebounce`). Showing is immediate.
2. **Wrong position in landscape on phones with a camera cut-out:** overlay windows did not extend into the cut-out area, so their
   coordinate system was shifted compared with the game. All overlay windows (HUD, icon, menu, crosshair, editor) now use
   `layoutInDisplayCutoutMode` (SHORT_EDGES, or ALWAYS on Android 11+).
3. **Positions could end up partly or fully off screen:** the old code stored whole percents and clamped only while dragging. Now
   positions are normalized fractions, re-clamped from the measured size every time an element changes size or the screen rotates.
4. **Silent failures:** a failed `addView` was swallowed. It is now logged.
- **Not confirmed:** which of these affected your phone. Test 3 in TEST_PLAN.md tells them apart.

## 4. ClickGUI opens slowly, closes unexpectedly, or will not close
- **Slow open:** a new WebView was built and the page loaded on every tap. Now it is created once (shortly after the service starts) and
  kept while the menu is closed. The window itself is removed on close, so a closed menu cannot block Minecraft. The kept WebView is
  released on low-memory signals and when the service stops.
- **Closing by itself:** cause 3.1 above (watcher), plus changing the "only in game" setting inside the menu could trigger it. Fixed by the
  same debounce.
- **Close and Back:** the close button is now 44 dp (was 36 dp). The Android Back button closes the menu while the menu window has
  keyboard focus. **Limit:** if you touch the game while the menu is open, Android moves focus to Minecraft and Back then goes to
  Minecraft. Use the close button or tap the icon again.
- **Fast double taps:** a tap on the icon during the closing animation used to be ignored. It now finishes the close and reopens.

## 5. Floating icon and menu direction
- **Finding:** the icon always snapped to the left or right edge after a drag, and the menu was a fixed full-height panel.
- **Fix:** the icon can be dropped anywhere. Its position is stored as x and y fractions of the free screen area, so it survives restarts and
  rotation. An optional "snap to edge" setting (`icon_snap`, off by default) keeps the old behaviour. The menu opens beside the icon:
  icon on the left half opens to the right, icon on the right half opens to the left. Width and position are computed from the screen
  size, so it never leaves the screen. If neither side has room, the panel uses the screen width. The icon is a 52 dp touch target (44 dp
  visible circle) that dims when idle. Positions saved by older versions are carried over.

## 6 to 8. HUD customization, editor, profiles
See HUD_SYSTEM.md.

## Not fixed because it cannot be fixed with the current architecture
- Real Minecraft FPS, attack CPS from touch input on public servers, coordinates, direction, keystrokes, armor and combo on public servers
  (all need game data; NATIVE_SPIKE.md explains the blocker).
- A preview of the real game frame inside the editor: Android gives no frame access without screen capture, so the editor shows a labelled
  schematic of the screen, driven by the same numbers the real HUD uses.

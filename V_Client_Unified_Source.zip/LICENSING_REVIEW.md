# LeviLauncher licensing and architecture review (completed from the uploaded source)

Reviewed: `LeviLauncher-Android-main.zip` (2,000 files: 731 Java, 87+48+40 C/C++ sources, 10 Kotlin, 581 XML, 125+38 headers).
This is an engineering review, not legal advice. **No LeviLauncher code was copied, adapted or built into V CLIENT.**

## 1. Verdict
| Question | Answer |
|---|---|
| Does the repository's licence permit the intended reuse (embedding its launcher in V CLIENT)? | **No.** The Apache-2.0 licence covers only the authors' own code. The parts that make the launcher work are not under it, and its Microsoft sign-in approach is not acceptable for V CLIENT. |
| Is anything reusable? | Only ideas and publicly documented Android techniques. Possibly small pieces of the authors' own Apache-2.0 code after a per-file ownership check, but nothing is needed for the selected approach. |
| Is the architecture technically adoptable? | Not as is. See section 4 and NATIVE_SPIKE.md. |

## 2. Licence inventory (every component found)
| Component | Location | Licence found | Reusable in V CLIENT? |
|---|---|---|---|
| Launcher application code (Kotlin/Java) | `app/src/main/java/org/levimc/launcher/**` | Apache-2.0 per `LICENSE`. **The appendix placeholder is unfilled (`LICENSE`, last block: "Copyright [yyyy] [name of copyright owner]"), and source files carry no copyright or SPDX headers** (header scan found only vendored code and two files with another party's copyright). Copyright holder and contributor set are therefore not stated. | Legally possible with conditions (licence text, NOTICE, change markers, no trademarks), but ownership is unclear and the code depends on the unlicensed parts below. Not used. |
| Game-side Java ("minecraft" module) | `minecraft/src/main/java/**`: 387 files, 35,630 lines. Packages `com/mojang/minecraftpe` (including a 2,133-line `MainActivity.java` with 231 `native` methods), `com/microsoft/{applications,playfab,xal,xbox,xboxlive,xboxtcui}`, `com/xbox/httpclient`, `org/fmod` | **No licence file, no NOTICE, no statement of origin or clean-room process.** The package names, class names and native method set mirror Mojang, Microsoft and FMOD code. Two files (`com/mojang/android/StringValue.java`, `TextViewReader.java`) carry "Copyright (C) 2018-2021 Тимашков Иван" with no licence text. The e2e README calls these "stub `com.mojang.minecraftpe` classes" (`e2e/README.md`). | **No.** Apache-2.0 cannot license other parties' code, and the origin is undocumented. Must not be copied. |
| Prebuilt native binaries | `app/src/main/jniLibs/arm64-v8a/`: `libgxcore.so`, `libmaesdk.so`, `libPlayFabMultiplayer.so`, `libinbuiltmods.so` | No licence. By file name the first three correspond to Microsoft/Xbox Game Core, Microsoft telemetry and PlayFab Multiplayer components (name-based inference). `libinbuiltmods.so` is the project's own. | **No.** |
| Hook engine ("preloader") | `.gitmodules`: `app/src/main/cpp/preloader` -> `github.com/LiteLDev/preloader-android`. **Directory is empty in the ZIP (0 files).** | Unknown | **Not reviewable, not usable.** |
| Xbox HTTP client | `.gitmodules`: `app/src/main/cpp/libHttpClient` -> `github.com/microsoft/libHttpClient`. **Empty in the ZIP.** | Microsoft project; licence not verified here | Not reviewable. |
| Pojav controls | `pojav_controls/` | **LGPL-3.0-or-later** (`pojav_controls/LICENSE`, `pojav_controls/NOTICE`: modified port of PojavLauncher's controls) | Would add LGPL obligations. Not used. |
| World tools | `app/src/main/cpp/worldtools/` | `NOTICE.txt`: GlacieTeam NBT and BinaryStream **MPL-2.0** (`vendor/nbt/LICENSE`, `vendor/binarystream/LICENSE`), LevelDB fork, Snappy, Zstandard **BSD-3-Clause**. Zstandard also ships a GPL-2.0 `COPYING` (dual licence; the BSD option is the one cited). | Not needed. Each carries its own obligations. |
| Sprites | `app/src/main/assets/licenses/NOTICE-levimc-kit.txt` | MIT (LeviMC) | Not needed. |
| Gradle dependencies | `gradle/libs.versions.toml`: Firebase, Play Services Games, Play Billing, Discord SDK (`libs/discord_partner_sdk.aar` referenced in `app/build.gradle:192`), Bouncy/Spongy Castle, OkHttp, Glide, RaphiMC `MinecraftAuth`, Lenni0451 `commons`, `xCrash` fork, others | Each has its own licence and terms; not individually audited. | Not used. |

Do not assume the whole repository is Apache-2.0: it is not.

## 3. Findings that block reuse regardless of licence
| Finding | Source reference |
|---|---|
| The launcher authenticates with Minecraft Bedrock Android's own Microsoft application identity: `DEFAULT_CLIENT_ID = MsaConstants.BEDROCK_ANDROID_TITLE_ID`, and `XalExporter` writes the resulting tokens into the game's XAL data using title id `1739947436`. | `core/auth/MsftAuthManager.java:77`, `core/auth/storage/XalExporter.java:27` |
| It builds a fake `ApplicationInfo` for package `com.mojang.minecraftpe`. | `core/minecraft/MinecraftLauncher.java:66` |
| It copies the installed game's native libraries into its own private storage and loads them with `System.load`. | `core/minecraft/GamePackageManager.kt:122` (`extractLibraries`), `:455` |
| The only "licence check" is whether the installer is Google Play. | `util/PlayStoreValidator.java`, used at `MinecraftLauncher.java:151` |
| Hook signatures (ARM64 byte patterns per game version) are fetched at runtime from a GitHub raw URL. | `preloader/PreloaderSignatureRulesManager.java:34`, data in `resources/preloader/preloader_signature_rules_source.json` |
| It disclaims bans and account risk. | `README.md:171` |

V CLIENT must not impersonate another application's Microsoft client identity, spoof package identity, or redistribute Mojang/Microsoft code or binaries. That excludes the launcher approach as built.

## 4. How LeviLauncher launches Minecraft (from the code)
1. `MinecraftLauncher.launch` (`core/minecraft/MinecraftLauncher.java`) checks the version (rejects below 1.21.80, line 124), the Play installer check (line 151), then starts `MinecraftLoadingActivity`.
2. `MinecraftRuntimePreparer.prepare` (`MinecraftRuntimePreparer.kt`) prepares the Microsoft account, extracts the game's libraries, loads `libminecraftpe.so` through its native helper (`:112`), loads the preloader (`:123`) and applies signature rules (`:129`).
3. The game then runs as `class MinecraftActivity : MainActivity()` (`MinecraftActivity.kt:35`) where `MainActivity` is the bundled `com.mojang.minecraftpe.MainActivity` from the `minecraft/` module, **inside the launcher's own process and package**.
4. Native mods are `.so` files loaded into that process and hook through the preloader.

Supported environment (`README.md:46-51`, `app/build.gradle`): Android 9+ (minSdk 28), ARM64 only (`abiFilters 'arm64-v8a'`, line 84), NDK 28.2.13676358, Minecraft 1.21.80 or later from Google Play.
Xbox: its own sign-in (see section 3). Multiplayer/Realms: the code handles Realm deep links (`util/MinecraftUriHandler.java`) but the repository contains no multiplayer or Realms test; its end-to-end test uses a placeholder game, not Minecraft (`e2e/README.md`). **Compatibility with servers and Realms is therefore unverified by the repository itself.**

## 5. Rules for V CLIENT
- No code, data, binaries or signature rules from this repository are used.
- No Flarial code is used.
- No Microsoft/Mojang code or binaries are redistributed; no application identity is impersonated.
- If any Apache-2.0 code is ever reused: confirm the copyright holder per file, add the licence text, a NOTICE entry and change markers, and list third-party licences in the app.

## 6. Other terms to read yourself
Minecraft EULA and Usage Guidelines, Microsoft Services Agreement, Google Play terms, and each server's rules.
Some large servers ban any client modification that gives a benefit the vanilla client lacks.

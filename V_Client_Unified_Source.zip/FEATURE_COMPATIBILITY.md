# V CLIENT feature compatibility report

One APK, one ClickGUI, one module registry, one config system. Each module declares what it needs, and the menu shows
its real status for the selected mode (Auto / Public server / Personal world). Nothing is faked: modules with no
legitimate route are listed as Unavailable or Planned and cannot be switched on.

Status key: **Works** = implemented, logic tested where possible. **Untested** = written, needs a device run (see TEST_PLAN.md).

## Public servers and personal worlds (Android side)
| Feature | Status | Notes |
|---|---|---|
| ClickGUI, module registry, animations | Works | Headless-browser tested |
| HUD editor + widgets (battery, clock, RAM, storage, display refresh, overlay time, ping, custom text) | Works (previous stage) | Ping goes to the address you type |
| Screen taps / sec | Works | Every tap. Never labelled attack CPS |
| Overlay crosshair | Works | May not match the game's aiming point exactly |
| Themes + custom colours, configs save/load | Works | |
| Resource/behavior pack manager | Works (previous stage) | |
| Server list with Add / Join | Untested | Uses Minecraft's own minecraft:// links |

## Personal and hosted worlds only (World add-on, Script API)
| Feature | Source | Status |
|---|---|---|
| Coordinates | player location | Logic tested, game glue untested |
| Direction | player rotation | Logic tested (yaw convention), glue untested |
| Armor HUD (durability %) | equippable + durability components | Logic tested, glue untested |
| Keystrokes (move, jump, sneak) | input info | Logic tested, glue untested |
| Attack CPS | attack swing events | Logic tested, glue untested |
| Combo | hit and hurt events | Logic tested, glue untested |

Not available on public servers: a behavior pack does not run on a server you join (to be confirmed on device).

## Not available
| Feature | Why |
|---|---|
| Minecraft FPS | Exists only inside the game. No legitimate route without root/Shizuku/injection. |
| Zoom | Needs game-side FOV change. Impossible on public servers. Personal worlds: planned (see KNOWN_ISSUES.md). |
| Any in-game stat on public servers | Would need code inside the game process. |

## Detection
V CLIENT detects: Minecraft installed and its version, overlay permission, whether the add-on was built and sent.
It cannot detect: which world is open, whether the pack is enabled in a world, or whether the add-on is running.

## Native tier (not built)
| Module | Needs | Status |
|---|---|---|
| Minecraft FPS, frame time | In-process graphics hook | Locked. Engine exists; no hook. |
| Zoom, FreeLook | In-process camera/FOV hooks | Locked. |
| Hit counter, target tracking, combat statistics | In-process game events | Locked. |
| Attack CPS, combo, coordinates, direction, armor, keystrokes on public servers | In-process game events | Locked; still available in personal worlds via the add-on. |
Native modules unlock only for a Minecraft version listed as verified after a real-phone test. The list is empty.

## HUD system (this update)
| Feature | Status |
|---|---|
| Per-element placement and styling, editor with preview, profiles, import/export, normalized coordinates | Implemented (phone test pending) |
| Battery, clock, RAM, storage, display refresh, overlay time, ping, custom text | Live Android data |
| Touch CPS | Live, but touches only; probably misses a second finger. Not attack CPS. |
| FPS, attack CPS, coordinates, direction, keystrokes, armor, combo (HUD elements) | Placeable; show "Needs Native Integration". Personal worlds: the add-on shows coordinates, direction, armor, keystrokes, attack CPS and combo on the action bar instead (not movable). |
| Crosshair | Drawn by V CLIENT; movable in the editor; may not match the game's exact aim point |
